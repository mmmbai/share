param
(
	[Parameter(Mandatory=$true)]
	[String] $subscriptionkey
)

$apimcontext = New-AzApiManagementContext -ResourceGroupName "DV-DV-APIMgmt-RG" -ServiceName "dv-dv-apimgmt01-apim"

$Subscriptions = Get-AzApiManagementSubscription -Context $apimcontext | Where-Object { $_.UserId -eq $null}

foreach ($sub in $Subscriptions) 
{
	$SubscriptionKeys = Get-AzApiManagementSubscriptionKey -Context $APIMContext -SubscriptionId $sub.SubscriptionId
	if ($SubscriptionKeys.PrimaryKey -eq $subscriptionkey -or $SubscriptionKeys.SecondaryKey -eq $subscriptionkey )
	{
		Write-Host "$($sub.Name)"
		break
	}	
 }