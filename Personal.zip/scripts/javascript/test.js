console.log("test");
a={};
a.a='a';
a.b='b';
console.log(a);
console.dir(a);
console.dirxml(a);


