function tracePrototypeChainOf(object) {
    var proto = object.constructor.prototype;
    var result = '';

    while (proto) {
        result += ' -> ' + proto.constructor.name;
        proto = Object.getPrototypeOf(proto)
    }

    return result;
}

function tracePropertiesChainOf(object) {
	var proto = object;	
    var space = '';
    while (proto) {
		console.log(space+'->['+proto.constructor.name+']');
		console.log(space+Object.getOwnPropertyNames(proto));
		space+='    ';
        proto = Object.getPrototypeOf(proto)
    } 
}


//Or
Object.prototype.tracePrototypeChainOf = function () {
    var proto = this.constructor.prototype;
    var result = '';

    while (proto) {
        result += ' -> ' + proto.constructor.name;
        proto = Object.getPrototypeOf(proto)
    }

    return result;
}












var trace = tracePrototypeChainOf(document.body)