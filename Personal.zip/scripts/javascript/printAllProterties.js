//0. If you need run in script file. you need us IIFE as
(function printThisObject(){
  console.log(this);         // return the global object
})();
//Or this "global" keyword
console.log(global);    

//1. Only own enumerable properties

OriginalThis=this;
Object.keys(this).forEach(function(element) {
  console.log(element,Object.prototype.toString.call(OriginalThis[element]));
});

function listOwnEnumerableProperties(object) {
Object.keys(object).forEach(function(element) {
  console.log(element,Object.prototype.toString.call(object[element]));
});
}

//2. own enumerable  properties + prototype enumerable properties

for (var propName in b)
{
console.log(  propName,  Object.prototype.toString.call(b[propName]))
}

function listAllEnumerableProperties(object) {
	for (var propName in object)
	{
	console.log(  propName,  Object.prototype.toString.call(object[propName]))
	}
}



//3. For all(enumerable+non enumerable) properties
console.log( Object.getOwnPropertyNames(this));

//or type 
this 

//get name
aaa.constructor.name
