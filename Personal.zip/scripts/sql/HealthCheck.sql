-- Title: ESB Meter Metrics
-- Author: John Khtaria
-- Version: 1.0
-- Date: 2013-05-22
-- Description: Provides all values to populate ESB portion of health gate spreadsheet.
-- Note: Run procedure in RT_PROD EMS Metrics connection, ensure DBMS Output is enabled to see results.

declare
-- Set these values before running this procedure.
todaydate varchar2(12) := '29-May-14';
yesterdaydate varchar2(12) := '28-May-14';

midnightrow varchar(100);
morningrow varchar(100);
eveningrow varchar(100);

midnightstarttotal number(20);
midnightendtotal number(20);

morningstarttotal number(20);
morningendtotal number(20);

eveningstarttotal number(20);
eveningendtotal number(20);

begin

-- Midnight Interrogation
SELECT pending_msg_count || ' pending messages at ' || sample_time into midnightrow
FROM (select pending_msg_count, sample_time from CRP_PRD_CLE.emsdestinationmetrics  
JOIN CRP_PRD_CLE.emsinstancemetrics 
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID 
WHERE emsinstancemetrics.sample_time between  
todaydate || ' 12.00.00 AM' and todaydate || ' 07.59.00 AM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
and ENVIRONMENT like 'PRD'
order by pending_msg_count desc)
where rownum = 1;

DBMS_OUTPUT.PUT_LINE('Midnight Interrogation: ');
DBMS_OUTPUT.PUT_LINE(midnightrow);

select inbound_total_msgs into midnightstarttotal
from CRP_PRD_CLE.emsdestinationmetrics  
JOIN CRP_PRD_CLE.emsinstancemetrics 
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID 
WHERE emsinstancemetrics.sample_time between  
todaydate || ' 12.00.00 AM' and todaydate || ' 12.05.00 AM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
and ENVIRONMENT like 'PRD'
order by sample_time asc;

select inbound_total_msgs into midnightendtotal
from CRP_PRD_CLE.emsdestinationmetrics  
JOIN CRP_PRD_CLE.emsinstancemetrics 
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID 
WHERE emsinstancemetrics.sample_time between  
todaydate || ' 08.00.00 AM' and todaydate || ' 08.05.00 AM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
and ENVIRONMENT like 'PRD'
order by sample_time asc;

DBMS_OUTPUT.PUT_LINE(midnightendtotal - midnightstarttotal || ' messages received from ADCS on ' || todaydate || ' from 12:00 AM to 8:00 AM');
DBMS_OUTPUT.PUT_LINE('');



-- Morning Interrogation
SELECT pending_msg_count || ' pending messages at ' || sample_time into morningrow
FROM (select pending_msg_count, sample_time from CRP_PRD_CLE.emsdestinationmetrics  
JOIN CRP_PRD_CLE.emsinstancemetrics 
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID 
WHERE emsinstancemetrics.sample_time between  
yesterdaydate || ' 08.00.00 AM' and yesterdaydate || ' 03.59.00 PM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
and ENVIRONMENT like 'PRD'
order by pending_msg_count desc)
where rownum = 1;

DBMS_OUTPUT.PUT_LINE('Morning Interrogation: ');
DBMS_OUTPUT.PUT_LINE(morningrow);

select inbound_total_msgs into morningstarttotal
from CRP_PRD_CLE.emsdestinationmetrics  
JOIN CRP_PRD_CLE.emsinstancemetrics 
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID 
WHERE emsinstancemetrics.sample_time between  
yesterdaydate || ' 08.00.00 AM' and yesterdaydate || ' 08.05.00 AM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
and ENVIRONMENT like 'PRD'
order by sample_time asc;

select inbound_total_msgs into morningendtotal
from CRP_PRD_CLE.emsdestinationmetrics  
JOIN CRP_PRD_CLE.emsinstancemetrics 
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID 
WHERE emsinstancemetrics.sample_time between  
yesterdaydate || ' 04.00.00 PM' and yesterdaydate || ' 04.05.00 PM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
and ENVIRONMENT like 'PRD'
order by sample_time asc;

DBMS_OUTPUT.PUT_LINE(morningendtotal - morningstarttotal|| ' messages received from ADCS on ' || yesterdaydate || ' from 8:00 AM to 4:00 PM');
DBMS_OUTPUT.PUT_LINE('');



-- Evening Interrogation
SELECT pending_msg_count || ' pending messages at ' || sample_time into eveningrow
FROM (select pending_msg_count, sample_time from CRP_PRD_CLE.emsdestinationmetrics  
JOIN CRP_PRD_CLE.emsinstancemetrics 
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID 
WHERE emsinstancemetrics.sample_time between  
yesterdaydate || ' 04.00.00 PM' and yesterdaydate || ' 11.59.00 PM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
and ENVIRONMENT like 'PRD'
order by pending_msg_count desc)
where rownum = 1;

DBMS_OUTPUT.PUT_LINE('Evening Interrogation: ');
DBMS_OUTPUT.PUT_LINE(eveningrow);

select inbound_total_msgs into eveningstarttotal
from CRP_PRD_CLE.emsdestinationmetrics  
JOIN CRP_PRD_CLE.emsinstancemetrics 
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID 
WHERE emsinstancemetrics.sample_time between  
yesterdaydate || ' 04.00.00 PM' and yesterdaydate || ' 04.05.00 PM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
and ENVIRONMENT like 'PRD'
order by sample_time asc;

select inbound_total_msgs into eveningendtotal
from CRP_PRD_CLE.emsdestinationmetrics  
JOIN CRP_PRD_CLE.emsinstancemetrics 
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID 
WHERE emsinstancemetrics.sample_time between  
yesterdaydate || ' 11.45.00 PM' and yesterdaydate || ' 11.59.00 PM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
and ENVIRONMENT like 'PRD'
order by sample_time asc;

DBMS_OUTPUT.PUT_LINE(eveningendtotal - eveningstarttotal || ' messages received from ADCS on ' || yesterdaydate || ' from 4:00 PM to 12:00 AM');
DBMS_OUTPUT.PUT_LINE(''); 

end;

