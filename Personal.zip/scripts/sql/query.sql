select SAMPLE_ID, SAMPLE_TIME, rno, ROWNUM rno2 from (
select SAMPLE_ID, SAMPLE_TIME, ROW_NUMBER() OVER (ORDER BY SAMPLE_TIME desc) rno, ROWNUM
from EMSINSTANCEMETRICS 
where EMS_URL='ssl://esbcprdmsg05.bchydro.bc.ca:21012,ssl://esbcprdmsg06.bchydro.bc.ca:21012'
order by SAMPLE_TIME desc ) 
where rno in (1,97) order by SAMPLE_TIME desc

63440
63238

select  INBOUND_TOTAL_BYTES from EMSDESTINATIONMETRICS 
where SAMPLE_ID='63440'

SAMPLE_ID DESTINATION_NAME DESTINATION_TYPE DESTINATION_SCOPE CONSUMER_COUNT PENDING_MSG_COUNT PENDING_MSG_BYTES  MAX_BYTES MAX_MESSAGES INBOUND_BYTE_RATE INBOUND_MSG_RATE INBOUND_TOTAL_BYTES INBOUND_TOTAL_MSGS OUTBOUND_BYTE_RATE OUTBOUND_MSG_RATE OUTBOUND_TOTAL_BYTES OUTBOUND_TOTAL_MSGS


select DESTINATION_NAME , SAMPLE_ID , INBOUND_TOTAL_BYTES,delta from
(select DESTINATION_NAME , SAMPLE_ID , INBOUND_TOTAL_BYTES,  INBOUND_TOTAL_BYTES -lag(INBOUND_TOTAL_BYTES) over(partition by  DESTINATION_NAME order by SAMPLE_ID ) delta
from (select * from emsdestinationmetrics
where (SAMPLE_ID='63440' or SAMPLE_ID='63238')
) order by delta desc)
where SAMPLE_ID='63440'


select to_timestamp('2014-10-08T20:44:56.964Z', 'YYYY-MM-DD"T"HH24:MI:SS.ff3"Z"') from dual;

SELECT to_char( CURRENT_TIMESTAMP,'YYYY-MM-DD"T"HH24:MI:SS.ff3"Z"') from dual;



select SAMPLE_ID , SAMPLE_TIME from (
select SAMPLE_ID, SAMPLE_TIME
from EMSINSTANCEMETRICS 
where EMS_URL='ssl://esbcprdmsg05.bchydro.bc.ca:21012,ssl://esbcprdmsg06.bchydro.bc.ca:21012'
and SAMPLE_TIME<to_timestamp('2014-10-08T20:44:56.964Z', 'YYYY-MM-DD"T"HH24:MI:SS.ff3"Z"') 
order by SAMPLE_TIME desc )
where ROWNUM=1


select extract( day from diff )  || ' Days ' ||
         extract( hour from diff ) || ' Hours ' ||
        extract( minute from diff )   ||' Mins'     
   from (select 
to_timestamp('2014-10-08T20:44:56.964Z', 'YYYY-MM-DD"T"HH24:MI:SS.ff3"Z"') -
to_timestamp('2014-10-07T20:44:56.964Z', 'YYYY-MM-DD"T"HH24:MI:SS.ff3"Z"')  
  diff from dual)
  
  



