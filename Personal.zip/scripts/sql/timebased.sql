select * from EMSINSTANCEMETRICS 
where   SAMPLE_TIME>to_timestamp('2014-10-14T20:44:56.964Z', 'YYYY-MM-DD"T"HH24:MI:SS.ff3"Z"') 
and  EMS_URL='ssl://esbcprdmsg05.bchydro.bc.ca:21012,ssl://esbcprdmsg06.bchydro.bc.ca:21012'
order by SAMPLE_TIME  