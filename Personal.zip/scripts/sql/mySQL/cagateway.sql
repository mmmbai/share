SELECT ps.name, ps.routing_uri, FROM_UNIXTIME(start_time/1000) AS start_time, sm.interval_size, FROM_UNIXTIME(end_time/1000) AS end_time, sm.attempted AS Total_Requests, (sm.attempted-sm.authorized) AS Failures_PolicyVilolation, ((sm.attempted-sm.completed)-(sm.attempted-sm.authorized)) AS Failures_RoutingFailure, sm.completed AS Successful_Requests
FROM published_service ps, service_metrics sm 
WHERE ps.goid=sm.published_service_goid AND ps.routing_uri IN ('/gwhealthcheck1') 
AND sm.interval_size=3600000;  
	
	
	
	
	
SELECT count(ps.name),min(FROM_UNIXTIME(start_time/1000)) AS min_start_time, max(FROM_UNIXTIME(end_time/1000)) AS max_end_time
FROM published_service ps, service_metrics sm 
WHERE ps.goid=sm.published_service_goid AND ps.routing_uri IN ('/infr/f5ping') AND sm.interval_size=86400000;  

--5000 keep 65 mins =780
--3600000 keep 7 days =168
--86400000 keep 365 days 
--82800000 and 90000000 are 23 and 25 hours, which is only use when PST/PDT time change 
SELECT ps.name,count(ps.name),min(FROM_UNIXTIME(start_time/1000)) AS min_start_time, max(FROM_UNIXTIME(end_time/1000)) AS max_end_time
FROM published_service ps, service_metrics sm 
WHERE ps.goid=sm.published_service_goid  AND sm.interval_size=86400000 group by  ps.name;  





SELECT ps.name, ps.routing_uri
FROM published_service ps, service_metrics sm 
WHERE ps.goid=sm.published_service_goid 
AND sm.interval_size=82800000;  




	
SELECT	distinct sm.interval_size  FROM published_service ps, service_metrics sm where  ps.routing_uri IN ('/gwhealthcheck1')


