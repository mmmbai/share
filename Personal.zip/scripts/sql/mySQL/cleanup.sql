--get hostname
select @@hostname;
--Detailed usage in last 30 days
SELECT ps.name,sum(attempted),min(FROM_UNIXTIME(start_time/1000)) AS min_start_time, max(FROM_UNIXTIME(end_time/1000)) AS max_end_time
FROM published_service ps, service_metrics sm 
WHERE ps.goid=sm.published_service_goid   AND FROM_UNIXTIME(start_time/1000) > ( CURRENT_DATE - INTERVAL 30 DAY)
group by  ps.name

--Detailed usage in one particular day
SELECT ps.name,count(attempted),min(FROM_UNIXTIME(start_time/1000)) AS min_start_time, max(FROM_UNIXTIME(end_time/1000)) AS max_end_time
FROM published_service ps, service_metrics sm 
WHERE ps.goid=sm.published_service_goid   
AND FROM_UNIXTIME(start_time/1000) > DATE('2020-01-17')
AND FROM_UNIXTIME(end_time/1000) < DATE('2020-01-18')
group by  ps.name



select name from(
--In last 30 days,used count is zero
select name from
(
SELECT name,sum(attempted) as att,min(FROM_UNIXTIME(start_time/1000)) AS min_start_time, max(FROM_UNIXTIME(end_time/1000)) AS max_end_time
FROM published_service ps, service_metrics sm 
WHERE ps.goid=sm.published_service_goid   AND FROM_UNIXTIME(start_time/1000) > ( CURRENT_DATE - INTERVAL 30 DAY)
group by  ps.name
) as temp_table
where  temp_table.att=0
--order by temp_table.name
UNION
--the name not shows in last 30 days table.show be empty
select name from 
(
SELECT distinct  name
FROM published_service ps
) as full_table
where full_table.name not in 
(
SELECT distinct  name
FROM published_service ps, service_metrics sm 
WHERE ps.goid=sm.published_service_goid   AND FROM_UNIXTIME(start_time/1000) > ( CURRENT_DATE - INTERVAL 30 DAY)
)
) as f_b
order by f_b.name


 