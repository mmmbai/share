-- https://techcommunity.microsoft.com/t5/azure-database-support-blog/lesson-learned-43-using-partitioning-option-for-azure-sql/ba-p/369039
--https://blog.csdn.net/manimanihome/article/details/53085285 Good example
SELECT *  FROM sys.database_files 
SELECT name,type_desc,physical_name,state_desc,size,growth FROM sys.database_files

SELECT *  FROM sys.filegroups 
CREATE TABLE t1 ( id int );
--- table on which filegroup
SELECT distinct o.[name], o.[type], f.[name] FROM sys.indexes i
     INNER JOIN sys.filegroups f
     ON i.data_space_id = f.data_space_id
     INNER JOIN sys.all_objects o
     ON i.[object_id] = o.[object_id] 
     AND o.type = 'U' -- User Created Tables
	 
--TABLE with partition
SELECT OBJECT_NAME(OBJECT_ID) ,partition_number, rows
FROM sys.partitions
--partition RANGE
select   * from sys.partition_range_values;

--function with RANGE
--https://database.guide/get-the-boundary-values-for-a-partitioned-table-in-sql-server-t-sql/
 SELECT 
    p.partition_number,
    r.boundary_id, 
    r.value AS [Boundary Value]   
FROM sys.tables AS t  
JOIN sys.indexes AS i  
    ON t.object_id = i.object_id  
JOIN sys.partitions AS p
    ON i.object_id = p.object_id AND i.index_id = p.index_id   
JOIN  sys.partition_schemes AS s   
    ON i.data_space_id = s.data_space_id  
JOIN sys.partition_functions AS f   
    ON s.function_id = f.function_id  
LEFT JOIN sys.partition_range_values AS r   
    ON f.function_id = r.function_id and r.boundary_id = p.partition_number  
WHERE i.type <= 1 AND t.name = 'TBL_PARTITION' 
ORDER BY p.partition_number ASC;

--which value in which partition
SELECT
MY_VALUE,
$PARTITION.PF_HASH_BY_VALUE(MY_VALUE) AS HASH_IDX
FROM
( SELECT MY_VALUE FROM [TBL_PARTITION] )  AS TEST (MY_VALUE); 
