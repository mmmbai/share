-- https://stackoverflow.com/questions/55218323/sql-server-automated-daily-table-partitioning
--https://myadventuresincoding.wordpress.com/2020/06/09/sql-server-how-to-partition-a-table-by-date/
ALTER PARTITION SCHEME [DailyPartitionScheme]
NEXT USED [PRIMARY];
 
alter partition function DailyPartitionFunction()  split range (N'2020-06-13T00:00:00.000');
