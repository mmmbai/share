--top by sql_id
 select * from 
 (
 select row_number()    OVER (ORDER BY count(*) desc) rn,
 sql_id, count(*) NUM,
count(*)*100/sum(count(*)) over() pctload
from v$active_session_history
--where sample_time > sysdate - 1/24
where sample_time >to_timestamp('2018-03-10 23:00:00', 'YYYY-MM-DD HH24:MI:SS')
and sample_time <to_timestamp('2018-03-10 23:59:00', 'YYYY-MM-DD HH24:MI:SS')
group by sql_id
order by count(*) desc
)
where PCTLOAD>5
--Then get details from sql_id
select ash.MACHINE,s.username, ash.session_id,ash."SESSION_SERIAL#" ,count(ash.MACHINE) NumOfCalls from v$active_session_history  ash, v$session s
where ash.sql_id = 'fxg5n8ptc9vqb' and  ash.sample_time > sysdate - 1/24 and ash.session_id=s.sid and ash."SESSION_SERIAL#"=s."SERIAL#"
group by ash.MACHINE ,ash.session_id,s.username,ash."SESSION_SERIAL#"
order by NumofCalls desc;
--Or only get machine from sql_id
select MACHINE, count(*) NumOfCalls from v$active_session_history 
where sql_id = 'cv27mhbsx65r9' and  sample_time > sysdate - 1/24 
group by MACHINE
order by NumofCalls desc;

select sql_text from v$sql where sql_id = 'cv27mhbsx65r9';
select * from  v$session where sid ='126'
--mixed version
select b.sql_id , a.NUM, a.pctload, b.sql_text from  
(
 select sql_id, NUM ,pctload from 
 (
 select row_number()    OVER (ORDER BY count(*) desc) rn,
 sql_id, count(*) NUM,
count(*)*100/sum(count(*)) over() pctload
from v$active_session_history
where sample_time > sysdate - 1/24/10
group by sql_id
order by count(*) desc
)
where PCTLOAD>5
)a,
(select distinct SQL_ID ,SQL_TEXT    from v$sql )  b
where b.sql_id in a.sql_id

--top by session_id
select session_id, count(*),
count(*)*100/sum(count(*)) over() pctload
from v$active_session_history
where sample_time > sysdate - 1/24
group by session_id
order by count(*) desc;
--Then get details from sql_id
select * from  v$session where sid ='547'