set serveroutput on format wraped; 
set serveroutput on;
ALTER PROCEDURE debug_purge COMPILE PLSQL_CCFLAGS = 'debug_on:TRUE' REUSE SETTINGS;
ALTER PROCEDURE log_info COMPILE PLSQL_CCFLAGS = 'debug_on:TRUE' REUSE SETTINGS;

DECLARE

   MAX_CREATION_DATE timestamp;
   MIN_CREATION_DATE timestamp;
   batch_size integer;
   max_runtime integer;
   retention_period timestamp;

  BEGIN

	dbms_output.enable;

   MIN_CREATION_DATE := to_timestamp('2010-01-01','YYYY-MM-DD');
   MAX_CREATION_DATE := to_timestamp('31-MAY-12 01.03.29.144000000 AM', 'DD-MON-RR HH12:MI:SS.FF AM') ;
    max_runtime := 60;
    retention_period := to_timestamp('31-MAY-12 01.03.29.144000000 AM', 'DD-MON-RR HH12:MI:SS.FF AM') ;
   batch_size := 10000;
     soa.delete_instances(
     min_creation_date => MIN_CREATION_DATE,
     max_creation_date => MAX_CREATION_DATE,
     batch_size => batch_size,
     max_runtime => max_runtime,
     retention_period => retention_period,
     purge_partitioned_component => false);
  END;
  
  
  
clear;
set serveroutput on;
ALTER PROCEDURE debug_purge COMPILE PLSQL_CCFLAGS = 'debug_on:TRUE' REUSE SETTINGS;
ALTER PROCEDURE log_info COMPILE PLSQL_CCFLAGS = 'debug_on:TRUE' REUSE SETTINGS;
DECLARE

   MAX_CREATION_DATE timestamp;
   MIN_CREATION_DATE timestamp;
   batch_size integer;
   max_runtime integer;
   retention_period timestamp;
    dt composite_instance.CREATED_TIME%type;

  BEGIN

	DBMS_OUTPUT.ENABLE(1000000);
    SELECT CREATED_TIME into dt  FROM 
(SELECT CREATED_TIME, ROW_NUMBER() OVER (ORDER BY CREATED_TIME) R FROM composite_instance)
WHERE R BETWEEN 10000 and 10000;
  dbms_output.put_line(dt);

   MIN_CREATION_DATE := to_timestamp('2010-01-01','YYYY-MM-DD');
   MAX_CREATION_DATE := to_timestamp(dt, 'DD-MON-RR HH12:MI:SS.FF AM') ;
    max_runtime := 60;
    retention_period := to_timestamp(dt, 'DD-MON-RR HH12:MI:SS.FF AM') ;
   batch_size := 10000;
     soa.delete_instances(
     min_creation_date => MIN_CREATION_DATE,
     max_creation_date => MAX_CREATION_DATE,
     batch_size => batch_size,
     max_runtime => max_runtime,
     retention_period => retention_period,
     purge_partitioned_component => false);
  END;


 