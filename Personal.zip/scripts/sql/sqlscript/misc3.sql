set trimspool on
set trim on
set pages 0
set linesize 1000
set long 1000000
set longchunksize 1000000
spool d:tst\sqlmon_active.html
select dbms_sqltune.report_sql_monitor(type=>'active') from dual;
spool off
/

set trimspool on trim on
set pages 0 linesize 1000
set long 1000000 longchunksize 1000000
spool d:tst\sqlmon_details.html
select dbms_sqltune.report_sql_detail('&sql_id',start_time=>to_date('&time','yyyy-mm-dd hh24:mi:ss'), duration=>&duration_in_seconds) from dual;
spool off

SELECT h.user_id,
       s2.username,
       s1.sql_text
FROM  v$active_session_history h,
      v$sqlarea s1,
      v$session s2
WHERE h.sample_time > sysdate-1
AND   h.sql_id = s1.sql_id
AND   h.user_id = s2.user_id
 



select /*+ ordered */ sql_text from v$sqltext sql
    where (sql.hash_value, sql.address) in (
        select decode(sql_hash_value, 0, prev_hash_value, sql_hash_value), decode(sql_hash_value, 0, prev_sql_addr, sql_address)
        from v$session s where s.paddr = (select addr from v$process p where p.spid = to_number('33292560')))
    order by piece asc;




 