COL p_1 NEW_VALUE 1 NOPRINT
COL p_2 NEW_VALUE 2 NOPRINT
SELECT 'x' p_1, 'x' p_2 FROM dual WHERE 1=2;
def 1
def 2


SELECT '&1' FROM dual;
