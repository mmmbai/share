--Schema level used space in each tablespace:

SELECT TABLESPACE_NAME, OWNER, round(SUM(BYTES/1024/1024),2) As Used FROM DBA_SEGMENTS group by TABLESPACE_NAME,owner order by Used desc;

--Allocated space :
select TABLESPACE_NAME, sum(bytes/1024/1024) "Allocated Size in MB" from dba_data_files group by TABLESPACE_NAME;

---Free Space:
select TABLESPACE_NAME,sum(bytes/1024/1024) "Freespace in MB" from dba_free_space group by tablespace_name;

