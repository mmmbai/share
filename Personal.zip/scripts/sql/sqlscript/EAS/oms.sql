select to_char(create_ts, 'YYYY-MM-DD') from oms.event_log order by  event_insert_ts desc limit 100


select occurence_ts from oms.event_log where create_ts > '2016-02-16 17:00:00'
limit 100



SELECT to_char(occurrence_ts, 'YYYY-MM-DD HH24')  occurrence_ts_res, count(1) occurrence_ts 
FROM oms.event_log  group by to_char(occurrence_ts, 'YYYY-MM-DD HH24') 
order by occurrence_ts_res


SELECT to_char(create_ts, 'YYYY-MM-DD HH24')  create_ts_res, count(1) create_ts 
FROM oms.event_log  group by to_char(create_ts, 'YYYY-MM-DD HH24') 
order by create_ts_res

SELECT to_char(processed_ts, 'YYYY-MM-DD HH24:MI')  processed_ts_res, count(1) processed_ts 
FROM oms.event_log  
where processed_ts > '2016-02-16 14:30:00' 
group by to_char(processed_ts, 'YYYY-MM-DD HH24:MI') 
order by processed_ts_res
