select version();
select current_catalog;
select current_database();
select current_schema();


SELECT datname FROM pg_database
WHERE datistemplate = true;

SELECT table_schema,table_name
FROM information_schema.tables
ORDER BY table_schema,table_name;

SELECT * FROM pg_tablespace;

SELECT * FROM pg_database 

SELECT pg_size_pretty(pg_tablespace_size('pg_default'))
SELECT pg_size_pretty(pg_database_size('oms'))