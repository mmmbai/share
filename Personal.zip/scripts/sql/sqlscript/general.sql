--Use two ' if you want print one '
select '''' from dual;

--User || if you want concat the string
select 'a' || 'b' from dual;

--set head off
set head off;

--Get current user
select user from  dual;
select username from user_users;
select sys_context('USERENV', 'CURRENT_USER') from  dual;
select sys_context('USERENV', 'SESSION_USER') from  dual;
select sys_context('USERENV', 'CURRENT_SCHEMA') from  dual;
select sys_context('USERENV', 'AUTHENTICATED_IDENTITY') from  dual;

--Get current database instance
select instance_name from v$instance  ;
select name from v$database; 

--Get current connection info
select uu.username || '@' || in1.instance_name connectionInfo from user_users uu, v$instance in1 ;

--Get default table space for current user
select default_tablespace from user_users;
