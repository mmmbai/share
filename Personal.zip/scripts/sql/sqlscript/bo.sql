SELECT to_char(START_TIMESTAMP, 'YYYY-MM-DD') START_TIMESTAMP, count(1) instances FROM audit_event group by to_char(START_TIMESTAMP, 'YYYY-MM-DD') order by START_TIMESTAMP



SELECT count(1) instances 
from audit_event 
where 
START_TIMESTAMP> to_timestamp('14-Mar-13 12.00.00.000000000 AM', 'DD-MON-RR HH12:MI:SS.FF AM')
and
USER_NAME='MBAI'

select * from v$session where USERNAME='BO_XIR3_AUDIT'



delete from AUDIT_DETAIL 
where event_id =(select Event_ID from AUDIT_EVENT 
                 where Start_Timestamp between '1/1/2006' and '12/31/2006') 
go 
delete from AUDIT_EVENT 
                 where Start_Timestamp between '1/1/2006' and '12/31/2006' 
go