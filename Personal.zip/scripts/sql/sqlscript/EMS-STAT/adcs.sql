with v as (  
select inbound_total_msgs total ,emsinstancemetrics.sample_time sample_time , row_number() over (order by sample_time asc) seqnum  
from emsdestinationmetrics  
JOIN emsinstancemetrics  
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID  
WHERE emsinstancemetrics.sample_time between   
 sysdate -3 and  sysdate  
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings'  
and ENVIRONMENT like 'PRD'  
order by sample_time asc  
)  
SELECT ( to_date(to_char(b.sample_time,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss') - to_date('1970-01-01', 'YYYY-MM-DD'))* 60 * 60 * 24  TIME,  
decode(sign(b.total-a.total), -1,0,b.total-a.total) delta  
from v a, v b  
where a.seqnum = b.seqnum-1  ;



select 
   (to_date(to_char(emsinstancemetrics.sample_time,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss') - to_date('1970-01-01', 'YYYY-MM-DD'))* 60 * 60 * 24  TIME,
   PENDING_MSG_COUNT delta 
from emsdestinationmetrics  
JOIN emsinstancemetrics  
on emsdestinationmetrics.SAMPLE_ID = emsinstancemetrics.SAMPLE_ID  
WHERE emsinstancemetrics.sample_time between   
 sysdate - 3 and  sysdate  
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings'  
and ENVIRONMENT like 'PRD'  
order by sample_time asc  






