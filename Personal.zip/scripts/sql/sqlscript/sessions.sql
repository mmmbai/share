SELECT  *
FROM  v$active_session_history h
WHERE h.sample_time > sysdate -1/(24*60)



select * from v$session

select h.SESSION_ID, h.SESSION_SERIAL#  ,
s.PROCESS,                 s.MACHINE , s.port
 FROM  v$active_session_history h,
  v$session s
  where h.SESSION_ID=s.SID
  and h.SESSION_SERIAL# = s.SERIAL#  
  and h.sample_time > sysdate -1/(24*60)
  
 
 --get full sql by sql id   
select  sql_text from v$sqltext sql
    where sql.sql_id='0jtp8nz94htvq'
    order by piece asc;
  
--get number of runs  of last 5 minutes 
  select sql_id, count(*)  runs
  FROM  v$active_session_history 
  where   sample_time > sysdate -5/(24*60)
  group by sql_id
  order by runs desc;

 
--get exec time of last 5 minutes 
select sql_id, sum(TM_DELTA_DB_TIME)/1000000000  runs
  FROM  v$active_session_history 
  where   sample_time > sysdate -5/(24*60)
  group by sql_id
  order by runs desc;
  
  --get sql_id and details
select 
  s.SCHEMANAME, s.PROCESS,                 s.MACHINE , s.port,
  h.SESSION_ID, h.SESSION_SERIAL#  ,h.sql_id
 FROM  v$active_session_history h,
  v$session s
  where h.SESSION_ID=s.SID
  and h.SESSION_SERIAL# = s.SERIAL#  
  and h.sql_id='fazx1u7k4qt19'
    and h.sample_time > sysdate -1/(24*60)

 
