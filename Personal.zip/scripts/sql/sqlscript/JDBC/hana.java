import java.sql.*;

public class Test {
	public static void main(String[] argv) {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(
					"jdbc:sap://hanacloud:30015/?autocommit=true", "TEST","Test12345");
		} catch (SQLException e) {
			e.printStackTrace();			
			return;
		}
		if (connection != null) {
			try {
				System.out.println("Connection to HANA successful!");
				Statement stmt = connection.createStatement();
			
				
				ResultSet resultSet = stmt
						.executeQuery("Select 'hello world' from dummy");
				resultSet.next();
				String hello = resultSet.getString(1);
				System.out.println(hello);
			} catch (SQLException e) {
				System.err.println("Query failed!");
			}
		}
	}	
	
	
}