BEGIN
FOR cur_rec IN (SELECT table_name, constraint_name 
FROM user_constraints
WHERE constraint_type = 'R') LOOP
EXECUTE IMMEDIATE 'ALTER TABLE ' || cur_rec.table_name || ' DROP CONSTRAINT ' || cur_rec.constraint_name;
END LOOP;
FOR cur_rec IN (SELECT object_name, object_type
FROM user_objects) LOOP
BEGIN
IF cur_rec.object_type != 'DATABASE LINK' THEN
EXECUTE IMMEDIATE 'DROP ' || cur_rec.object_type || ' ' || cur_rec.object_name;
execute immediate 'purge recyclebin';
END IF;
EXCEPTION
WHEN OTHERS THEN
NULL;
END;
END LOOP;
END;
/

