create directory TMP as '/tmp/'; 

DECLARE
f utl_file.file_type;
begin
f:= utl_file.fopen('TMP', 'foo.log', 'A');
end;





begin
f:= UTL_FILE.FREMOVE ('TMP', 'foo.log');
end;
drop directory tmp;
