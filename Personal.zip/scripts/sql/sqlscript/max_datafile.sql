select b.FILE_ID,b.OWNER, b.SEGMENT_NAME, b.SEGMENT_TYPE, b.block_id ,b.BYTES from
(select max(block_id) block_id,file_id   from dba_extents group by file_id ) a,
dba_extents b
where a.block_id=b.block_id and a.file_id=b.file_id and b.TABLESPACE_NAME='CRP_USER_DATA' order by b.FILE_ID