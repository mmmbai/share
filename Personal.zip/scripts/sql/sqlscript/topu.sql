select b.sid , a.NUM, a.pctload, b.username, b.machine from  
(
 select session_id, NUM ,pctload from 
   (
         select session_id, count(*) NUM,
        count(*)*100/sum(count(*)) over() pctload
        from v$active_session_history
        where sample_time > sysdate - 1/24
        group by session_id
        order by count(*) desc
    )
where PCTLOAD>3
)a,
(select sid, username, machine from  v$session  )  b
where b.sid in a.session_id