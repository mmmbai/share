--In sql server, following will work but Oracle didn;t
SELECT * INTO TEMP_Testing from auditing where  noun='Invoice' and target='PASSPORT' and source='ARIBA' 


--In Oracle we need use
create table TEMP_Testing  as SELECT *  from auditing where  noun='Invoice' and target='PASSPORT' and source='ARIBA' 