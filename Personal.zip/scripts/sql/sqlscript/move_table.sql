set head off;
SELECT    'alter table '||  user_tables.table_name|| ' move;'
FROM user_tables ;
SELECT   
 'alter index '|| user_indexes.index_name|| ' rebuild online;'
FROM user_tables JOIN user_indexes on user_indexes.table_name = user_tables.table_name
where  user_indexes.index_type='NORMAL'
ORDER by user_tables.table_name,user_indexes.index_name;


set head off;
SELECT    'alter table '||  user_tables.table_name|| ' move;'
FROM user_tables where user_tables.table_name='EMSDESTINATIONMETRICS' ;
SELECT   
 'alter index '|| user_indexes.index_name|| ' rebuild online;'
FROM user_tables JOIN user_indexes on user_indexes.table_name = user_tables.table_name
where  user_indexes.index_type='NORMAL' and user_tables.table_name='EMSDESTINATIONMETRICS'
ORDER by user_tables.table_name,user_indexes.index_name   ;


