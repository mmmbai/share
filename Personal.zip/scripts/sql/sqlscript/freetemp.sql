
select TABLESPACE_NAME,
       BYTES_USED/1024/1024 "USED(MB)", 
	   BYTES_FREE/1024/1024 "Free(MB)",  
	   (BYTES_USED+BYTES_FREE)/1024/1024 "TOTAL(MB)", 
	   BYTES_USED/(BYTES_USED+BYTES_FREE)*100 "USED(%)"	   
from V$TEMP_SPACE_HEADER
order by "USED(%)"

select * from dba_temp_free_space