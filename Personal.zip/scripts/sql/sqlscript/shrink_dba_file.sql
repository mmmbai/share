--get File_ID
select * from  dba_data_files where  TABLESPACE_NAME  ='CRP_USER_DATA';

--get segment name of largest block id in one file
select owner,
           segment_name,
           file_id,
           block_id AS start_block,
           block_id + blocks - 1 AS end_block
           from (select  *  from DBA_EXTENTS where file_id=5 
order by BLOCK_ID desc ) 
where rownum = 1;
--shrink table 
ALTER TABLE LOG move;
--or shrink LOB(First line is Get which table belong to of a lob)
select owner , table_name, column_name from dba_lobs where segment_name='SYS_LOB0000116257C00011$$'; 
--This line will not work: ALTER TABLE LOG MODIFY lob (LOGMESSAGES) (shrink space);
ALTER TABLE LOG move lob(LOGMESSAGES) store as (tablespace CRP_USER_DATA)

--get invalid index
select owner, index_name from dba_indexes where status='UNUSABLE';
--rebuild index 
ALTER INDEX DOC_STORE_PK rebuild online;

--Dertermize how much can shrink
select file_name,
       ceil( (nvl(hwm,1)*8192)/1024/1024 ) smallest,
       ceil( blocks*8192/1024/1024) currsize,
       ceil( blocks*8192/1024/1024) -
       ceil( (nvl(hwm,1)*8192)/1024/1024 ) savings
from dba_data_files a,
     ( select file_id, max(block_id+blocks-1) hwm
         from dba_extents
         where file_id=5
        group by file_id ) b
where a.file_id = b.file_id
--Dertermize how much block can shrink
select a.file_id ,file_name,
       ceil( (nvl(hwm,1)) ) smallest,
       ceil( blocks) currsize,
       ceil( blocks) -
       ceil( (nvl(hwm,1)) ) savings
from dba_data_files a,
     ( select file_id, max(block_id+blocks-1) hwm
         from dba_extents
        group by file_id ) b
where a.file_id = b.file_id(+)
order by a.file_id
--shrin data file
alter database datafile '/u04/oradata/ESBTST3/CRP_USER_DATA09.dbf' resize  21288m;  

--Get all unused block for each file





