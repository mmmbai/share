set head off;
set serverout on;
--set feedback off ;
set linesize 1000

declare 
info varchar(120);
ts_name varchar(100);
alloced_mb number;
max_gb number;
perc_1 number;

owner varchar(100);
table_name varchar(100);
mbytes number;
perc number;



begin
select 'Current connection is ' ||uu.username || '@' || in1.instance_name connectionInfo into info from user_users uu, v$instance in1 ;

dbms_output.put_line(info );


END;


