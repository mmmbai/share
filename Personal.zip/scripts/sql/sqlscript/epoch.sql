select (sysdate- to_date('1-1-1970 00:00:00','MM-DD-YYYY HH24:Mi:SS'))*24*3600 epoch from dual;

select to_timestamp_tz('1970-01-01 Europe/London', 'yyyy-mm-dd tzr')+ numtodsinterval(1241132400000/1000,'second') dstamp from dual;