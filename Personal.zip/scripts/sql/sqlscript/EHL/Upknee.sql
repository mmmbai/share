delete from TEMP_SESSIONID;

insert into TEMP_SESSIONID (SESSION_ID)
select distinct lg.SESSION_ID  
from log_entry_upgraded lg
where  (sysdate -36/24)<lg.EVENT_TIMESTAMP  and   lg.EVENT_TIMESTAMP <(sysdate-0/24)
and NOUN='ExternalCampaignRequest'
;

exec  SP_Upaknee_Report;

select * from TEMP_REPORT order by TIMESTART ;


