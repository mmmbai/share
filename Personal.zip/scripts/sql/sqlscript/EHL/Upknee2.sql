create or replace PROCEDURE SP_Upaknee_Report AS 
	v_TIMESTART TIMESTAMP; 
	v_TIMESEND TIMESTAMP;
	v_EVENTSTART VARCHAR2(200 BYTE); 
	v_EVENTEND VARCHAR2(200 BYTE); 
	v_NUM_RETRYS integer;  
  CURSOR cur_SESSION_ID IS
  SELECT SESSION_ID FROM TEMP_SESSIONID;
begin
   delete from TEMP_REPORT;
FOR rec IN cur_SESSION_ID
LOOP
    insert into  TEMP_REPORT ( SESSION_ID) values ( rec.SESSION_ID);
    select  NVL(max(Event), null),  NVL(max(eventTime),null)
      into v_EVENTSTART, v_TIMESTART
      from
      (
        select DBMS_LOB.substr(DESCRIPTION, 50) Event ,EVENT_TIMESTAMP eventTime
          from log_entry_upgraded 
          where session_id =rec.SESSION_ID      
          and DBMS_LOB.substr(DESCRIPTION, 50) = 'START-PROCESS: SendAsync' order by EVENT_TIMESTAMP
      ) where rownum=1;
    update TEMP_REPORT set TEMP_REPORT.EVENTSTART=v_EVENTSTART,
      TEMP_REPORT.TIMESTART=v_TIMESTART
      where TEMP_REPORT.SESSION_ID=rec.SESSION_ID;
      
    select  NVL(max(Event), null),  NVL(max(eventTime),null)
      into v_EVENTEND, v_TIMESEND
      from
      (
        select DBMS_LOB.substr(DESCRIPTION, 50) Event ,EVENT_TIMESTAMP eventTime
          from log_entry_upgraded 
          where session_id =rec.SESSION_ID      
          and DBMS_LOB.substr(DESCRIPTION, 50) = 'END-PROCESS: SendAsync' order by EVENT_TIMESTAMP
      ) where rownum=1;
    update TEMP_REPORT set TEMP_REPORT.EVENTEND=v_EVENTEND,
      TEMP_REPORT.TIMESEND=v_TIMESEND
      where TEMP_REPORT.SESSION_ID=rec.SESSION_ID;
    select  count(*)*3 
    into v_NUM_RETRYS
      from log_entry_upgraded 
      where session_id =rec.SESSION_ID      
      and SEVERITY='ERROR' ; 
    update TEMP_REPORT set TEMP_REPORT.NUM_RETRYS=v_NUM_RETRYS
      where TEMP_REPORT.SESSION_ID=rec.SESSION_ID;  
END LOOP;
commit;
end;

