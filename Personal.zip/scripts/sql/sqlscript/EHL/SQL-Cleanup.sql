create or replace PROCEDURE SP_PURGE_TEMP AS 
TYPE tt_delete IS TABLE OF NUMBER;
t_delete tt_delete;
counter NUMBER;
CURSOR c_delete IS
   SELECT LOGID
   FROM LOG
   WHERE TRANSACTIONDOMAIN='ScadaDeviceInformation';
   --ServiceLinkOutboundService
l_delete_buffer PLS_INTEGER := 1000;
BEGIN
  counter := 0;
  OPEN c_delete;
  DBMS_OUTPUT.ENABLE(1000000);
  dbms_output.put_line('Started at: '||SYSTIMESTAMP );
  LOOP
  FETCH c_delete BULK COLLECT 
    INTO t_delete LIMIT l_delete_buffer;
    
    FORALL i IN 1..t_delete.COUNT
        DELETE LOG
        WHERE LOGID = t_delete (i); 
    EXIT WHEN c_delete%NOTFOUND;
    COMMIT;
    dbms_output.put_line('Counter:'||counter ||'. '||l_delete_buffer ||' deleted: '||SYSTIMESTAMP );
    counter := counter +1;    
    EXIT WHEN counter >=1000; 
  END LOOP;
  CLOSE c_delete;
  dbms_output.put_line('All Done: '||SYSTIMESTAMP );
END SP_PURGE_TEMP;