select sid,
listagg (eventTime, ',') WITHIN GROUP(ORDER BY eventTime ) TIMETime ,
listagg (event, ',') WITHIN GROUP(ORDER BY eventTime )   EVENT
from 
(
  select DBMS_LOB.substr(DESCRIPTION, 50) Event ,lg.EVENT_TIMESTAMP eventTime, session_id sid
  from log_entry_upgraded lg
  where session_id in(
  'EEM003-f1d29d03-9f62-465a-b944-5df062e1cd8d-1440783855567'
  )
  and (DBMS_LOB.substr(DESCRIPTION, 50) ='END-PROCESS: SendAsync' or DBMS_LOB.substr(DESCRIPTION, 50) = 'START-PROCESS: SendAsync')
  order by lg.EVENT_TIMESTAMP
) 
GROUP BY sid

select * from log_entry_upgraded where session_id=
'EEM003-5eae7a17-e081-4e8c-a043-bc8d10603e9a-1440795444491'