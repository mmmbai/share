select b.FILE_ID,b.OWNER, c.table_name, b.SEGMENT_TYPE, b.block_id ,b.BYTES 
from
  (select max(block_id) block_id,file_id   from dba_extents group by file_id ) a,
  dba_extents b,
  (SELECT segment_name table_name, owner,segment_name ori_name, bytes  
	FROM dba_segments  
	WHERE segment_type = 'TABLE'  
	UNION ALL  
	SELECT i.table_name, i.owner, i.index_name,   s.bytes  
	FROM dba_indexes i, dba_segments s  
	WHERE s.segment_name = i.index_name  
	AND   s.owner = i.owner  
	AND   s.segment_type = 'INDEX'  
	UNION ALL  
	SELECT l.table_name, l.owner,l.segment_name , s.bytes  
	FROM dba_lobs l, dba_segments s  
	WHERE s.segment_name = l.segment_name  
	AND   s.owner = l.owner  
	AND   s.segment_type = 'LOBSEGMENT'  
	UNION ALL  
	SELECT l.table_name, l.owner, l.index_name  ,s.bytes  
	FROM dba_lobs l, dba_segments s  
	WHERE s.segment_name = l.index_name  
	AND   s.owner = l.owner  
	AND   s.segment_type = 'LOBINDEX')c
where  
   a.block_id=b.block_id and a.file_id=b.file_id and b.TABLESPACE_NAME='CRP_USER_DATA' and  b.OWNER=c.owner and b.SEGMENT_NAME=c.ori_name
   order by b.FILE_ID