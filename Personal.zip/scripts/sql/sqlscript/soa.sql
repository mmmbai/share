-- Get total number of composite instance
SELECT count(1) total_instance from  composite_instance 

-- Get number of composite instance grouped by state
SELECT count(1) instances,state from  composite_instance  group by state
--Get total number of composite instance older than ? days
SELECT count(1) total_instance from  composite_instance where CREATED_TIME<(sysdate-14)

-- Get number of composite instance grouped by created date
SELECT to_char(CREATED_TIME, 'YYYY-MM-DD') CREATED_DATE, count(1) instances FROM composite_instance group by to_char(CREATED_TIME, 'YYYY-MM-DD') order by CREATED_DATE

-- Get number of composite instance grouped by created date and hour
SELECT to_char(CREATED_TIME, 'YYYY-MM-DD:HH') CREATED_DATE, count(1) instances FROM composite_instance group by to_char(CREATED_TIME, 'YYYY-MM-DD:HH') order by CREATED_DATE


-- Get number of composite instance grouped by composite name (with version)
SELECT count(1) instances,COMPOSITE_DN from  composite_instance  group by COMPOSITE_DN

-- Get number of composite instance grouped by composite name (without version)
SELECT count(1) instances,substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1) as COMPOSITE from  composite_instance  group by substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1) 

-- Get number of composite instance with composite name 
SELECT count(1) instances from  composite_instance where COMPOSITE_DN like '%PubT%'

--Get delevery queue grouped by state
select count(1) dlv, state from dlv_message group by state

--Get BPEL instance grouped by state
select count(1) bpelInstance, state from cube_instance group by state



--Get  delevery queue which parent composite doesn't exist
SELECT dlv_message.ecid FROM dlv_message 
WHERE dlv_message.ecid NOT IN (SELECT composite_instance.ecid FROM composite_instance)

--Get BPEL instance which parent composite doesn't exist
SELECT cube_instance.ecid FROM cube_instance 
WHERE cube_instance.ecid NOT IN (SELECT composite_instance.ecid FROM composite_instance)


--select dl.* from composite_instance ci, dlv_message dl where id='30001' and ci.CONVERSATION_ID  =dl.CONV_ID  ;
--select * from cube_instance where  CMPST_ID =null;

-- schesule log 
select log_date, owner, job_name, status  from user_scheduler_job_log where job_name = 'DO_LOOPED_PURGE_JOB';

clear;
SELECT count(1) instances,COMPOSITE_DN from  composite_instance where COMPOSITE_DN like '%PubQ%' 
or COMPOSITE_DN like '%SubQ%'
or COMPOSITE_DN like '%PubT%'
or COMPOSITE_DN like '%SubT%'  group by COMPOSITE_DN



SELECT count(1) instances,substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1) as COMPOSITE
from composite_instance 
where 
(CREATED_TIME> to_timestamp('18-Sep-12 01.05.00.000000000 PM', 'DD-MON-RR HH12:MI:SS.FF AM'))
and
(CREATED_TIME< to_timestamp('18-Sep-12 01.06.00.000000000 PM', 'DD-MON-RR HH12:MI:SS.FF AM'))
group by substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1) 



select log_date, owner, job_name, status  from user_scheduler_job_log where job_name = 'DO_LOOPED_PURGE_JOB';

