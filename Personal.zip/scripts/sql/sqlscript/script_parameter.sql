set serverout on verify off
declare
myvar1 varchar2(30) := '&1' ;
myvar2 varchar2(30) := '&2' ;
begin
if myvar1 is not null and myvar2 is not null
then
dbms_output.put_line('both variables are not null : ['||myvar1||','||myvar2||']');else
dbms_output.put_line('ERR : at least one of the variables is null !');
end if;
end;
/
exit;


--SELECT '&1' FROM dual;