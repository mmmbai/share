--1)
create or replace 
function my_is_number(pVal in varchar2) return number deterministic
  as
     lNum number;
  begin
    lNum := to_number(pVal);
    return 1;
  exception
    when value_error then
             return 0;
  end;
  
--2)
select *  from table_name
 where is_number(col_need_check) = 0

 
 
 

