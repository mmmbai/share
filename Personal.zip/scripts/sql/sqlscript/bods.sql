--Job and workflow are in same level objects. They can not use same name
--Dataflow are same level objects. They can not use same name

-- Get total number of Job instance
SELECT count(1) total_instance from  al_history 

-- Get number of Job instance grouped by Job name
SELECT count(1) instances, service "Job name" from  al_history  group by service

-- Get number of Job instance grouped by created date
SELECT to_char(START_TIME, 'YYYY-MM-DD') CREATED_DATE, count(1) instances FROM al_history group by to_char(START_TIME, 'YYYY-MM-DD') order by CREATED_DATE

--Get total number of Job instance older than ? days
SELECT count(1) total_instance from  al_history where START_TIME<(sysdate-14)

--Get file location from Job's name
SELECT al_history_info.value from al_history ,  al_history_info where   al_history.object_key= al_history_info.object_key and al_history.service='Alpha_Customers_Job' 
  and(al_history_info.norm_name='MONITOR_LOG_INFO' or al_history_info.norm_name='ERROR_LOG_INFO' or al_history_info.norm_name='TRACE_LOG_INFO')