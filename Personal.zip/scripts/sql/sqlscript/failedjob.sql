SELECT to_char(log_date, 'DD-MON-YY HH24:MM:SS') TIMESTAMP, job_name, status,
   SUBSTR(additional_info, 1, 40) ADDITIONAL_INFO
     FROM dba_scheduler_job_run_details 
   where JOB_NAME='Purge_Job_log_entry_upgraded_T' ORDER BY log_date;