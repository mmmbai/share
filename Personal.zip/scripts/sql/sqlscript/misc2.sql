select * from dba_role_privs where GRANTEE='RO_DEV2_MDS'


select count(1)  from composite_instance where created_time < to_timestamp('03-JAN-12 22.30.26.998000000', 'DD-MON-RRHH24:MI:SS.FF');



SELECT * FROM
(SELECT CREATED_TIME, ROW_NUMBER() OVER (ORDER BY CREATED_TIME) R FROM composite_instance)
WHERE R BETWEEN 10000 and 10000





   MIN_CREATION_DATE := to_timestamp('2011-01-01','YYYY-MM-DD');
   MAX_CREATION_DATE := to_timestamp('05-DEC-11 19.14.39.809000000', 'DD-MON-RRHH24:MI:SS.FF');
   
   select to_timestamp('31-MAY-12 01.03.29.144000000 AM', 'DD-MON-RR HH12:MI:SS.FF AM') from dual ;
   
   
SELECT to_char(CREATED_TIME, 'YYYY-MM-DD') abc, count(1) FROM composite_instance group by to_char(CREATED_TIME, 'YYYY-MM-DD') order by abc


SELECT to_char(CREATED_TIME, 'YYYY-MM-DD:HH') abc, count(1) FROM composite_instance group by to_char(CREATED_TIME, 'YYYY-MM-DD:HH') order by abc



spool soainfra_purge_n2_output3.txt 
set serveroutput on 
set pages 1000 
ALTER PROCEDURE debug_purge  COMPILE PLSQL_CCFLAGS = 'debug_on:TRUE' REUSE SETTINGS; 
ALTER PROCEDURE log_info COMPILE PLSQL_CCFLAGS = 'debug_on:TRUE' REUSE SETTINGS;

DECLARE

   MAX_CREATION_DATE timestamp; 
   MIN_CREATION_DATE timestamp; 
   batch_size integer; 
   max_runtime integer; 
   retention_period timestamp;

BEGIN

  MIN_CREATION_DATE := sysdate - 365;      
  MAX_CREATION_DATE := sysdate - 3;      
  max_runtime := 10;      
  retention_period := sysdate;      
  batch_size := 300;      
        
  dbms_output.put_line ('MIN_CREATION_DATE=' || MIN_CREATION_DATE);      
  dbms_output.put_line ('MAX_CREATION_DATE=' || MAX_CREATION_DATE);      
  dbms_output.put_line ('retention_period=' || retention_period);      
        
  soa.delete_instances(      
  min_creation_date => MIN_CREATION_DATE,      
  max_creation_date => MAX_CREATION_DATE,      
  batch_size => batch_size,      
  max_runtime => max_runtime,      
  retention_period => retention_period,      
  purge_partitioned_component => false);      
   END; 
   /

ALTER PROCEDURE debug_purge  COMPILE PLSQL_CCFLAGS = 'debug_on:FALSE' REUSE SETTINGS; 
ALTER PROCEDURE log_info COMPILE PLSQL_CCFLAGS = 'debug_on:FALSE' REUSE SETTINGS;
spool off

clear;
SELECT count(1) instances, state ,substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1) as COMPOSITE from  composite_instance  
where (
substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1)='AssetManagement/MaximoInvTxnReceiverService' 
or substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1)='AssetManagement/MaximoInvTxnPublisherService' 
or substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1)='Finance/JDEInvTxnSubscriberService' 
or substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1)='Finance/JDEInvTxnUpdateService' )
and created_time > to_timestamp('23-FEB-12 15.00.54.809000000', 'DD-MON-RRHH24:MI:SS.FF')
group by substr(COMPOSITE_DN, 1, instr(COMPOSITE_DN, '!')-1) , state;

DBMS_OUTPUT.ENABLE(1000000);
SET AUTOTRACE ON
set autotrace traceonly
explain plan for ???
select * from table(DBMS_XPLAN.display); 

execute dbms_session.session_trace_enable
alter session set sql_trace=true;
set timing on;


write_line(TO_CHAR(sysdate, 'DD-MON-YYYY HH24:MI:SS') ||  ' 3');
grep ERRJMS_ERR_CR_QUEUE_PROD soa_server1.out|grep Q2|wc -l

grep ERRJMS_ERR_CR_TOPIC_PROD soa_server1.out|grep Topic2|wc -l
