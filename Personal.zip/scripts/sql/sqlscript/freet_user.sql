--freet only for ts 'CRP_USER_DATA' ;
SELECT    a.owner, a.table_name, TRUNC(sum(bytes)/1024/1024) Meg 
FROM
	(SELECT segment_name table_name, owner, bytes  
	FROM dba_segments  
	WHERE segment_type = 'TABLE'  
	UNION ALL  
	SELECT i.table_name, i.owner, s.bytes  
	FROM dba_indexes i, dba_segments s  
	WHERE s.segment_name = i.index_name  
	AND   s.owner = i.owner  
	AND   s.segment_type = 'INDEX'  
	UNION ALL  
	SELECT l.table_name, l.owner, s.bytes  
	FROM dba_lobs l, dba_segments s  
	WHERE s.segment_name = l.segment_name  
	AND   s.owner = l.owner  
	AND   s.segment_type = 'LOBSEGMENT'  
	UNION ALL  
	SELECT l.table_name, l.owner, s.bytes  
	FROM dba_lobs l, dba_segments s  
	WHERE s.segment_name = l.index_name  
	AND   s.owner = l.owner  
	AND   s.segment_type = 'LOBINDEX') a,   
    (select OWNER, SEGMENT_NAME ,  TABLESPACE_NAME    
    from dba_segments 
    where tablespace_name='CRP_USER_DATA')b
 where a.owner=b.owner and a.table_name = b.SEGMENT_NAME
GROUP BY a.table_name, a.owner 
HAVING SUM(bytes)/1024/1024 > 1  /* Ignore really small tables */ 
ORDER BY SUM(bytes) desc ; 
