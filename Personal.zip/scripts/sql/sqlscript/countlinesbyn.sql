select
     table_name,
    to_number(
     extractvalue(
       xmltype(
dbms_xmlgen.getxml('select count(*) c from '||table_name))
       ,'/ROWSET/ROW/C')) countnumber
   from user_tables
  where (iot_type != 'IOT_OVERFLOW'
 or    iot_type is null)
 order by table_name;
 