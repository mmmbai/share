select * from user_indexes where index_name like 'INDEX%'

CREATE INDEX  "INDEX4" ON  "CUBE_INSTANCE"
    (
      "MODIFY_DATE"
    );
CREATE INDEX  "INDEX6" ON  "CUBE_INSTANCE"
    (
      "CPST_INST_CREATED_TIME"
    );
CREATE INDEX ."INDEX9" ON "CUBE_INSTANCE"
    (
      "CMPST_ID"
    );
	
CREATE INDEX "INDEX13" ON "AUDIT_TRAIL"
    (
      "CIKEY"
    );
CREATE INDEX  "INDEX15" ON  "BPM_AUDIT_QUERY"
      (
        "COMPONENT_INSTANCE_ID"
      );	  
CREATE INDEX  "INDEX16" ON  "COMPOSITE_INSTANCE"
  (
    "CREATED_TIME"
  );  
CREATE INDEX "INDEX17" ON "REFERENCE_INSTANCE"
  (
    "CREATED_TIME"
  );
