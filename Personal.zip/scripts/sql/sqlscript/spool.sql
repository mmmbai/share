--set colsep ,
set pagesize 0   
set trimspool on 
set headsep off 
set linesize 5000 
set echo off
set feedback off
set sqlprompt ''
set wrap off

spool d:\vlo\out.csv;
select T1.PATH , T1.DOCUMENT_NAME, T1.DOCUMENT_TYPE  , T1.OBJECT_CUID,   T1.USER_NAME , T1.ACTION_NAME, T1.ACTION_TIME,
T2.REPORT_PATH ,UNIVERSE, T2.UNIVERSE_CONNECTION, T2.UNIVERSE_PATH
from T1
left join T2
on T1.DOCUMENT_NAME=T2.REPORT;
spool off
