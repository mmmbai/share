DBMS_OUTPUT.ENABLE(1000000);

set serveroutput on format word_wrapped; 
execute dbms_session.session_trace_enable
alter session set sql_trace=true;
set timing on;
set autotrace on explain (This works)

explain plan for count(*) total_instance from  composite_instance;
select * from table(DBMS_XPLAN.display);

execute dbms_stats.gather_table_stats(ownname => 'boss0817',tabname => 't_subscriberelations',estimate_percent => null ,method_opt => 'for all indexed columns' ,cascade => true);
