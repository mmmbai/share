--1. From OS process find sid
SELECT 
a.sid,
b.spid
FROM v$session a, v$process b
WHERE a.paddr = b.addr
and b.spid = 30245;


--2.From sid find sql text 
select a.num, b.sql_id ,  b.sql_text   from  
(
select   sql_id, count(1) num from v$active_session_history where session_id = '902' and  sample_time > sysdate - 1/24/6 group by sql_id
)a,
(  (select distinct SQL_ID ,SQL_TEXT    from v$sql )
    UNION 
    (select distinct SQL_ID ,SQL_TEXT    from v$sqltext                                              )
)b
where b.sql_id in a.sql_id


-----Following are misc----


select count(1)   from(select distinct SQL_ID ,SQL_TEXT    from v$sql  )

select count(1)   from v$sql  
select * 
from v$active_session_history where sql_id='8x8bcffgxdx01'



select * from v$session where SID = '232'
select  distinct sql_id from v$active_session_history where session_id = '778' and  sample_time > sysdate - 1/24

SELECT 
a.sid,
b.spid
FROM v$session a, v$process b
WHERE a.paddr = b.addr
and b.spid = 30245;

select a.num, b.sql_id ,  b.sql_text   from  
(
select   sql_id, count(1) num from v$active_session_history where session_id = '902' and  sample_time > sysdate - 1/24/6 group by sql_id
)a,
(select distinct SQL_ID ,SQL_TEXT    from v$sql )  b
where b.sql_id in a.sql_id





from v$sqltext



select   SQL_ID ,SQL_TEXT    from v$sql where SQL_ID='9xs9qw2d57tzv';


select   * from  V$SQLAREA  where SQL_ID='9xs9qw2d57tzv';


select   * from v$active_session_history where SQL_ID='9xs9qw2d57tzv';

@find_sql_long.sql







select   * from v$active_session_history where session_id = '902' and  sample_time > sysdate - 1/24/6 
select  SID, MACHINE,PORT from v$session where USERNAME = 'CRP_QAT_ADM' and  MACHINE = 'esbcqatadm01'




