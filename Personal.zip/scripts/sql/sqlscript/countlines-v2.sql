select
     table_name,
    to_number(
     extractvalue(
       xmltype(
dbms_xmlgen.getxml('select count(*) c from '||OWNER|| '.' || table_name))
       ,'/ROWSET/ROW/C')) countnumber
   from dba_tables
  where (iot_type != 'IOT_OVERFLOW'
 or    iot_type is null)
 and OWNER='CRP_TST_ADM'
 order by countnumber;
 