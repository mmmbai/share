set serveroutput on size 300000
--SET SERVEROUTPUT ON FORMAT WRAPPED


select * from dba_tablespaces

SELECT * FROM DATABASE_PROPERTIES where PROPERTY_NAME='DEFAULT_TEMP_TABLESPACE';
select TABLESPACE_NAME, BYTES_USED, BYTES_FREE from V$TEMP_SPACE_HEADER;

select TABLESPACE_NAME,
       BYTES_USED/1024/1024 USED(MB), 
	   BYTES_FREE/1024/1024 Free(MB)    from V$TEMP_SPACE_HEADER;
	   (BYTES_USED+BYTES_FREE)/1024/1024 TOTAL(MB), 
	   BYTES_USED/(BYTES_USED+BYTES_FREE)/1024/1024 USED




select count(1), state from composite_instance group by state



select * from dba_tablespaces
where TABLESPACE_NAME like 'DEV1%'

select count(1) from cube_instance
select count(1) from composite_instance

delete from cube_instance




select domain_name,composite_name,state,dlv_type,count(*) from dlv_message group by domain_name,composite_name,state,dlv_type order by domain_name,composite_name;

select dlv_message.domain_name,dlv_message.composite_name,dlv_message.state,composite_instance.state,dlv_message.ecid from dlv_message,composite_instance where dlv_message.ecid=composite_instance.ecid and dlv_message.composite_name='testError' and dlv_message.state=3;

update dlv_message set state=3 where ecid='b4abed1c78fb08c9:69b10b6c:13418270598:-8000-000000000013447f' and state=0;



spool d:/temp/test.spool;
select 'select count (1) ', TABLE_NAME , 'from ' ,TABLE_NAME  , ';' from user_tables;
spool off;
spool d:/temp/results.spool;
@d:/temp/test.spool;
spool off;




spool d:/temp/test.spool;
select 'delete   from ' ,TABLE_NAME  , ';' from user_tables;
spool off;
spool d:/temp/results1.spool;
@d:/temp/test.spool;
spool off;


