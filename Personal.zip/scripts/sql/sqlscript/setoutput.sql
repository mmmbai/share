set serveroutput on format wraped; 
 
 
begin
dbms_output.enable;
dbms_output.put_line('Hello oracle!');
end; 
 
 