select   listagg (port, '\|') WITHIN GROUP (ORDER BY port) enames  
from v$session where machine ='esbcsusapp03' and username='CRP_SUS_ADM_ALPHA'