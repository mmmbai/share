select xmltype(message).extract('/Message/Payload/Compressed[1]/text()','xmlns=http://www.iec.ch/TC57/2010/schema/message').getclobval() length
, message from Temp_Testing where  lower(message) like '%bai%'
