clear;
set serveroutput on;

DECLARE
   PROCEDURE myProc (dt1 IN VARCHAR2,dt2 IN VARCHAR2 default 'default' ) IS
   BEGIN
      DBMS_OUTPUT.PUT_LINE ('dt1 is ' || dt1 || ', dt2 is ' || dt2 );
   END;
BEGIN
   myProc ('one', 'two');
   myProc ('one');
   myProc (dt1=>'one', dt2=>'two');
   myProc (dt2=>'two', dt1=>'one' );
   myProc (dt1=>'one');   
END;
/