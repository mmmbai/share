--not work
set serveroutput on;
DECLARE
v_num  integer;
v_schema_name VARCHAR2(100);
v_str VARCHAR2(100);

v_Mbytes_alloc   integer;
v_Mbytes_max integer;

  BEGIN
   --select sys_context( 'userenv', 'current_schema' ) into v_schema_name from dual;
  --select 'CRP_QAT_EHL'  into v_schema_name from dual;
  select sum(bytes)/1024/1024 Kbytes_alloc, 
			  sum(greatest(bytes,maxbytes))/1024/1024 Kbytes_max into 	v_Mbytes_alloc,	v_Mbytes_max	   
	   from dba_data_files  where tablespace_name='CRP_QAT_EHL' group by tablespace_name;	   
	   select v_Mbytes_alloc, '  ',v_Mbytes_max into v_str from dual;
	   DBMS_OUTPUT.PUT_LINE(v_str);
  END;
  /
  exit;

