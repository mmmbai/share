EXECUTE DBMS_AQADM.DROP_QUEUE_TABLE (    queue_table   => 'B2B_BAM_QTAB'); 
EXECUTE DBMS_AQADM.DROP_QUEUE (    queue_name      => 'B2B_BAM_QUEUE'); 

select 'EXECUTE DBMS_AQADM.STOP_QUEUE ( ''' || name || ''');' from dba_queues where owner='LAB1_SOAINFRA'
select 'EXECUTE DBMS_AQADM.DROP_QUEUE ( ''' || name || ''',true);' from dba_queues where owner='LAB1_SOAINFRA'
select 'EXECUTE DBMS_AQADM.DROP_QUEUE_TABLE (  '''|| queue_table ||''',true);' from dba_queues where owner='LAB1_SOAINFRA'

select  name,queue_table,queue_type from dba_queues where owner='LAB1_SOAINFRA'