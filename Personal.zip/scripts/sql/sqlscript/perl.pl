print  "$size   ";
while(<MYFILE>) 
{
  $.=1;
  print $.;  

  # Print 'aa' either side of the value, so we can see where it split
  #foreach my $val (@values) {
    #print "${val}\n";
  #}
  #print  "$size   ";

  print $_;    
  $.=1
}


  my $data = "Becky\n\nAlcorn";

  my @values = split(' ',$data);

  # Print 'aa' either side of the value, so we can see where it split
  foreach my $val (@values) {
    print "aa${val}aa\n";
  }

