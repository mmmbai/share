set head off;
set serverout on FORMAT WRAPPED;
set feedback off ;
set linesize 1000;


declare 
info varchar(120);
ts_name varchar(100);
alloced_mb number;
max_gb number;
perc_1 number;

owner varchar(100);
table_name varchar(100);
mbytes number;
perc number;

cursor cur is 
SELECT    owner, table_name, TRUNC(sum(bytes)/1024/1024) Meg 
FROM
	(SELECT segment_name table_name, owner, bytes  
	FROM dba_segments  
	WHERE segment_type = 'TABLE'  
	UNION ALL  
	SELECT i.table_name, i.owner, s.bytes  
	FROM dba_indexes i, dba_segments s  
	WHERE s.segment_name = i.index_name  
	AND   s.owner = i.owner  
	AND   s.segment_type = 'INDEX'  
	UNION ALL  
	SELECT l.table_name, l.owner, s.bytes  
	FROM dba_lobs l, dba_segments s  
	WHERE s.segment_name = l.segment_name  
	AND   s.owner = l.owner  
	AND   s.segment_type = 'LOBSEGMENT'  
	UNION ALL  
	SELECT l.table_name, l.owner, s.bytes  
	FROM dba_lobs l, dba_segments s  
	WHERE s.segment_name = l.index_name  
	AND   s.owner = l.owner  
	AND   s.segment_type = 'LOBINDEX') 
WHERE owner ='CRP_SUS_EHL'
GROUP BY table_name, owner 
HAVING SUM(bytes)/1024/1024 > 1  /* Ignore really small tables */ 
ORDER BY SUM(bytes) desc ;

procedure show_space  
( p_segname in varchar2,
p_prec out number,
p_owner   in varchar2 default user,
p_type    in varchar2 default 'TABLE',
p_partition in varchar2 default NULL ) is
-- this procedure uses authid current user so it can query DBA_*
-- views using privileges from a ROLE and so it can be installed
-- once per database, instead of once per user that wanted to use it


    l_free_blks                 number;
    l_total_blocks              number;
    l_total_bytes               number;
    l_unused_blocks             number;
    l_unused_bytes              number;
    l_LastUsedExtFileId         number;
    l_LastUsedExtBlockId        number;
    l_LAST_USED_BLOCK           number;
    l_segment_space_mgmt        varchar2(255);
    l_unformatted_blocks number;
    l_unformatted_bytes number;
    l_fs1_blocks number; l_fs1_bytes number;
    l_fs2_blocks number; l_fs2_bytes number;
    l_fs3_blocks number; l_fs3_bytes number;
    l_fs4_blocks number; l_fs4_bytes number;
    l_full_blocks number; l_full_bytes number;
    l_used_block number;

begin
   -- this query is executed dynamically in order to allow this procedure
   -- to be created by a user who has access to DBA_SEGMENTS/TABLESPACES
   -- via a role as is customary.
   -- NOTE: at runtime, the invoker MUST have access to these two
   -- views!
   -- this query determines if the object is a ASSM object or not
   begin
      execute immediate
          'select ts.segment_space_management
             from dba_segments seg, dba_tablespaces ts
            where seg.segment_name      = :p_segname
              and (:p_partition is null or
                  seg.partition_name = :p_partition)
              and seg.owner = :p_owner
              and seg.tablespace_name = ts.tablespace_name'
             into l_segment_space_mgmt
            using p_segname, p_partition, p_partition, p_owner;
   exception
       when too_many_rows then
          dbms_output.put_line
          ( 'This must be a partitioned table, use p_partition => ');
          return;
   end;


   -- if the object is in an ASSM tablespace, we must use this API
   -- call to get space information, else we use the FREE_BLOCKS
   -- API for the user managed segments
   if l_segment_space_mgmt = 'AUTO'
   then
     dbms_space.space_usage
     ( p_owner, p_segname, p_type, l_unformatted_blocks,
       l_unformatted_bytes, l_fs1_blocks, l_fs1_bytes,
       l_fs2_blocks, l_fs2_bytes, l_fs3_blocks, l_fs3_bytes,
       l_fs4_blocks, l_fs4_bytes, l_full_blocks, l_full_bytes, p_partition);
/*
     p( 'Unformatted Blocks ', l_unformatted_blocks );
     p( 'FS1 Blocks (0-25) ', l_fs1_blocks );
     p( 'FS2 Blocks (25-50) ', l_fs2_blocks );
     p( 'FS3 Blocks (50-75) ', l_fs3_blocks );
     p( 'FS4 Blocks (75-100)', l_fs4_blocks );
     p( 'Full Blocks        ', l_full_blocks );
  */ 
  l_used_block := l_unformatted_blocks*0;
  l_used_block :=l_used_block+l_fs1_blocks*0.875;
  l_used_block :=l_used_block+l_fs2_blocks*0.675;
  l_used_block :=l_used_block+l_fs3_blocks*0.375;
  l_used_block :=l_used_block+l_fs4_blocks*0.175;
  l_used_block :=l_used_block+l_full_blocks*1;
end if;

-- and then the unused space API call to get the rest of the
-- information
dbms_space.unused_space
( segment_owner     => p_owner,
    segment_name      => p_segname,
    segment_type      => p_type,
    partition_name    => p_partition,
    total_blocks      => l_total_blocks,
    total_bytes       => l_total_bytes,
    unused_blocks     => l_unused_blocks,
    unused_bytes      => l_unused_bytes,
    LAST_USED_EXTENT_FILE_ID => l_LastUsedExtFileId,
    LAST_USED_EXTENT_BLOCK_ID => l_LastUsedExtBlockId,
    LAST_USED_BLOCK => l_LAST_USED_BLOCK );
/*
    p( 'Total Blocks', l_total_blocks );
    p( 'Total Bytes', l_total_bytes );
    p( 'Total MBytes', trunc(l_total_bytes/1024/1024) );
    p( 'Unused Blocks', l_unused_blocks );
    p( 'Unused Bytes', l_unused_bytes );
    p( 'Last Used Ext FileId', l_LastUsedExtFileId );
    p( 'Last Used Ext BlockId', l_LastUsedExtBlockId );
    p( 'Last Used Block', l_LAST_USED_BLOCK );
    */
    p_prec:=l_used_block/l_total_blocks*100;
    --p( 'Used prec', l_used_block/l_total_blocks*100 );
    
end;




begin
DBMS_OUTPUT.ENABLE(1000000);
select 'Current connection is ' ||uu.username || '@' || in1.instance_name connectionInfo into info from user_users uu, v$instance in1 ;

dbms_output.put_line(info );
select  tablespace_name ,
        round(sum(bytes)/1024/1024) ,
        round(sum(greatest(bytes,maxbytes))/1024/1024/1024) ,
        round(sum(bytes)/sum(greatest(bytes,maxbytes))*100,1)  
        into ts_name,alloced_mb,max_gb,perc_1
           from sys.dba_data_files
     where tablespace_name =(select default_tablespace from user_users)
     group by tablespace_name ;
dbms_output.put_line('Table Space details');  
dbms_output.put_line(rpad('TS_NAME',20,' ')  || rpad('ALLOCED_MB',20,' ')|| rpad('MAX_GB',20,' ')|| rpad('USED Percentage',20,' ') ); 
dbms_output.put_line(rpad(ts_name,20,' ')  || rpad(alloced_mb,20,' ')|| rpad(max_gb,20,' ')|| rpad(perc_1||'%',20,' ') );       
--dbms_output.new_line;
dbms_output.put_line('Details of table bigger than 1MB ');
dbms_output.put_line(rpad('Table Name',40,' ')  ||rpad('Alloced MB',20,' ')|| rpad('Used Percentage',20,' ') );
open cur;
loop
 fetch cur into owner, table_name,mbytes;
 exit when cur%notfound;
 show_space(table_name, perc,owner);
 dbms_output.put_line(rpad(table_name,40,'.')  ||rpad(mbytes,20,'.')|| round(perc)||'%');
 end loop;
 close cur;
END;
/
exit;

