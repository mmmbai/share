ALTER TABLE LOG_ENTRY_UPGRADED enable row movement;
ALTER TABLE LOG_ENTRY_UPGRADED shrink space CASCADE;
ALTER TABLE LOG_ENTRY_UPGRADED disable row movement;

ALTER TABLE LOG_ENTRY  enable row movement;
ALTER TABLE LOG_ENTRY  shrink space CASCADE;
ALTER TABLE LOG_ENTRY  disable row movement;

ALTER TABLE EXCEPTIONREC  enable row movement;
ALTER TABLE EXCEPTIONREC  shrink space CASCADE;
ALTER TABLE EXCEPTIONREC  disable row movement;

ALTER TABLE logging  enable row movement;
ALTER TABLE logging  shrink space CASCADE;
ALTER TABLE logging  disable row movement;

ALTER TABLE log  enable row movement;
ALTER TABLE log  shrink space CASCADE;
ALTER TABLE log  disable row movement;






ALTER TABLE LOG move;

ALTER INDEX DOC_STORE_PK rebuild online;
ALTER TABLE XML_DOCUMENT MODIFY lob (DOCUMENT) (shrink space);


ALTER TABLE LOG MODIFY lob (LOGMESSAGES) (shrink space);
ALTER TABLE LOG move lob(LOGMESSAGES) store as (tablespace CRP_USER_DATA)


set serveroutput on;
exec show_space('AUDIT_TRAIL')

Analyze index index4 validate structure;
select height,DEL_LF_ROWS/LF_ROWS from index_stats; --(height>=4 or DEL_LF_ROWS/LF_ROWS>0.2 we need rebuild index)


DLV_SUBSCRIPTION

execute DBMS_STATS.GATHER_SCHEMA_STATS('<schema_name>',100,FALSE,'FOR ALL COLUMNS SIZE 1',NULL,'DEFAULT', TRUE)

execute DBMS_STATS.GATHER_TABLE_STATS('soa_soainfra', 'AUDIT_TRAIL',NULL,100,TRUE,'FOR ALL COLUMNS SIZE 1',NULL,'DEFAULT',TRUE);











