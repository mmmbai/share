select user from dual;

select * from v$session where SCHEMANAME=user;

gv$active_session_history
v$active_session_history
 v$sqlarea
v$session
 select * from v$session
 --GET sessionid
select userenv('sessionid') from dual;
--GET CURRENT current_schema
select sys_context( 'userenv', 'current_schema' )  from dual;

--get recent sql
SELECT h.sql_id,
        h.user_id,
       s2.username,
       s1.sql_text
FROM  v$active_session_history h,
      v$sqlarea s1,
      v$session s2
WHERE h.sample_time > sysdate -1/(24*60)
AND   h.sql_id = s1.sql_id
AND   h.user_id = s2.USER#
AND   'LAB2_MDS'=s2.USERNAME
--get sql by sql_id
SELECT
   a.sql_text,
   b.name,
   b.position,
   b.datatype_string,
   b.value_string
FROM 
  v$sql_bind_capture b, 
  v$sqlarea          a 
WHERE 
   b.sql_id = 'bm3tuv506kk3a' 
AND
   b.sql_id = a.sql_id;
   
   
--get full sql by sql id   
select  sql_text from v$sqltext sql
    where sql.sql_id='18qm915f1v270'
    order by piece asc;
	

select sql_id,count(*),
round(count(*)/sum(count(*)) over (),2) pctload
from v$active_session_history
where sample_time > sysdate -5/(24*60)
and session_type <> 'BACKGROUND'
and session_state= 'ON CPU'
group by sql_id
order by count(*) desc;

 
 --get the link from a syno
 select * from 
(
 select  object_name objname, object_type, 'my object' details, 1 resolveOrder 
  from user_objects
  where object_type not like 'SYNONYM'
 union all
 select synonym_name obj , 'my synonym', table_owner||'.'||table_name, 2 resolveOrder
  from user_synonyms
 union all
 select  synonym_name obj , 'public synonym', table_owner||'.'||table_name, 3 resolveOrder
  from all_synonyms where owner = 'PUBLIC'
)
where objname like upper('DBA%')
--get all the table you can query
SELECT PRIVILEGE , TABLE_NAME
FROM ALL_TAB_PRIVS_RECD
WHERE PRIVILEGE = 'SELECT'
AND OWNER = 'SYS'
AND TABLE_NAME like 'DBA%'

SELECT * FROM SESSION_PRIVS;

select * from user_sys_privs; 
select * from user_tab_privs;
SELECT * FROM user_role_privs;

DBA_ROLE_PRIVS - Roles granted to users and roles
ROLE_ROLE_PRIVS - Roles which are granted to roles
ROLE_SYS_PRIVS - System privileges granted to roles
ROLE_TAB_PRIVS - Table privileges granted to roles






explain plan for 
SELECT /*+INDEX(CUBE_INSTANCE, CI_ECID)  */* FROM CUBE_INSTANCE WHERE ((COMPONENTTYPE = 'bpmn' )  
AND (ECID = '216c086befea54ee:72d35ad4:13b2613f2ee:-7ffc-000000000039ae93' )) ORDER BY CREATION_DATE DESC   ;


SELECT  * FROM CUBE_INSTANCE WHERE ((COMPONENTTYPE = 'bpmn' )  
AND (ECID = '216c086befea54ee:72d35ad4:13b2613f2ee:-7ffc-000000000039ae93' )) ORDER BY CREATION_DATE DESC   ;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

show parameters optimizer_mode
alter session set optimizer_mode=CHOOSE;
set autotrace off
SELECT_CATALOG_ROLE
SELECT    * FROM REFERENCE_INSTANCE
WHERE (ECID = '216c086befea54ee:72d35ad4:13b2613f2ee:-7ffc-000000000039ae93' ) ORDER BY CREATED_TIME DESC   ;


select count(*) from v$process --当前的连接数  
select value from v$parameter where name = 'processes' --数据库允许的最大连接数  
  
修改最大连接数:  
alter system set processes = 300 scope = spfile;  

