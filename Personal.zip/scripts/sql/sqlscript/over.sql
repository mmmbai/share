--set colsep ,
set pagesize 0   
set trimspool on 
set headsep off 
set linesize 5000 
set echo off
set feedback off
set sqlprompt ''
set wrap off

column subject_area format a30
column WORKFLOW_NAME format a30


spool /apps/tibco/bin/getruns.txt;
SELECT 
  subject_area,
	WORKFLOW_NAME,
	RUN_ERR_CODE,
    END_TIME
    FROM 
 (SELECT 
 subject_area,
	WORKFLOW_NAME,
	RUN_ERR_CODE,
    END_TIME,
    row_number() over(partition by WORKFLOW_NAME order by END_TIME desc) rid
    from REP_WFLOW_RUN
    )
    where rid=1;
spool off
exit
