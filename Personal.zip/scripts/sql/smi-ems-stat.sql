SELECT emsinstancemetrics.sample_time, consumer_count, ENVIRONMENT, pending_msg_count,
inbound_msg_rate, outbound_msg_rate, inbound_total_msgs,  outbound_total_msgs 
FROM crp_prd_cle.emsdestinationmetrics  
JOIN crp_prd_cle.emsinstancemetrics 
on crp_prd_cle.emsdestinationmetrics.SAMPLE_ID = crp_prd_cle.emsinstancemetrics.SAMPLE_ID 
WHERE sample_time between  
'03-May-14 04.59.01 AM' and '03-May-14 10.00.01 AM' 
and DESTINATION_NAME like 'bchydro.esb.prd.crp.meterdatasubscription.mdms.itronmeterreadings' 
order by sample_time asc;