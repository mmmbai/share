param (
    [Parameter(Mandatory=$true)]
    [string]$Environment
)

# Enable verbose output
$VerbosePreference = "Continue"


# Define the necessary variables
$TenantId = "05c5c963-c839-4c9e-b5c1-b51b3799ac37"
$SmtpFrom = "l7ssg@worksafebc.com"
$SmtpTo = "l7ssg@worksafebc.com"
$SmtpBody = "<html><body><p>Following list of named values are not used in any policies. Please check if these named values are used in any of the policy fragments before deleting them</p><ul>"
$EmailSubjectTemplate = "APIM Unused Named Values List"

# Set the subscription ID based on the environment
if ($Environment -eq "DV") {
    $SubscriptionId = "e0279acf-930e-4937-abbf-f45670343bcf"
} else {
    $SubscriptionId = "31aa985b-4df3-43ab-87d3-92153f79500b"
}

# SendGrid variables
$SecretName = "SendGrid-Email-ApiKey"
$SendGridUrl = "https://api.sendgrid.com/v3/mail/send"

# Function to retrieve Environment-specific variables
function Get-EnvironmentVariable {
    param (
        [string]$VariableName
    )
    return Get-AutomationVariable -Name "$($Environment)_$VariableName"
}

# Retrieve Environment-specific variables
$ResourceGroupName = Get-EnvironmentVariable -VariableName 'ResourceGroupName'
$ServiceName = Get-EnvironmentVariable -VariableName 'APIMServiceName'
$VaultName = Get-EnvironmentVariable -VariableName 'KeyVaultName'
# Add the environment-specific prefix to EmailSubject
$SmtpSubject = "$Environment - $EmailSubjectTemplate"



Write-Output "Started checking.. "
Connect-AzAccount -Identity
Set-AzContext -SubscriptionId $SubscriptionId -TenantId $TenantId

$ApiMgmtContext = New-AzApiManagementContext -ResourceGroupName $ResourceGroupName -ServiceName $ServiceName



# Get all named values
Write-Output "Before getting all Named Values .. "
$allNamedValues = Get-AzApiManagementNamedValue -Context $ApiMgmtContext
$namedValuesNames = @()
$usedNamedValues = @()
foreach ($namedValue in $allNamedValues){
	$namedValuesNames += $namedValue.Name
}

Write-Output "After getting all Named Values .. "

# Get global policy and pull used named values
Write-Output "Before checking in Global Policy.. "
$globalPolicy = Get-AzApiManagementPolicy -Context $ApiMgmtContext
Write-Output "Global policy retrieved"
# Check if the policy contains any named values
foreach ($namedValue in $namedValuesNames) {
	if ($globalPolicy -Match $namedValue) {
		$usedNamedValues += $namedValue
		#$namedValuesNames.Remove($namedValue)
	}
}
Write-Output "After checking in Global Policy.. "

# Get all products and pull used named values in produt policies
Write-Output "Before checking in Product Policies .. "
$allProducts = Get-AzApiManagementProduct -Context $ApiMgmtContext

foreach ($product in $allProducts) {
	$productPolicy = Get-AzApiManagementPolicy -Context $ApiMgmtContext -ProductId $product.ProductId
	Write-Output "Product: $($product.ProductId)"
	# Check if the policy contains any named values
	foreach ($namedValue in $namedValuesNames) {
		if ($productPolicy -Match $namedValue) {
			$usedNamedValues += $namedValue
			#$namedValuesNames.Remove($namedValue)
		}
	}
}
Write-Output "After checking in Global Policy.. "

# Get all APIs and pull used named values in API policies
Write-Output "Before checking in API and Operations Policies .. "
$apis = Get-AzApiManagementApi -Context $ApiMgmtContext

# Get all API operations
foreach ($api in $apis) {
	$apiOperations = @()
	$policy = ""
	$policy = Get-AzApiManagementPolicy -Context $ApiMgmtContext -ApiId $api.ApiId
	
    $operations = Get-AzApiManagementOperation -Context $ApiMgmtContext -ApiId $api.ApiId
    $apiOperations += $operations.OperationId
	foreach ($operation in $apiOperations) {
		# Get the policy of the operation
		$policy = $policy + (Get-AzApiManagementPolicy -Context $ApiMgmtContext -ApiId $api.ApiId -OperationId $operation)
		Write-Output "$($api.ApiId) - $($operation)"
	}
	# Check if the policy contains any named values
	foreach ($namedValue in $namedValuesNames) {
		if ($policy -Match $namedValue) {
			$usedNamedValues += $namedValue
			#$namedValuesNames.Remove($namedValue)
		}
	}
}

$usedNamedValues = $usedNamedValues | select -Unique
Write-Output "Retrieved all Used Named values .."

# Get the list of unused named values
$unusedNamedValues = @()
$unusedNamedValues = $allNamedValues | Where-Object { $usedNamedValues -notcontains $_.Name }

#$unusedNamedValuesNames = @() 
foreach ($unUsed in $unusedNamedValues){
	#$unusedNamedValuesNames += $unUsed.Name
	$script:SmtpBody += "<li>$($unUsed.Name)</li>"
}
Write-Output "Retrieved all Un-Used Named values .."

#$script:SmtpBody += "<li>($unusedNamedValuesNames)</li>"

$SmtpBody += "</ul></body></html>"
Write-Output "Final SmtpBody content: $script:SmtpBody"

# Check if the email body contains any <li> elements
if ($script:SmtpBody -match "<li>") {
    # Retrieve SendGrid API key from Azure Key Vault
    $SendGridApiKey = Get-AzKeyVaultSecret -VaultName $VaultName -Name $SecretName -ErrorAction Stop -AsPlainText

    # Verify that the SendGrid API key is not null or empty
    if (![string]::IsNullOrEmpty($SendGridApiKey)) {
        Write-Output "SendGrid API key retrieved successfully."
    } else {
        Write-Error "Failed to retrieve SendGrid API key."
        exit
    }

    # Create the email message payload for SendGrid
    $EmailMessage = @{
        personalizations = @(
            @{
                to = @(
                    @{
                        email = $SmtpTo
                    }
                )
            }
        )
        from = @{
            email = $SmtpFrom
        }
        subject = $SmtpSubject
        content = @(
            @{
                type = "text/html"
                value = $script:SmtpBody
            }
        )
    }

    # Convert the email message payload to JSON
    $EmailMessageJson = $EmailMessage | ConvertTo-Json -Depth 4

    # Send the email using SendGrid API
    try {
        if (-not $SendGridApiKey) {
            throw "SendGrid API key is missing."
        }
        
        $Headers = @{
            "Authorization" = "Bearer $SendGridApiKey"
            "Content-Type"  = "application/json"
        }

        $Response = Invoke-RestMethod -Method Post -Uri $SendGridUrl -Headers $Headers -Body $EmailMessageJson
        Write-Output "Email sent successfully."
    } catch {
        Write-Output "Failed to send email: ${_}"
        Write-Output "Exception details: ${_.Exception.Message}"
        Write-Output "Inner exception: ${_.Exception.InnerException}"
    }
} else {
    Write-Output "No Unused named values found, no email sent"
}
