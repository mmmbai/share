# This script creates the Product if not existing. Add APIs to the Product. Create Subscritpion if not existing.
# One Product can have multiple APIs. So APIs are seperate by ":". Each part in APIs is an apiID
# If the subscription key is already in the keyvault secret, update it if the key is changed, otherwise do nothing.
param
(	
	# Resource Group Name
	[Parameter(Mandatory=$true)]
    [String] $RGName,

    # APIM Service Name
    [Parameter(Mandatory = $true)]
    [String] $ServiceName,
   
    # Key Vault. KeyVault and Secret are operational. If doesn't provied, it means it doesn't use KeyVault
    [String] $keyVault,

    # Key Vault Secret
    [String] $secret,

    # Environment. It's used to update keyvault name to match the environment. 
    # example: DV-DV-APIMGMT01-KV will updated to AS-SY-APIMGMT01-KV, or AS-ST-APIMGMT01-KV, or AS-PR-APIMGMT01-KV, based on the env
    # The values: Dev, Sys, Stg and Prd
    [Parameter(Mandatory = $true)]
    [String] $Env
)
	
#create APIM context
$apimContext = New-AzApiManagementContext -ResourceGroupName $RGName -ServiceName $ServiceName

# get the secret from the keyvault
# first, get the correct keyvault name based on the environment
if($Env -eq "Sys") { $KeyVault = $KeyVault.ToUpper().Replace("DV-DV","AS-SY") }
if($Env -eq "Stg") { $KeyVault = $KeyVault.ToUpper().Replace("DV-DV","AS-ST") }
if($Env -eq "Prd") { $KeyVault = $KeyVault.ToUpper().Replace("DV-DV","AS-PR") }

$ExistingSecret = Get-AzKeyVaultSecret -VaultName $keyVault -Name $secret
#Secret exists. Update it if the value is different from the value in APIM subscription
$secretInPlainText = $ExistingSecret.SecretValue | ConvertFrom-SecureString -AsPlainText
Write-Host 'secret exists:'	    $secretInPlainText






