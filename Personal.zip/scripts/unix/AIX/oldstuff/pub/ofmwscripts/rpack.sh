#!/usr/bin/env  bash
#######################################################################
#  This shell script is called from WLST with the following formats:  #
#  (1) Use this script as a command line utility:                     #
#      repack -i ${1}  ${2}                                           #
#                                                                     #
#      Where, ${1} is the jar file current name                       #
#             ${2} is the jar file name after re-jar                  #
#      The current working folder is the target folder as default.    #
#  (2) Use this script from other script                              #
#      repack ${1}  ${2} ${3}                                         #
#                                                                     #
#      Where, ${1} is the Home folder of the target jar file          #
#             ${2} is the jar file name                               #
#             ${3} is the working folder                              #
#      The existing jar file is to be written, so the file name will  #
#      be the same as before.                                         #
#                                                                     #
#  Created by: Richard Wang                                           #
#  Created on: Jan 18, 2012                                           #
#######################################################################
#
# set -x
TARGETDIR='./testsuites'

if [ ${1} == "-i" ] ; then 
    x=${2}
    WORKINGDIR="/tmp/"${x%.jar}
    DEPLOYJARHOME=`pwd`
    DEPLOYJAR=${2}
else
    WORKINGDIR=${3}
    DEPLOYJARHOME=${1}
    DEPLOYJAR=${2}
fi

# Delete working directory first if exist
echo $PWD
if [ -d $WORKINGDIR ] ; then 
   echo "delete $WORKINGDIR"
   rm -rf $WORKINGDIR
   echo "Deleted"
fi

#Create working directory again
mkdir -p $WORKINGDIR

#Change to the working directory
cd $WORKINGDIR

echo $PWD
# move the target jar file to the working directory
if [ -e $DEPLOYJARHOME/$DEPLOYJAR ] ; then 
   cp $DEPLOYJARHOME/$DEPLOYJAR ./
else
   echo "No target .sar (jar) file found in the project"
   exit 100
fi

# Extract
jar xf $DEPLOYJAR

# Rename old jar
if [ -e $DEPLOYJAR ] ; then 
   rm $DEPLOYJAR
   echo "Old $DEPLOYJAR has been removed"
fi

# Remove testsuites if exist
if [ -d $TARGETDIR ] ; then 
   rm -rf $TARGETDIR
   echo "$TARGETDIR has been removed"
fi

# Re-jar all back in the jar file without default manifest
jar cMf $DEPLOYJAR ./*

# move the target jar file back to the original place
mv $DEPLOYJARHOME/$DEPLOYJAR $DEPLOYJARHOME/$DEPLOYJAR"_bak"
cp $DEPLOYJAR $DEPLOYJARHOME/$DEPLOYJAR
# echo "Again confirm the current working directory:" `pwd`
cd ..
echo "Delete ${WORKINGDIR}"
rm -rf $WORKINGDIR
echo "Done"
exit 0

