#!/usr/bin/bash
#set -x

EXPECTED_ARGS=1
echo '\e[1;31m'
echo "---------------------------------------------------------------------------------"
echo " For example, if you want to run this script for PROD, you need to login to      "
echo " iv00076p.cenovus.com, change your working directory to /ofmwscript, then invoke "
echo " stopLiveLinkComposites.sh PROD                                                          "
echo "                                                                                 "
echo " Created on july 10, 2013                                                         "
echo "---------------------------------------------------------------------------------"
echo '\e[0m'

if [ $# -ne $EXPECTED_ARGS ]
then
  echo "Usage: `basename $0` {arg}"
  exit 100
fi
echo "Target environment is " $1

startComposite.py -e $1 -a "LivelinkFileHandlerServices,1.0,True,True,CommonServices"
startComposite.py -e $1 -a "LivelinkFolderCheckService,1.0,True,True,CommonServices"
startComposite.py -e $1 -a "LivelinkCommonService,1.0,True,True,CommonServices"
startComposite.py -e $1 -a "LiveLinkService,1.0,True,True,CommonServices"
startComposite.py -e $1 -a "SCMLivelinkRFIService,1.0,True,True,SCM"
startComposite.py -e $1 -a "SCMLivelinkPOService,1.0,True,True,SCM"
startComposite.py -e $1 -a "SCMMediaObjectService,1.0,True,True,SCM"
startComposite.py -e $1 -a "SCMDocumentCtlService,1.0,True,True,SCM"

exit
~
~

