#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : runDeploy.py  appHome [targetServer]
# Description: This script is to perform deployment task based on the properties file in 
#              which all composite applications is defined.
# Created by : Richard Wang
# Date       : Sep 6, 2011
# Updated    : Jan 16, 2012
#
###############################################################################################
import re
import sys
import os
import os.path
import commands
import random
import wlstwrapper as ww
from oracle.fabric.management.deployedcomposites import CompositeManager
from time import gmtime, strftime, localtime

execfile("/ofmwscripts/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script only function with the following prerequisites:
           [1] There must be an application created by JDeveloper;
           [2] There must be composites.properties file in which 
               all projects need to be deployed in this application 
               have to be defined with deployment requirements.
           [3] The name of target SAR(jar) file must be a regulated name
               grenated based on project name.

         Usage: runDdeploy.py [-r] -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
            -r: re-pack the SAR(jar) file before deploying for clean-up,
                if no re-pack needed, don't use this option.
'''

# Check parameters
repack = False
targetServer = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-r':
        repack = True
        args = args[1:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

# Lust all deployed composite applications for checking if we need to 
# undeploy prior to deploy.
deployedCompos = None
deployedCompList = []

print "Target Server:" + targetServer
serverUrl = getServerHTTPUrl(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

# Set loop counter
for loop in range(100):
    print ( ww.bcolors.WARNING + "Loop=>" + ww.bcolors.ENDC)
    print loop
    ow = true
    fd = true
    myTime = strftime("Before Undeploy----------------------------------%a, %d %b %Y %H:%M:%S ", localtime())
    print ( ww.bcolors.RED + myTime + ww.bcolors.ENDC )
    sca_undeployComposite(serverUrl, 
                       "JmsPub", 
                       "1.0", 
                       user=os.getenv('un'), 
                       password=os.getenv('pw'), 
                       partition="TestTopic")
    myTime = strftime("After Undeploy and Before Deploy-----------------%a, %d %b %Y %H:%M:%S", localtime())
    print ( ww.bcolors.RED + myTime + ww.bcolors.ENDC )

    sca_deployComposite(serverUrl, 
                        "/home/oraclesoa/appDock/TQA/TestTopic/sca_JmsPub_rev1.0.jar", 
                        ow, 
                        user=os.getenv('un'),
                        password=os.getenv('pw'),
                        forceDefault=fd, 
                        partition="TestTopic" )
    myTime =  strftime("After Deploy-------------------------------------%a, %d %b %Y %H:%M:%S", localtime())
    print ( ww.bcolors.RED + myTime + ww.bcolors.ENDC )
    

print "Done"

