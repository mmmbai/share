#!/usr/bin/bash
#set -x

EXPECTED_ARGS=1
echo '\e[1;31m'
echo "---------------------------------------------------------------------------------"
echo " This script must be run from the same machine where the Scheduler residents     "
echo " For example, if you want to run this script for PROD, you need to login to      "
echo " iv00076p.cenovus.com, change your working directory to /ofmwscript, then invoke "
echo " fixJMSTopics.sh PROD                                                      "
echo "                                                                                 "
echo " Created by chandra rai                                                         "
echo " Created on Aug 09, 2013                                                         "
echo "---------------------------------------------------------------------------------"
echo '\e[0m'

if [ $# -ne $EXPECTED_ARGS ]
then
  echo "Usage: `basename $0` {arg}"
  exit 100
fi
echo "Target environment is " $1

cd /ofmwscripts

#stopComposite.py -e $1 -a "MaximoExRateSubscriberService,1.0,True,True,AssetManagement"
stopComposite.py -e $1 -a "JDEPODBPublisher,1.0,True,True,Finance"
#stopComposite.py -e $1 -a "JDEInvTxnSubscriberService,1.2,True,True,Finance"
stopComposite.py -e $1 -a "MaximoChartOfAccountsDBPublisher,1.1,True,True,AssetManagement"
stopComposite.py -e $1 -a "MaximoCostCentreDBPublisher,1.1,True,True,AssetManagement"
stopComposite.py -e $1 -a "PASMasterDataAddressBookDBPublisher,1.0,True,True,Finance"
stopComposite.py -e $1 -a "PASMasterDataCostCenterDBPublisher,1.0,True,True,Finance"
stopComposite.py -e $1 -a "PASMasterDataDivisionOfInterestDBPublisher,1.0,True,True,Finance"
#stopComposite.py -e $1 -a "MaximoGLTransactionSubscriberService,1.1,True,True,AssetManagement"
#stopComposite.py -e $1 -a "MaximoPOInvoicePaymentSubscriberService,1.1,True,True,AssetManagement"
#stopComposite.py -e $1 -a "MaximoPOInvoiceReceiptSubscriberService,1.1,True,True,AssetManagement"
stopComposite.py -e $1 -a "MaximoVendorJMSToDBTransferService,1.0,True,True,AssetManagement"
stopComposite.py -e $1 -a "JDEWODBPublisher,1.1,True,True,Finance"
stopComposite.py -e $1 -a "CommonCallbackService,1.2,True,True,CommonServices"
stopComposite.py -e $1 -a "UpdateJDEFXRatesTable,1.0,True,True,Marketing"
stopComposite.py -e $1 -a "JDEExRatePublisherService,1.0,True,True,Finance"
stopComposite.py -e $1 -a "SendNotificationService,1.5,True,True,CommonServices"


sleep 60

#startComposite.py -e $1 -a "MaximoExRateSubscriberService,1.0,True,True,AssetManagement"
startComposite.py -e $1 -a "JDEPODBPublisher,1.0,True,True,Finance"
#startComposite.py -e $1 -a "JDEInvTxnSubscriberService,1.2,True,True,Finance"
startComposite.py -e $1 -a "MaximoChartOfAccountsDBPublisher,1.1,True,True,AssetManagement"
startComposite.py -e $1 -a "MaximoCostCentreDBPublisher,1.1,True,True,AssetManagement"
startComposite.py -e $1 -a "PASMasterDataAddressBookDBPublisher,1.0,True,True,Finance"
startComposite.py -e $1 -a "PASMasterDataCostCenterDBPublisher,1.0,True,True,Finance"
startComposite.py -e $1 -a "PASMasterDataDivisionOfInterestDBPublisher,1.0,True,True,Finance"
#startComposite.py -e $1 -a "MaximoGLTransactionSubscriberService,1.1,True,True,AssetManagement"
#startComposite.py -e $1 -a "MaximoPOInvoicePaymentSubscriberService,1.1,True,True,AssetManagement"
#startComposite.py -e $1 -a "MaximoPOInvoiceReceiptSubscriberService,1.1,True,True,AssetManagement"
startComposite.py -e $1 -a "MaximoVendorJMSToDBTransferService,1.0,True,True,AssetManagement"
startComposite.py -e $1 -a "JDEWODBPublisher,1.1,True,True,Finance"
startComposite.py -e $1 -a "CommonCallbackService,1.2,True,True,CommonServices"
startComposite.py -e $1 -a "UpdateJDEFXRatesTable,1.0,True,True,Marketing"
startComposite.py -e $1 -a "JDEExRatePublisherService,1.0,True,True,Finance"
startComposite.py -e $1 -a "SendNotificationService,1.5,True,True,CommonServices"

exit
