#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : stopComposite.py
# Description: This script is to stop one specific deployed composites
# Created by : Richard Wang
# Created Date : July 12, 2011
# Modified Date: Oct, 26 2012
#
###############################################################################################
import re
import sys
import os.path
import commands
import wlstwrapper as ww
from oracle.fabric.management.deployedcomposites import CompositeManager
execfile("/ofmwscripts/wlstCustomUtils.py")

deployedCompos = None
compositesQueue = list()

# Check parameters
targetServer = ''
compositeName = ''
compositeRev = ''
part = ''

args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]

    elif current_arg == '-a':
        print "args[1]=" , args[1]
        compositesQueue.append(args[1])
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server?" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
# Connect to the AdminServer
print "Target Server:" + targetServer

serverUrl = getServerHTTPUrl(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', serverUrl)
    if matchObj:  
        hostAddr = matchObj.group(1)
        hostPort = matchObj.group(2)
        # print "Target server host=", hostAddr 
        # print "Target server port=", hostPort
        
        try:
            # Get composite list from compositesList file
            for i in range(len(compositesQueue)):
                oneComposite = compositesQueue.pop()
                print oneComposite
                propList = oneComposite.split(",")
                compositeName = os.path.basename(propList[0])
                compositeRev = propList[1]
                part = propList[4]
                sca_stopComposite(hostAddr, 
                                hostPort, 
                                os.getenv('un'), 
                                os.getenv('pw'), 
                                compositeName, 
                                compositeRev,
                                partition=part)
        except Exception, detail:
               print 'Exception:', detail
               sys.exit()
    else:
        pass
exit()
