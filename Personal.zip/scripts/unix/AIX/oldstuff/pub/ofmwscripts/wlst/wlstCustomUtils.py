import sys, threading, commands, re, socket
from java.lang import Thread

###################PROD####################################
prodAServerT3Url = "t3://iv00076p.cenovus.com:7001"
prodSOAServer1Name = "soa_server1"
prodMServer1T3Url = "t3://iv00076p.cenovus.com:8001"
prodMServer1HTTPUrl = "http://iv00076p.cenovus.com:8001"
prodSOAServer2Name = "soa_server2"
prodMServer2T3Url = "t3://iv00077p.cenovus.com:8001"
prodMServer2HTTPUrl = "http://iv00077p.cenovus.com:8001"

###################TQA#####################################
tqaAServerT3Url = "t3://iv00094p.cenovus.com:7001"
tqaSOAServer1Name = "soa_server1"
tqaMServer1T3Url = "t3://iv00094p.cenovus.com:8001"
tqaMServer1HTTPUrl = "http://iv00094p.cenovus.com:8001"
tqaSOAServer2Name = "soa_server2"
tqaMServer2T3Url = "t3://iv00095p.cenovus.com:8001"
tqaMServer2HTTPUrl = "http://iv00095p.cenovus.com:8001"

###################TST#####################################
tstAServerT3Url = "t3://iv00045p.cenovus.com:7001"
tstSOAServer1Name = "soa_server1"
tstMServer1T3Url = "t3://iv00045p.cenovus.com:8001"
tstMServer1HTTPUrl = "http://iv00045p.cenovus.com:8001"
tstSOAServer2Name = "soa_server2"
tstMServer2T3Url = "t3://iv00045p.cenovus.com:9001"
tstMServer2HTTPUrl = "http://iv00045p.cenovus.com:9001"

###################DEV1####################################
dev1AServerT3Url = "t3://iv00047p.cenovus.com:7001"
dev1SOAServer1Name = "soa_server1"
dev1MServer1T3Url = "t3://iv00047p.cenovus.com:8001"
dev1MServer1HTTPUrl = "http://iv00047p.cenovus.com:8001"

###################DEV2####################################
dev2AServerT3Url = "t3://iv00048p.cenovus.com:7001"
dev2SOAServer1Name = "soa_server1"
dev2MServer1T3Url = "t3://iv00048p.cenovus.com:8001"
dev2MServer1HTTPUrl = "http://iv00048p.cenovus.com:8001"
###################LAB ####################################
labAServerT3Url = "t3://iv00046p.cenovus.com:7001"
labSOAServer1Name = "soa_server1"
labMServer1T3Url = "t3://iv00046p.cenovus.com:8001"
labMServer1HTTPUrl = "http://iv00046p.cenovus.com:8001"

class MaskingPassword(threading.Thread):
    # This thread will take over control and put a * for every character you type.
    def __init__ (self):
        threading.Thread.__init__(self)
        self.stop_event = threading.Event()
    def stop(self):
        self.stop_event.set()
    def run(self):
        Thread.currentThread().setPriority(Thread.MAX_PRIORITY)
        while not self.stop_event.isSet():
            sys.stdout.write("\010 ")
            Thread.currentThread().sleep(10)


def isValidServer(host, port):
    outMsg = commands.getstatusoutput('nc -z ' + host + ' ' + port)
    rc = list(outMsg)[0]
    if rc == 0:
        print "Server " + host + ':' + port + " is available."
        return True
    else:
        print "Server " + host + ':' + port + " is NOT available."
        return False

def validateHTTPUrl(httpUrl):
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', httpUrl)
    if matchObj:
       return isValidServer(matchObj.group(1), matchObj.group(2))
    else:
        return False

def validateT3Url(t3Url):
    matchObj = re.match(r't3:\/\/(.+):([0-9]{4})', t3Url)
    if matchObj:  
       return isValidServer(matchObj.group(1), matchObj.group(2))
    else:
        return False
def getAdminServerT3Url(targetServer):
    if targetServer == 'LAB':
        isCluster = False
        if validateT3Url(labAServerT3Url):
            try:
                labusername
            except NameError:
                pass
            else:
                try:
                    labpassword
                except NameError:
                    pass
                else:
                    ww.init(labusername, labpassword)
            return labAServerT3Url
        else:
            return "None"
    elif targetServer == 'DEV1':
        isCluster = False
        if validateT3Url(dev1AServerT3Url):
            try:
                dev1username
            except NameError:
                pass
            else:
                try:
                    dev1password
                except NameError:
                    pass
                else:
                    ww.init(dev1username, dev1password)
            return dev1AServerT3Url
        else:
            return "None"
    elif targetServer == 'DEV2':
        isCluster = False
        if validateT3Url(dev2AServerT3Url):
            try:
                dev2username
            except NameError:
                pass
            else:
                try:
                    dev2password
                except NameError:
                    pass
                else:
                    ww.init(dev2username, dev2password)
            return dev2AServerT3Url
        else:
            return "None"
    elif targetServer == 'TST':
        isCluster = True
        if validateT3Url(tstAServerT3Url):
            try:
                tstusername
            except NameError:
                pass
            else:
                try:
                    tstpassword
                except NameError:
                    pass
                else:
                    ww.init(tstusername, tstpassword)
            return tstAServerT3Url
        else:
            return "None"
    elif targetServer == 'TQA':
        isCluster = True
        if validateT3Url(tqaAServerT3Url):
            try:
                tqausername
            except NameError:
                pass
            else:
                try:
                    tqapassword
                except NameError:
                    pass
                else:
                    ww.init(tqausername, tqapassword)
            return tqaAServerT3Url
        else:
            return "None"
    elif targetServer == 'PROD':
        isCluster = True
        if validateT3Url(prodAServerT3Url):
            try:
                produsername
            except NameError:
                pass
            else:
                try:
                    prodpassword
                except NameError:
                    pass
                else:
                    ww.init(produsername, prodpassword)
            return prodAServerT3Url
        else:
            return "None"
    else:
        return "None"

def getServerHTTPUrl(targetServer):
    if targetServer == 'LAB':
        isCluster = False
        if validateHTTPUrl(labMServer1HTTPUrl):
            try:
                labusername
            except NameError:
                pass
            else:
                try:
                    labpassword
                except NameError:
                    pass
                else:
                    ww.init(labusername, labpassword)
            return labMServer1HTTPUrl
        else:
            return "None"
    elif targetServer == 'DEV1':
        isCluster = False
        if validateHTTPUrl(dev1MServer1HTTPUrl):
            try:
                dev1username
            except NameError:
                pass
            else:
                try:
                    dev1password
                except NameError:
                    pass
                else:
                    ww.init(dev1username, dev1password)
            return dev1MServer1HTTPUrl
        else:
            return "None"
    elif targetServer == 'DEV2':
        isCluster = False
        if validateHTTPUrl(dev2MServer1HTTPUrl):
            try:
                dev2username
            except NameError:
                pass
            else:
                try:
                    dev2password
                except NameError:
                    pass
                else:
                    ww.init(dev2username, dev2password)
            return dev2MServer1HTTPUrl
        else:
            return "None"
    elif targetServer == 'TST':
        isCluster = True
        if validateHTTPUrl(tstMServer1HTTPUrl):
            try:
                tstusername
            except NameError:
                pass
            else:
                try:
                    tstpassword
                except NameError:
                    pass
                else:
                    ww.init(tstusername, tstpassword)
            return tstMServer1HTTPUrl
        elif validateHTTPUrl(tstMServer2HTTPUrl):
            try:
                tstusername
            except NameError:
                pass
            else:
                try:
                    tstpassword
                except NameError:
                    pass
                else:
                    ww.init(tstusername, tstpassword)
            return tstMServer2HTTPUrl
        else:
            return "None"
    elif targetServer == 'TQA':
        isCluster = True
        if validateHTTPUrl(tqaMServer1HTTPUrl):
            try:
                tqausername
            except NameError:
                pass
            else:
                try:
                    tqapassword
                except NameError:
                    pass
                else:
                    ww.init(tqausername, tqapassword)
            return tqaMServer1HTTPUrl
        elif validateHTTPUrl(tqaMServer2HTTPUrl):
            try:
                tqausername
            except NameError:
                pass
            else:
                try:
                    tqapassword
                except NameError:
                    pass
                else:
                    ww.init(tqausername, tqapassword)
            return tqaMServer2HTTPUrl
        else:
            return "None"
    elif targetServer == 'PROD':
        isCluster = True
        if validateHTTPUrl(prodMServer1HTTPUrl):
            try:
                produsername
            except NameError:
                pass
            else:
                try:
                    prodpassword
                except NameError:
                    pass
                else:
                    ww.init(produsername, prodpassword)
            return prodMServer1HTTPUrl
        elif validateHTTPUrl(prodMServer2HTTPUrl):
            try:
                produsername
            except NameError:
                pass
            else:
                try:
                    prodpassword
                except NameError:
                    pass
                else:
                    ww.init(produsername, prodpassword)
            return prodMServer2HTTPUrl
        else:
            return "None"
    else:
        return "None"
        
def getServerT3Url(targetServer):
    if targetServer == 'LAB':
        isCluster = False
        if validateT3Url(labMServer1T3Url):
            try:
                labusername
            except NameError:
                pass
            else:
                try:
                    labpassword
                except NameError:
                    pass
                else:
                    ww.init(labusername, labpassword)
            return labMServer1T3Url
        else:
            return "None"
    elif targetServer == 'DEV1':
        isCluster = False
        if validateT3Url(dev1MServer1T3Url):
            try:
                dev1username
            except NameError:
                pass
            else:
                try:
                    dev1password
                except NameError:
                    pass
                else:
                    ww.init(dev1username, dev1password)
            return dev1MServer1T3Url
        else:
            return "None"
    elif targetServer == 'DEV2':
        isCluster = False
        if validateT3Url(dev2MServer1T3Url):
            try:
                dev2username
            except NameError:
                pass
            else:
                try:
                    dev2password
                except NameError:
                    pass
                else:
                    ww.init(dev2username, dev2password)
            return dev2MServer1T3Url
        else:
            return "None"
    elif targetServer == 'TST':
        isCluster = True
        if validateT3Url(tstMServer1T3Url):
            try:
                tstusername
            except NameError:
                pass
            else:
                try:
                    tstpassword
                except NameError:
                    pass
                else:
                    ww.init(tstusername, tstpassword)
            return tstMServer1T3Url
        elif validateT3Url(tstMServer2T3Url):
            try:
                tstusername
            except NameError:
                pass
            else:
                try:
                    tstpassword
                except NameError:
                    pass
                else:
                    ww.init(tstusername, tstpassword)
            return tstMServer2T3Url
        else:
            return "None"
    elif targetServer == 'TQA':
        isCluster = True
        if validateT3Url(tqaMServer1T3Url):
            try:
                tqausername
            except NameError:
                pass
            else:
                try:
                    tqapassword
                except NameError:
                    pass
                else:
                    ww.init(tqausername, tqapassword)
            return tqaMServer1T3Url
        elif validateT3Url(tqaMServer2T3Url):
            try:
                tqausername
            except NameError:
                pass
            else:
                try:
                    tqapassword
                except NameError:
                    pass
                else:
                    ww.init(tqausername, tqapassword)
            return tqaMServer2T3Url
        else:
            return "None"
    elif targetServer == 'PROD':
        isCluster = True
        if validateT3Url(prodMServer1T3Url):
            try:
                produsername
            except NameError:
                pass
            else:
                try:
                    prodpassword
                except NameError:
                    pass
                else:
                    ww.init(produsername, prodpassword)
            return prodMServer1T3Url
        elif validateT3Url(prodMServer2T3Url):
            try:
                produsername
            except NameError:
                pass
            else:
                try:
                    prodpassword
                except NameError:
                    pass
                else:
                    ww.init(produsername, prodpassword)
            return prodMServer2T3Url
        else:
            return "None"
    else:
        return "None"
        
def getSOAServer(targetServer):
    if targetServer == 'LAB':
        if validateT3Url(labMServer1T3Url):
            return labSOAServer1Name
        else:
            return "None"
    elif targetServer == 'DEV1':
        if validateT3Url(dev1MServer1T3Url):
            return dev1SOAServer1Name
        else:
            return "None"
    elif targetServer == 'DEV2':
        if validateT3Url(dev2MServer1T3Url):
            return dev2SOAServer1Name
        else:
            return "None"
    elif targetServer == 'TST':
        if validateT3Url(tstMServer1T3Url):
            return tstSOAServer1Name
        elif validateT3Url(tstMServer2T3Url):
            return tstSOAServer2Name
        else:
            return "None"
    elif targetServer == 'TQA':
        if validateT3Url(tqaMServer1T3Url):
            return tqaSOAServer1Name
        elif validateT3Url(tqaMServer2T3Url):
            return tqaSOAServer2Name
        else:
            return "None"
    elif targetServer == 'PROD':
        if validateT3Url(prodMServer1T3Url):
            return prodSOAServer1Name
        elif validateT3Url(prodMServer2T3Url):
            return prodSOAServer2Name
        else:
            return "None"
    else:
        return "None"
        
def getHostNameList(targetServer):
    m = re.compile(r't3:\/\/(.+):([0-9]{4})')
    sList = []

    if targetServer == 'LAB':
        mo = m.match(labMServer1T3Url)
        if mo:
            sList.append(mo.group(1))
        else:
            sList.append("None")
        return sList
    elif targetServer == 'DEV1':
        mo = m.match(dev1MServer1T3Url)
        if mo:
            sList.append(mo.group(1))
        else:
            sList.append("None")
        return sList
    elif targetServer == 'DEV2':
        mo = m.match(dev2MServer1T3Url)
        if mo:
            sList.append(mo.group(1))
        else:
            sList.append("None")
        return sList
    elif targetServer == 'TST':
        mo = m.match(tstMServer1T3Url)
        if mo:
            sList.append(mo.group(1))
        mo1 = m.match(tstMServer2T3Url)
        if mo1:
            sList.append(mo1.group(1))
        else:
            sList.append("None")
        return sList
    elif targetServer == 'TQA':
        mo = m.match(tqaMServer1T3Url)
        if mo:
            sList.append(mo.group(1))
        mo = m.match(tqaMServer2T3Url)
        if mo:
            sList.append(mo.group(1))
        else:
            sList.append("None")
        return sList
    elif targetServer == 'PROD':
        mo = m.match(prodMServer1T3Url)
        if mo:
            sList.append(mo.group(1))
        mo = m.match(prodMServer2T3Url)
        if mo:
            sList.append(mo.group(1))
        else:
            sList.append("None")
        return sList
    else:
        return sList.append("None")

def getLocalHostName():
    localHostName = socket.gethostname()
    return localHostName

######## Main ##################################
loadProperties('/home/oraclesoa/.serverEnv.properties')
# AdminServer Attributes

