#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : stopf5healthcheck.py
# Description: This script is to stop F5 Health Check WEB Application (in case of cluster, 
#              two web applications for each node.
# Created by : Richard Wang
# Created Date : Aug 1, 2012
# Modified Date: 
#
###############################################################################################
import re
import sys
import wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to stop F5 Health Check WEB Applications, they have to be stopped 
         before stopping the SOA servers in order to prevent the service requests from F5.

         Usage: stopf5healthcheck.py -e environment
            -e: Environment, it must be TST, TQA, or PROD
'''
# Check parameters
targetServer = ''

args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server?" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
    
# Connect to the AdminServer
print "Target Server:" + targetServer

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    try:
        connect(os.getenv('un'), os.getenv('pw'), serverUrl)
        cd('domainRuntime:/AppRuntimeStateRuntime/AppRuntimeStateRuntime')  
        #get intended state for application
        #
        intendedState1 = cmo.getIntendedState('soa1f5healthcheck')  
        print 'The state for soa1f5healthcheck is ' + intendedState1
        #
        intendedState2 = cmo.getIntendedState('soa2f5healthcheck')  
        print 'The state for soa2f5healthcheck is ' + intendedState2

    except Exception, detail:
           print 'Exception:', detail
           exit()
exit()
