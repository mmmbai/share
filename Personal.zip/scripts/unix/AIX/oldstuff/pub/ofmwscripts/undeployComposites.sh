#!/usr/bin/bash
#set -x

EXPECTED_ARGS=1
echo '\e[1;31m'
echo "---------------------------------------------------------------------------------"
echo " For example, if you want to run this script for PROD, you need to login to      "
echo " iv00076p.cenovus.com, change your working directory to /ofmwscript, then invoke "
echo " undeployComposites.sh PROD Filename                                                         "
echo "                                                                                 "
echo " Created by chandra rai                                                          "
echo " Created on Feb 6, 2013                                                          "
echo "---------------------------------------------------------------------------------"
echo '\e[0m'

if [ $# -ne $EXPECTED_ARGS ]
then
  echo "Usage: `basename $0` ENV"
  exit 100
fi
echo "Target environment is " $1

FILENAME="/ofmwscripts/listofcomps"
echo $FILENAME
FS=" "

while read line
do
# store field 1	
	F1=$(echo $line|cut -d ' ' -f1)
	echo $F1	
# store field 2	
	F2=$(echo $line|cut -d ' ' -f2)
	echo $F2	
# store field 3 	
	F3=$(echo $line|cut -d ' ' -f3)
	echo $F3
runUndeploy.py -e $1 -p $F1  -c $F2 -r $F3
done < $FILENAME
exit
