#!/usr/bin/bash
#set -x

EXPECTED_ARGS=1
echo '\e[1;31m'
echo "---------------------------------------------------------------------------------"
echo " For example, if you want to run this script for PROD, you need to login to      "
echo " iv00076p.cenovus.com, change your working directory to /ofmwscript, then invoke "
echo " stopLiveLinkComposites.sh PROD                                                          "
echo "                                                                                 "
echo " Created on july 10, 2013                                                         "
echo "---------------------------------------------------------------------------------"
echo '\e[0m'

if [ $# -ne $EXPECTED_ARGS ]
then
  echo "Usage: `basename $0` {arg}"
  exit 100
fi
echo "Target environment is " $1

stopComposite.py -e $1 -a "PASMasterDataAddressBookDBPublisher,1.0,True,True,Finance"
stopComposite.py -e $1 -a "PASMasterDataCostCentreDBPublisher,1.0,True,True,Finance"
stopComposite.py -e $1 -a "PASMasterDataDivisionOfInterestDBPublisher,1.0,True,True,Finance"
stopComposite.py -e $1 -a "JDEPODBPublisher,1.0,True,True,Finance"

exit
