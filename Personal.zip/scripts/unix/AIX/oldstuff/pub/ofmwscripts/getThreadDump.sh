#!/usr/bin/bash

pid=$1
counter=$2
inv=$3

until [ $counter -lt 0 ] 
do
	echo "sleep $inv sec" 
	sleep $inv
	#prefix='ThreadDump_'
	#suffix=$(date +%s)".txt"
	#filename=$prefix$suffix
	#echo $filename
	kill -3 $pid 2>&1
	let counter-=1
	echo "Done"
done
