#!/usr/bin/bash
#set -x

EXPECTED_ARGS=1
echo '\e[1;31m'
echo "---------------------------------------------------------------------------------"
echo " This script must be run from the same machine where the Scheduler residents     "
echo " For example, if you want to run this script for PROD, you need to login to      "
echo " iv00076p.cenovus.com, change your working directory to /ofmwscript, then invoke "
echo " afterJDEOutage.sh PROD                                                          "
echo "                                                                                 "
echo " Created by Richard Wang                                                         "
echo " Created on Oct 26, 2012                                                         "
echo "---------------------------------------------------------------------------------"
echo '\e[0m'

if [ $# -ne $EXPECTED_ARGS ]
then
  echo "Usage: `basename $0` {arg}"
  exit 100
fi
echo "Target environment is " $1 

startComposite.py -e $1 -a "CAPDApprovalMatrixServices,1.0,True,True,CAPDOC"
startComposite.py -e $1 -a "CAPDAuditEntryServices,1.0,True,True,CAPDOC"
startComposite.py -e $1 -a "CAPDBPMDocumentApprovalWFUtilities,1.0,True,True,CAPDOC"
startComposite.py -e $1 -a "CAPDBPMNDocumentApprovalWorkflow,2.2,True,True,CAPDOC"
startComposite.py -e $1 -a "CAPDDocServices,1.0,True,True,CAPDOC"
startComposite.py -e $1 -a "CAPDDocumentApprovalRequestTaskManagementServices,1.8,True,True,CAPDOC"
startComposite.py -e $1 -a "CAPDUserDemographicsServices,1.0,True,True,CAPDOC"
startComposite.py -e $1 -a "CAPDUserServices,1.8,True,True,CAPDOC"
startComposite.py -e $1 -a "CAPDWorkflowLifecycleServices,1.8,True,True,CAPDOC"
startComposite.py -e $1 -a "CAPDWorkflowUtilityServices,1.8,True,True,CAPDOC"


exit
