#!/usr/bin/bash
#set -x

EXPECTED_ARGS=1
echo '\e[1;31m'
echo "---------------------------------------------------------------------------------"
echo " This script must be run from the same machine where the Scheduler residents     "
echo " For example, if you want to run this script for PROD, you need to login to      "
echo " iv00076p.cenovus.com, change your working directory to /ofmwscript, then invoke "
echo " beforeMaximoOutage.sh PROD                                                      "
echo "                                                                                 "
echo " Created by Richard Wang                                                         "
echo " Created on Oct 26, 2012                                                         "
echo "---------------------------------------------------------------------------------"
echo '\e[0m'

if [ $# -ne $EXPECTED_ARGS ]
then
  echo "Usage: `basename $0` {arg}"
  exit 100
fi
echo "Target environment is " $1 

cd /u01/Scheduler

./E1SchedulerControl.sh -stop JDEPO
./E1SchedulerControl.sh -stop JDEWO

cd /ofmwscripts

stopComposite.py -e $1 -a "AFENav,1.0,True,True,Finance"
stopComposite.py -e $1 -a "ChartOfAccountsService,1.0,True,True,Finance"
stopComposite.py -e $1 -a "JDEHRMyWorldServices,1.0,True,True,HR"
stopComposite.py -e $1 -a "JDEInvTxnSubscriberService,1.2,True,True,Finance"
stopComposite.py -e $1 -a "SubscribePASSystemEventNotificationService,1.0,True,True,Finance"

exit
