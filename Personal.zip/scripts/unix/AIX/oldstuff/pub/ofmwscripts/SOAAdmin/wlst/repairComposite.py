#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : repairComposites.py
# Description: This script is to backup individual deployed composite with "UNKNOWN" state
#              to a specific folder and re-install it again in order to fix the "UNKNOWN"
#              state back to normal.
# Created by : Richard Wang
# Last update: Aug 21, 2012
#        
###############################################################################################
import re, sys, os
import wlstwrapper as ww
execfile("/ofmwscripts/SOAAdmin/wlst/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
    Usage: repairComposite.py [-u update-type] -e environment -p partition -c composite -r revision
           -e: Environment, it must be one of the following servers:
               LAB, DEV1, DEV2, TST, TQA or PROD
           -u: Update type, the type of postdeployment changes (like DVM)
               to be exported, default is "all"
           -p: Partition
           -c: Composite
           -r: Revision
           
    Note: This script does not validate the Partition, Composite and Revision you input,
          leave them to the API, if the system could not find the one you specified, it will
          cause exception.
'''
# from optparse import OptionParser
updateType = 'all'
targetServer = ''
targetPartition = ''
targetComposite = ''
targetRevision = '1.0'
userid = ''
passwd = ''
ow = true
fd = true

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-u':
        updateType = args[1].strip()
        args = args[2:]
    elif current_arg == '-p':
        targetPartition = args[1].strip()
        args = args[2:]
    elif current_arg == '-c':
        targetComposite = args[1].strip()
        args = args[2:]
    elif current_arg == '-r':
        targetRevision = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]

if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    appHome = '/ofmwmedia/cenovus_apps/' + targetServer + '/'
    
serverUrl = getServerHTTPUrl(targetServer)
print "Target Server=" + serverUrl
print "Update Type=" + updateType

if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', serverUrl)
    if matchObj:  
        hostAddr = matchObj.group(1)
        hostPort = matchObj.group(2)

if os.getenv('un') is None or os.getenv('pw') is None:
    userid = raw_input("Enter username: ")
    MaskingThread = MaskingPassword()
    MaskingThread.start()
    passwd = raw_input("Enter password: ")
    MaskingThread.stop() 
    if userid.strip() == '' or passwd.strip() == '':
        print ww.bcolors.RED + "userid or password or both is empty, please try again." + ww.bcolors.ENDC
        exit()
else:
    userid = os.getenv('un')
    passwd = os.getenv('pw')

try:
    sarFile = appHome + targetPartition + '/sca_' + targetComposite + '_rev' + targetRevision + '.jar'
    print ww.bcolors.RED + "Back up the specified coposite......" + ww.bcolors.ENDC
    sca_exportComposite(serverUrl,
                        updateType,
                        sarFile,
                        targetComposite,
                        targetRevision,
                        user=userid,
                        password=passwd,
                        partition=targetPartition)

    # Undeploy the composite application before running the deployment
    print ww.bcolors.RED + "Clean up: undeploy it ......" + ww.bcolors.ENDC
    sca_undeployComposite(serverUrl,
                        targetComposite,
                        targetRevision,
                        user=userid,
                        password=passwd,
                        partition=targetPartition)

    # Deploy without plan
    print ww.bcolors.RED + "Restore it again......" + ww.bcolors.ENDC
    sca_deployComposite(serverUrl, 
                        sarFile, 
                        ow, 
                        user=userid,
                        password=passwd,
                        forceDefault=fd, 
                        partition=targetPartition)
    print ww.bcolors.RED + "Done" + ww.bcolors.ENDC
except Exception, detail:
       print 'Exception:', detail
       sys.exit()

exit()
