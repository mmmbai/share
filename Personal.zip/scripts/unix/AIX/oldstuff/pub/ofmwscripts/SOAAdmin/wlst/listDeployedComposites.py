#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : listDeployedComposites.py  [ LAB | DEV1 | DEV2 | TQA | PROD ]
# Description: This script is to display all deployed composites
# Created by : Richard Wang
# Modified Date: Jan 31, 2012
#
###############################################################################################
import re
import sys
import os.path
import commands
import wlstwrapper as ww
from oracle.fabric.management.deployedcomposites import CompositeManager
execfile("/ofmwscripts/wlstCustomUtils.py")
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script to list all composites deployed to the specified server.
         Usage: listDeployedComposites.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''

targetServer = ''
# Check parameters
args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

deployedCompos = None
deployedCompList = []

print "Target Server:" + targetServer

deployTargetServerUrl = getServerHTTPUrl(targetServer)

userid = ''
passwd = ''
if os.getenv('un') is None or os.getenv('pw') is None:
    userid = raw_input("Enter username: ")
    MaskingThread = MaskingPassword()
    MaskingThread.start()
    passwd = raw_input("Enter password: ")
    MaskingThread.stop() 
    if userid.strip() == '' or passwd.strip() == '':
        print ww.bcolors.RED + "userid or password or both is empty, please try again." + ww.bcolors.ENDC
        exit()
else:
    userid = os.getenv('un')
    passwd = os.getenv('pw')    


matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', deployTargetServerUrl)

if matchObj:  
    hostAddr = matchObj.group(1)
    hostPort = matchObj.group(2)
    print "Target server host=", hostAddr 
    print "Target server port=", hostPort
    
try:
    CompositeManager.initConnection(hostAddr,
                        hostPort,
                        userid,
                        passwd)

    print "Connection has been established."
    clmMBean = CompositeManager.getCompositeLifeCycleMBean()
    if clmMBean == None:
        print 'Cannot find composite lifecycle mbean.'
        sys.exit()
        
    deployedComposites = CompositeManager.listDeployedComposites(clmMBean)
    compList = deployedComposites.split('\n')
    del compList[0:3]
    print
    print '%-40s' %'partitionName', '%-70s' %'compositeName' , '%-10s' %'mode' ,'%-5s' %'state' ,'%-10s' %'isDefault' ,'%-30s' %'deployedTime' 
    print ww.bcolors.RED + '------------------------------------------------------------------------------------------------------------------------------------------------------------------' + ww.bcolors.ENDC
    for lineString in compList:
        lineArray = lineString.split(',')
        if (len(lineArray) > 2):
            partitionName=(lineArray[1].split('='))[1]
            compositeName=(lineArray[0].split(' '))[1]
            mode=(lineArray[2].split('='))[1]
            state=(lineArray[3].split('='))[1]
            isDefault=(lineArray[4].split('='))[1]
            deployedTime=(lineArray[5].split('='))[1]            
            print '%-40s' %(partitionName), '%-70s' %(compositeName) , '%-10s' %(mode) ,'%-5s' %(state) ,'%-10s' %(isDefault) ,'%-30s' %(deployedTime) 

except Exception, detail:
       print 'Exception:', detail
       dumpStack()
       sys.exit()

print "Done"
    
