#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : importMetadata.py nameSpaceOfDocument
# Description: This script is for importing metadata from a pre-defined directory to 
#              the MDS_repository. At this time, the repository partition is fixed to be 
#              soa-infra (Application), it may be changed for applying any specified
#              applications.
#
# Created by : Richard Wang
# Modified Date : April 9, 2012
#        
###############################################################################################
import re
import sys
import os
import wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")

applicationName = 'soa-infra'

# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script only function with the following prerequisites:
           [1] The Application Name of MDS is fixed as 'soa-infra';
           [2] The ~/.serverEnv.properties file is referred from this script;
           [3] The target server ABBRIVATION must be provided as the first parameter.
           [4] The MDS data root folder in tree-structure format must be exist under
               /ofmwmedia/cenovus_apps/MDS/ and provided as the second parameter.
               
         Usage: runDdeploy.py -e environment mds-data-folder-name
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
            mds-data-folder-name: The root folder of MDS name.
                
            Be very careful to specify this name,or will create garbage namespace!!!
'''

# Check parameters
targetServer = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg != '':
        mdsData = current_arg
        args = args[1:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server?" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
serverUrl = getServerT3Url(targetServer)

userid = ''
passwd = ''
if os.getenv('un') is None or os.getenv('pw') is None:
    userid = raw_input("Enter username: ")
    MaskingThread = MaskingPassword()
    MaskingThread.start()
    passwd = raw_input("Enter password: ")
    MaskingThread.stop() 
    if userid.strip() == '' or passwd.strip() == '':
        print ww.bcolors.RED + "userid or password or both is empty, please try again." + ww.bcolors.ENDC
        exit()
else:
    userid = os.getenv('un')
    passwd = os.getenv('pw')     



if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    print "Target Server:" + serverUrl

    pathToMDS = "/ofmwmedia/cenovus_apps/MDS/" + mdsData
    print 'The path to metadata or folder to deploy is......' , pathToMDS
    if not (os.path.exists(pathToMDS + '/apps')):
        print "It looks like the path to the MDS folder is not correct, please try it again."
        sys.exit()
    else:
        pass        

    yesno = raw_input('Are you going to continue(Yes/yes/y OR No/no/n)?')
    if (yesno.strip().upper() != 'Y' and yesno.strip().upper() != 'YES'):
        sys.exit()
    else:
        # Connect to the AdminServer
        connect(userid, passwd, serverUrl)
        # domainConfig() 
        print 'Run import.....'
        try:
            importMetadata(application=applicationName,
                           server=getSOAServer(targetServer), 
                           fromLocation=pathToMDS, docs='/**')
            print 'Upload sucessfully!'
        except WLSTException:
            dumpStack()

disconnect()
exit()

