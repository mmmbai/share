#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : runStartAll.py
# Description: This script is to start all deployed composites
# Created by : Richard Wang
# Created Date : July 12, 2011
# Modified Date: Feb 29, 2012
#
###############################################################################################
import re
import sys
import os.path
import commands
import wlstwrapper as ww
from oracle.fabric.management.deployedcomposites import CompositeManager
execfile("/ofmwscripts/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to start all composites listed in compositeList_XXX.properties
         file. the XXX is the abbriviation of the target SOA server name, it can be 
             LAB, DEV1, DEV2, TQA, TST and PROD.

         Usage: runStartAll.py -e environment [-f properties_file_name] [-g groupName] 
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA, or PROD
            -f: Properties file name, in which target composites list is defined,
                If no file name is passed from command line, the script will use 
                default one based on the specified environment
            -g group_id, it is the part before "=" in the properties file.
               If no group_id is specified as command line argument, the script will
               parse all composites and find all valid groups.
'''
# Check parameters
deployedCompos = None
compositesQueue = list()
targetServer = ''
resourceProp = ''
compositeName = ''
compositeRev = ''
groupName = ''
part = ''

args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-f':
        resourceProp = args[1].strip()
        args = args[2:]
    elif current_arg == '-g':
        groupName = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server?" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
if resourceProp == '':
    resourceProp = "/ofmwscripts/compositeList_" + targetServer + ".properties"
    
# Connect to the AdminServer
print "Target Server:" + targetServer
print "Properties File:" + resourceProp
print "Group Name:" + groupName

serverUrl = getServerHTTPUrl(targetServer)

userid = ''
passwd = ''
if os.getenv('un') is None or os.getenv('pw') is None:
    userid = raw_input("Enter username: ")
    MaskingThread = MaskingPassword()
    MaskingThread.start()
    passwd = raw_input("Enter password: ")
    MaskingThread.stop() 
    if userid.strip() == '' or passwd.strip() == '':
        print ww.bcolors.RED + "userid or password or both is empty, please try again." + ww.bcolors.ENDC
        exit()
else:
    userid = os.getenv('un')
    passwd = os.getenv('pw')    



if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', serverUrl)
    if matchObj:  
        hostAddr = matchObj.group(1)
        hostPort = matchObj.group(2)
        # print "Target server host=", hostAddr 
        # print "Target server port=", hostPort
        try:
            # Get composite list from compositesList file
            if os.path.exists(resourceProp):
                prop = open(resourceProp, "r")
                if groupName != '':
                    rx = re.compile(groupName + '=(.*)')
                    for line in prop:
                        matchObj = rx.match(line)
                        if matchObj: 
                            # print "composite=>", matchObj.group(1)
                            compositesQueue.append(matchObj.group(1))
                else:
                    rx = re.compile(r'^(?!#).*=(.*)')
                    for line in prop:
                        matchObj = rx.match(line)
                        if matchObj: 
                            # print "composite=>", matchObj.group(1)
                            compositesQueue.append(matchObj.group(1))
                prop.seek(0)

                for oneComposite in compositesQueue:
                    print oneComposite
                    propList = oneComposite.split(",")
                    compositeName = os.path.basename(propList[0])
                    compositeRev = propList[1]
                    part = propList[4]
                    # print "compositeName =" + str(propList[0])
                    # print "compositeRev =" + str(propList[1])
                    # print "partition =" + str(propList[4])
                    sca_startComposite(hostAddr, 
                                    hostPort, 
                                    userid, 
                                    passwd, 
                                    compositeName, 
                                    compositeRev,
                                    partition=part)
            else:
                print "The specified properties file does not exist!!!"
                sys.exit()
        except Exception, detail:
               print 'Exception:', detail
               sys.exit()
exit()

