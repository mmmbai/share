#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : runUndeployNonDefault.py
# Description: This script is to call sca_undeploy wlst command to perform undeployment  
#              of multiple non default composite applications defined in deploy.properties file.
# Created By: Chandra Rai
# Date       : Oct 23, 2013    
#        
###############################################################################################
import re
import sys
import os.path
import commands
import wlstwrapper as ww
from oracle.fabric.management.deployedcomposites import CompositeManager
execfile("/ofmwscripts/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
    Usage: runUndeployNonDefault.py -e environment
           -e: Environment, mandatory.it must be LAB, DEV1 DEV2 TST, TQA or PROD
'''
# from optparse import OptionParser
env = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        env = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]

if env == '':
    print usageText
    sys.exit()

    
print "Environment=" + env


deployedCompos = None
deployedCompList = []

serverUrl = getServerHTTPUrl(env)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', serverUrl)

if matchObj:  
    hostAddr = matchObj.group(1)
    hostPort = matchObj.group(2)
    print "Target server host=", hostAddr 
    print "Target server port=", hostPort
    
try:
    CompositeManager.initConnection(hostAddr, 
                        hostPort, 
                        os.getenv('un'), 
                        os.getenv('pw'))
    clmMBean = CompositeManager.getCompositeLifeCycleMBean()
    if clmMBean == None:
        print 'Cannot find composite lifecycle mbean.'
        sys.exit()
        
    deployedComposites = CompositeManager.listDeployedComposites(clmMBean)
    compList = deployedComposites.split('\n')
    del compList[0:2]

    # Re organize the list, only the compositeName will be left
    targetComposite = ''
    targetRevision = ''
    targetPartition = ''
    targetDefaultValue = '' 
    for i in range(len(compList)):
        if compList[i] != '':
            #print "compList[i] = " + compList[i]
            iList = compList[i].split(",")
            matchCompInfo = re.match(r'[0-9]+.\s*(.+)\[([0-9]+\.[0-9]+)\]', iList[0])
            if matchCompInfo:
                targetComposite = matchCompInfo.group(1)
                targetRevision = matchCompInfo.group(2)
            else:
                print "Problem happened when parsing " + iList[0] + " skip it." 
                continue

            # Get Partition
            matchPartitionInfo = re.match(r'partition=(.+)', iList[1].strip())
            if matchPartitionInfo:
                targetPartition = matchPartitionInfo.group(1)
            else:
                print "Problem happened when parsing " + iList[1] + " skip it." 
                continue
            
	        # Get isDefault value
	    matchdefaultValue = re.match(r'isDefault=(.+)', iList[4].strip())
       	    if matchdefaultValue:
		targetDefaultValue = matchdefaultValue.group(1)
 	    else:
		print "Problem happened when parsing " + iList[4] + " skip it."
		continue 
            # Undeploy only if composite is non default 
            #print "targetComposite=" + targetComposite
            #print "Composite=" + com
            #print "targetRevision=" + targetRevision
            #print "Revision=" + rev
            #print "targetPartition=" + targetPartition
            #print "Partition=" + par

            if targetDefaultValue == "false":
                print "Found non default composite, undeploy it....."
                sca_undeployComposite(serverUrl, 
                               targetComposite, 
                               targetRevision, 
                               user=os.getenv('un'), 
                               password=os.getenv('pw'), 
                               partition=targetPartition)

                print targetComposite + '[' + targetRevision + '] has been un-deployed from ' + targetPartition + ' partition.\n'
            else:
                pass

except Exception, detail:
       print 'Exception:', detail
       sys.exit()
