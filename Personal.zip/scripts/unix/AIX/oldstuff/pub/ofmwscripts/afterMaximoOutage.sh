#!/usr/bin/bash
#set -x

EXPECTED_ARGS=1
echo '\e[1;31m'
echo "---------------------------------------------------------------------------------"
echo " This script must be run from the same machine where the Scheduler residents     "
echo " For example, if you want to run this script for PROD, you need to login to      "
echo " iv00076p.cenovus.com, change your working directory to /ofmwscript, then invoke "
echo " afterMaximoOutage.sh PROD                                                       "
echo "                                                                                 "
echo " Created by Richard Wang                                                         "
echo " Created on Oct 26, 2012                                                         "
echo "---------------------------------------------------------------------------------"
echo '\e[0m'

if [ $# -ne $EXPECTED_ARGS ]
then
  echo "Usage: `basename $0` {arg}"
  exit 100
fi
echo "Target environment is " $1 

startComposite.py -e $1 -a "MaximoGLTransactionSubscriberService,1.1,True,True,AssetManagement"
startComposite.py -e $1 -a "MaximoPIMeterReadingService,1.0,True,True,AssetManagement"
startComposite.py -e $1 -a "MaximoPOInvoiceReceiptSubscriberService,1.2,True,True,AssetManagement"
startComposite.py -e $1 -a "MaximoExRateSubscriberService,1.0,True,True,AssetManagement"

cd /u01/Scheduler
./E1SchedulerControl.sh -start MaximoVendor
./E1SchedulerControl.sh -start MaximoCostCentre
cd /ofmwscripts

sleep 300

startComposite.py -e $1 -a "MaximoPOInvoicePaymentSubscriberService,1.1,True,True,AssetManagement"

#cd /u01/Scheduler
#./E1SchedulerControl.sh -start MaximoChartOfAccounts
#cd /ofmwscripts

exit
