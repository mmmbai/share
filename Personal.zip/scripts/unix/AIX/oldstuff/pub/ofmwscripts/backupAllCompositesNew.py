#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : backupAllComposites.py
# Description: This script is to backup all deployed composites to a specific folder
#              just in case the SOA server crashed and need to get all composites back
# Created by : Richard Wang
# Last modified: Aug 20, 2012
#        
###############################################################################################
import re
import sys
import os
import commands
import wlstwrapper as ww
from oracle.fabric.management.deployedcomposites import CompositeManager
execfile("/ofmwscripts/wlstCustomUtils.py")

appHome = '/ofmwmedia/cenovus_apps/'
updateType = 'all'
deployedCompos = None
deployedCompList = []

# Preformatted UsageText
usageText = '''
    Usage: backupAllComposites.py [-u update-type] -e environment
           -e: Environment, it must be one of the following servers:
               LAB, DEV1, DEV2, TST, TQA or PROD
           -u: Update type, the type of postdeployment changes (like DVM)
               to be exported, default is "all"
'''
# from optparse import OptionParser
targetServer = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-u':
        updateType = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
        
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    appHome = appHome + targetServer + '/'
    
serverUrl = getServerHTTPUrl(targetServer)
print "Target Server=" + serverUrl
print "Update Type=" + updateType

if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', serverUrl)
    if matchObj:  
        hostAddr = matchObj.group(1)
        hostPort = matchObj.group(2)

userid = ''
passwd = ''
if os.getenv('un') is None or os.getenv('pw') is None:
    userid = raw_input("Enter username: ")
    MaskingThread = MaskingPassword()
    MaskingThread.start()
    passwd = raw_input("Enter password: ")
    MaskingThread.stop() 
    if userid.strip() == '' or passwd.strip() == '':
        print ww.bcolors.RED + "userid or password or both is empty, please try again." + ww.bcolors.ENDC
        exit()
else:
    userid = os.getenv('un')
    passwd = os.getenv('pw')

try:
    CompositeManager.initConnection(hostAddr, hostPort, userid, passwd)
    clmMBean = CompositeManager.getCompositeLifeCycleMBean()
    if clmMBean == None:
        print 'Cannot find composite lifecycle mbean.'
        sys.exit()
        
    deployedComposites = CompositeManager.listDeployedComposites(clmMBean)
    compList = deployedComposites.split('\n')
    del compList[0:2]
    # Re organize the list, only the compositeName will be left
    targetComposite = ''
    targetRevision = ''
    targetPartition = ''
    for i in range(len(compList)):
        if compList[i] != '':
            # print "compList[i] = " + compList[i]
            iList = compList[i].split(",")
            matchCompInfo = re.match(r'[0-9]+.\s*(.+)\[([0-9]+\.[0-9]+)\]', iList[0])
            if matchCompInfo:
                targetComposite = matchCompInfo.group(1)
                targetRevision = matchCompInfo.group(2)
            else:
                print "Problem happened when parsing " + iList[0] + " skip it." 
                continue

            # Get Partition
            matchPartitionInfo = re.match(r'partition=(.+)', iList[1].strip())
            if matchPartitionInfo:
                targetPartition = matchPartitionInfo.group(1)
            else:
                print "Problem happened when parsing " + iList[1] + " skip it." 
                continue
            sarFile = appHome + targetPartition + '/sca_' + targetComposite + '_rev' + targetRevision + '.jar'

            sca_exportComposite(serverUrl,
                                updateType,
                                sarFile,
                                targetComposite,
                                targetRevision,
                                user=userid,
                                password=passwd,
                                partition=targetPartition)
        else:
            pass

except Exception, detail:
       print 'Exception:', detail
       sys.exit()

exit()