#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

############################################################################
# By using SOA custom WLST commands, no matter the application's status,
# it can be deployed.
############################################################################ 
import sys
import re
import os
import os.path
import commands
#
# Define all necessary variables, but the can be replaced by command params
# Please refer to the usage 
# 

loadProperties('./serverEnv.properties')

# Default value when no parameters specified

# Check parameters, if there is not enough parameters, ask to input them
# by default, otherwise use userName and password passed from parameters
params = len(sys.argv)

if params == 1:
    print "At least you need to specify a composite name you want to package...Please try again."
    exit()
elif params == 2:
    compositeName = sys.argv[1]
    revision = '1.0'
elif params == 3:
    compositeName = sys.argv[1]
    revision = sys.argv[2]

# Get composite's full path name from the applications.properties
grepCmd = 'grep ' + compositeName + ' ' + appDockDir + '/applications.properties'

compositeAttr = commands.getoutput(grepCmd)

matchObj = re.match(r'composite\d+\s=\s(.*)', compositeAttr)
if matchObj:
    compositePath = matchObj.group(1).split(',')[0]
    
    compositeFullPath = appDockDir + '/' + compositePath
    
    sca_package(compositeFullPath,
               compositeName,
               revision,
               oracleHome=oracleSOAHome
               )
    exit()
else:
    print "No the composite could be found."
    exit()

