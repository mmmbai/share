jmsModuleName='CenovusSOAJMSModule'
businessAreaName='common'
queueName='testQueue'
subDeploymentName=businessAreaName+'SubDeployment'



def createQueue():		
	currentTree='/JMSSystemResources/'+ jmsModuleName+'/JMSResource/'+ jmsModuleName
	cd(currentTree)
	cmo.createQueue(queueName)
	currentTree=currentTree+'/Queues/'+queueName
	cd(currentTree)
	queueJNDIName='jms/'+businessAreaName+'/'+queueName
	cmo.setJNDIName(queueJNDIName)
	cmo.setSubDeploymentName(subDeploymentName)
	save()
	
	
def createQueueCF():		
	currentTree='/JMSSystemResources/'+ jmsModuleName+'/JMSResource/'+ jmsModuleName
	cd(currentTree)
	cmo.createQueue(queueName)
	currentTree=currentTree+'/Queues/'+queueName
	cd(currentTree)
	queueJNDIName='jms/'+businessAreaName+'/'+queueName
	cmo.setJNDIName(queueJNDIName)
	cmo.setSubDeploymentName(subDeploymentName)
	save()

createQueue()	