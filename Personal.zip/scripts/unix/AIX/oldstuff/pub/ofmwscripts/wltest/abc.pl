#!/usr/bin/perl
$_='I am sleepy....snore....DING ! Wake Up!';

/snore/;	# look, no parens !

print "Postmatch: $'\n";
print "Prematch: $`\n";
print "Match: $&\n";
