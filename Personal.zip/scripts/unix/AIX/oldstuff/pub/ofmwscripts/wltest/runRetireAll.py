#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : runStopAll.py
# Description: This script is to stop all deployed composites
# Created by : Richard Wang
# Created Date : July 12, 2011
# Modified Date: Feb 29, 2012
#
###############################################################################################
import re
import sys
import os.path
import commands
import wlstwrapper as ww
from oracle.fabric.management.deployedcomposites import CompositeManager
execfile("/ofmwscripts/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to retire all deployed composites (not based on
         the properties file like compositeList_XXX.properties).

         Usage: runRetireAll.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TQA, or PROD
            -f: Properties file, if no specified, use compositeList_XXX.properties
            -g: Group name, the name on the left-hand of "=" in the properties file.
'''

deployedCompos = None
deployedCompList = []
compositesQueue = list()
resourceProp = ''
groupName = ''
compositeName = ''
compositeRev = ''
part = ''
targetServer = ''

# Check parameters
args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip()
        args = args[2:]
    elif current_arg == '-f':
        resourceProp = args[1].strip()
        args = args[2:]
    elif current_arg == '-g':
        groupId = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
        
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server?" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
if resourceProp == '':
    resourceProp = "/ofmwscripts/compositeList_" + targetServer + ".properties"

print "Target Server:" + targetServer
print "Properties File:" + resourceProp
print "Group Name:" + groupName

serverUrl = getServerHTTPUrl(targetServer)

if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', serverUrl)
    if matchObj:  
        hostAddr = matchObj.group(1)
        hostPort = matchObj.group(2)
        # print "Target server host=", hostAddr 
        # print "Target server port=", hostPort
        try:
            # Get composite list from compositesList file but in Queue LIFO
            # print "Composites properties file: " + resourceProp
            if os.path.exists(resourceProp):
                prop = open(resourceProp, "r")
                
                # Pick up one composite's properties
                if groupName != '':
                    rx = re.compile(groupName + '=(.*)')
                    for line in prop:
                        matchObj = rx.match(line)
                        if matchObj: 
                            # print "composite=>", matchObj.group(1)
                            compositesQueue.append(matchObj.group(1))
                else:
                    rx = re.compile(r'^(?!#).*=(.*)')
                    for line in prop:
                        matchObj = rx.match(line)
                        if matchObj: 
                            # print "composite=>", matchObj.group(1)
                            compositesQueue.append(matchObj.group(1))
                prop.seek(0)
            else:
                print "No composite properties file exist."
                sys.exit()

            # Re organize the list, only the compositeName will be left
            for i in range(len(compositesQueue)):
                oneComposite = compositesQueue.pop()
                print oneComposite
                propList = oneComposite.split(",")
                compositeName = os.path.basename(propList[0])
                compositeRev = propList[1]
                part = propList[4]

                sca_retireComposite(hostAddr, 
                                    hostPort, 
                                    os.getenv('un'), 
                                    os.getenv('pw'), 
                                    compositeName, 
                                    compositeRev,
                                    partition=part)


        except Exception, detail:
               print 'Exception:', detail
               sys.exit()
    else:
        pass
exit()

