#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#
#  This script is to list up all jdbc datasources defined in the FMW environment and their status
#
#  Created by: Richard Wang
#  Created on : Aug. 28, 2011
#
###############################################################################################################

import re, sys, wlstwrapper as ww, traceback
execfile("/ofmwscripts/wlstCustomUtils.py")
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to check all JDBC data sources status.
         Usage: checkDataSources.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''

print "Check all datasources' status....."
#=======================================================================================
# Process the changes
#=======================================================================================
targetServer = ''
args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

# Connect to the AdminServer
print "Target Server:" + targetServer

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)

    # Get all servers 
    allServers=domainRuntimeService.getServerRuntimes();

    if (len(allServers) > 0):
      for tempServer in allServers:
        jdbcServiceRT = tempServer.getJDBCServiceRuntime();
        dataSources = jdbcServiceRT.getJDBCDataSourceRuntimeMBeans();
        if (len(dataSources) > 0):
            print 'There are ',  len(dataSources), 'datasources defined right now:'
            for dataSource in dataSources:
                print '---------------------------------------------------------------------------------------'
                # print 'ActiveConnectionsAverageCount      '  ,  dataSource.getActiveConnectionsAverageCount()
                # print 'ActiveConnectionsCurrentCount      '  ,  dataSource.getActiveConnectionsCurrentCount()
                # print 'ActiveConnectionsHighCount         '  ,  dataSource.getActiveConnectionsHighCount()
                # print 'ConnectionDelayTime                '  ,  dataSource.getConnectionDelayTime()
                # print 'ConnectionsTotalCount              '  ,  dataSource.getConnectionsTotalCount()
                # print 'DeploymentState                    '  ,  dataSource.getDeploymentState()
                # print 'FailedReserveRequestCount          '  ,  dataSource.getFailedReserveRequestCount()
                # print 'FailuresToReconnectCount           '  ,  dataSource.getFailuresToReconnectCount()
                # print 'HighestNumAvailable                '  ,  dataSource.getHighestNumAvailable()
                # print 'HighestNumUnavailable              '  ,  dataSource.getHighestNumUnavailable()
                # print 'LeakedConnectionCount              '  ,  dataSource.getLeakedConnectionCount()
                # print 'ModuleId                           '  ,  dataSource.getModuleId()
                print 'Name                               '  ,  dataSource.getName()
                # print 'NumAvailable                       '  ,  dataSource.getNumAvailable()
                # print 'NumUnavailable                     '  ,  dataSource.getNumUnavailable()
                # print 'Parent                             '  ,  dataSource.getParent()
                # print 'Properties                         '  ,  dataSource.getProperties()
                # print 'ReserveRequestCount                '  ,  dataSource.getReserveRequestCount()
                print 'State                              '  ,  dataSource.getState()
                # print 'Type                               '  ,  dataSource.getType()
                # print 'VersionJDBCDriver                  '  ,  dataSource.getVersionJDBCDriver()
                # print 'WaitingForConnectionCurrentCount   '  ,  dataSource.getWaitingForConnectionCurrentCount()
                # print 'WaitingForConnectionFailureTotal   '  ,  dataSource.getWaitingForConnectionFailureTotal()
                # print 'WaitingForConnectionHighCount      '  ,  dataSource.getWaitingForConnectionHighCount()
                # print 'WaitingForConnectionSuccessTotal   '  ,  dataSource.getWaitingForConnectionSuccessTotal()
                # print 'WaitingForConnectionTotal          '  ,  dataSource.getWaitingForConnectionTotal()
                # print 'WaitSecondsHighCount               '  ,  dataSource.getWaitSecondsHighCount()

exit()
