#!/usr/bin/perl
use strict;
use Getopt::Long;

my($num) = 0;
my($i) = 0;
my($total_size) = 0;
my @fields = ();
my @pName = ();
my @pValue = ();
my %processes = ();
my $process;
my $topNum;
my $tempValue;
GetOptions("n=i" => \$num);

#Get System Infomation 
my @output=();
open(OUTPUT,"/usr/bin/svmon |") || die "Failed to run svmon: $!\n";
@output=<OUTPUT>;
my @values = split(' ',$output[1]);
my $SystemTotal=$values[1]*4;
my $AllUsed=$values[2]*4;

#Get User Infomation
open(INPUT,"/usr/bin/svmon -Slm|tail +3 |") || die "Failed to run svmon: $!\n";
while (<INPUT>){
    chomp;
    s/\t//g;
    s/^\s*//g;
    if (/^[0-9a-f]/) {
        @fields = split(/\s\s+/);
        if ($fields[2] eq "s"){
            $total_size = $total_size + ( $fields[3] * 4 ); 
        }elsif ($fields[2] eq "m"){
            $total_size = $total_size + ( $fields[3] * 64 ); 
        }
    }elsif ( /^s{1}/ ) {
        @fields = split(/\s\s+/);
        $total_size =+ ( $fields[1] * 4 ); 
    }elsif ( /^m{1}/ ) {
        @fields = split(/\s\s+/);
        $total_size =+ ( $fields[1] * 64 ); 
    }elsif ( /^parent=/ ) {
        next;
    }else {
        #print ($_ . ": " . $total_size . "(KB)\n");
        if (exists $processes{$_}) {
            $processes{$_} = $processes{$_} + $total_size;
        }else {
             $processes{$_} = $total_size;
        }
        $total_size = 0;
    }
}
$total_size = 0;
foreach $process ( sort { $processes{$a} <=> $processes{$b} } keys %processes) {
    push(@pName, $process);
    push(@pValue, $processes{$process});
    $total_size = $total_size + $processes{$process};
}
#Start to print

printf "%65s  => %15s (KB)     %15s\n"," System Total" ,$SystemTotal, "";
printf "%65s  => %15s (KB)     %.2f\%\n","All User Used" ,$AllUsed, $AllUsed/$SystemTotal*100;
printf "%65s  => %15s (KB)     %.2f\%\n","oraclesoa Used",$total_size, $total_size/$SystemTotal*100;

print "\n";

if (($num > 0) && ($num <= $#pValue)){
    $topNum = $num;
    #print "Top " . $topNum . " are as below:\n";
}else{
    $topNum = $#pValue + 1;
}
for ($i = 0; $i < $topNum; $i++){
	$tempValue=pop(@pValue);
    printf "%65s  => %15s (KB)     %.2f\%\n",pop(@pName) ,$tempValue, $tempValue/$SystemTotal*100;
}
close(INPUT);
