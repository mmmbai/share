#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#
#  This script is to check the health of Threads Pool in a regular time interval
#
#  Created by: Richard Wang
#  Created on : Feb 18, 2012
#
###############################################################################################################

import re, sys, string, traceback

#############  This method would send the Alert Email  #################
def sendMailString():
    os.system('/bin/mailx -s  "ALERT: Thread Pool Health is in WARNING !!! " richard.wang@cenovus.com < rw_file')
    print '*********  ALERT MAIL HAS BEEN SENT  ***********'
    print ''

#############  This method is checking the Thread Pool Health   #################
def alertThreadPoolHealth(healthState):
    state ="Checking HealthState: " + str(healthState)
    check = string.find(state,"HEALTH_WARN")
    if check != -1:
        print '!!!! ALERT !!!! Thread Pool Health is in WARNING State'
        print ''
        message =  'Please Check the Thread Pool is in WARNING State.'
        cmd = "echo " + message +" > rw_file"
        os.system(cmd)
        sendMailString()
    else:
        print 'Everything is working fine till now'

loadProperties('/home/oraclesoa/.serverEnv.properties')
# Connect to the AdminServer
connect(username, password, managedServerT3Url)
serverRuntime()
cd('ThreadPoolRuntime/ThreadPoolRuntime')

i = 0
y = int(checkTimes_Number)

while (i < y):
    # ls()
    healthState=cmo.getHealthState();
    # print "healthState=" + str(healthState)
    alertThreadPoolHealth(healthState)
    Thread.sleep(int(checkInterval_in_Milliseconds))
    i = i + 1

sys.exit()
