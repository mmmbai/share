#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

############################################################################
# By using SOA custom WLST commands, no matter the application's status,
# it can be deployed.
############################################################################ 
import sys
import re
import os
import os.path
import commands
#
# Define all necessary variables, but the can be replaced by command params
# Please refer to the usage 
# 

loadProperties('./serverEnv.properties')

# Default value when no parameters specified

# Check parameters, if there is not enough parameters, ask to input them
# by default, otherwise use userName and password passed from parameters
params = len(sys.argv)

if params == 1:
    print "At least you need to specify a composite name you want to deploy...Please try again."
    exit()
elif params == 2:
    compositeName = sys.argv[1]
    displayLevel = 2
    errorOutput = "/tmp/error.out"
elif params == 3:
    compositeName = sys.argv[1]
    displayLevel = sys.argv[2]
    errorOutput = "/tmp/error.out"
elif params == 4:
    compositeName = sys.argv[1]
    displayLevel = sys.argv[2]
    errorOutput = sys.argv[3]

# Get composite's full path name from the applications.properties
grepCmd = 'grep ' + compositeName + ' ' + appDockDir + '/applications.properties'

compositeAttr = commands.getoutput(grepCmd)

print "CompositeAttr=",  compositeAttr

matchObj = re.match(r'composite\d+\s=\s(.*)', compositeAttr)
if matchObj:
    compositePath = matchObj.group(1).split(',')[0]
    
    compositeFullPath = appDockDir + '/' + matchObj.group(1).split(',')[0]
    
    # Call SOA wlst sca_compile command with userName and password
    sca_compile(compositeFullPath + '/composite.xml',
                displayLevel=displayLevel,
                oracleHome=oracleSOAHome,
                error=errorOutput)
  
    exit()
else:
    print "No the composite could be found."
    exit()

