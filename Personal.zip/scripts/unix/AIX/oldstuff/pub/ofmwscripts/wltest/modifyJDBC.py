#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#  This script is to modify the JDBC resources defined in the FMW environment
#  Created by: Michael Bai
#  Created on : May. 30, 2012
###############################################################################################################
import re, sys, wlstwrapper as ww, traceback
execfile("/ofmwscripts/wlstCustomUtils.py")
usageText = '''
         Usage: checkJMSConnection.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''
targetServer = ''
args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

print "Target Server:" + targetServer

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)

print "Check all JDBC resources' status....."
edit()
startEdit()
alljdbcSystemResources = cmo.getJDBCSystemResources()  
#print alljdbcSystemResources

for jdbcSystemResource in alljdbcSystemResources:
    # Set JDBC Driver properties

    jdbcResource=jdbcSystemResource.getJDBCResource()    
    xaBean = jdbcResource.getJDBCXAParams()
    xaBean.setXaTransactionTimeout(0)
    



save() 
activate()


disconnect()
exit()