#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : runDeploy.py  appHome [targetServer]
# Description: This script is to perform deployment task based on the properties file in 
#              which all composite applications is defined.
# Created by : Richard Wang
# Date       : Sep 6, 2011
# Updated    : Jan 16, 2012
#
###############################################################################################
import re
import sys
import os
import os.path
import commands
import random
from oracle.fabric.management.deployedcomposites import CompositeManager

# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script only function with the following prerequisites:
           [1] There must be an application created by JDeveloper;
           [2] There must be composites.properties file in which 
               all projects need to be deployed in this application 
               have to be defined with deployment requirements.
           [3] The name of target SAR(jar) file must be a regulated name
               grenated based on project name.

         Usage: runDdeploy.py [-r] -e environment
            -e: Environment, it must be LAB, DEV1 DEV2 TQA or PROD
            -r: re-pack the SAR(jar) file before deploying for clean-up,
                if no re-pack needed, don't use this it.
'''

loadProperties('/home/oraclesoa/wlst/serverEnv.properties')

# Check parameters
repack = False
targetServer = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip()
        args = args[2:]
    elif current_arg == '-r':
        repack = True
        args = args[1:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print usageText
    sys.exit()

# Lust all deployed composite applications for checking if we need to 
# undeploy prior to deploy.
deployedCompos = None
deployedCompList = []
print "Target Server:" + targetServer

if targetServer == 'dev1' or targetServer == 'DEV1':
    deployTargetServerUrl = dev1ServerUrl
    deployTargetUsername = dev1ServerUser
    deployTargetPassword = dev1ServerPassword
elif targetServer == 'dev2' or targetServer == 'DEV2':
    deployTargetServerUrl = dev2ServerUrl
    deployTargetUsername = dev2ServerUser
    deployTargetPassword = dev2ServerPassword
elif targetServer == 'tqa' or targetServer == 'TQA':
    deployTargetServerUrl = tqaServerUrl
    deployTargetUsername = tqaServerUser
    deployTargetPassword = tqaServerPassword
elif targetServer == 'prod' or targetServer == 'PROD':
    deployTargetServerUrl = prodServerUrl
    deployTargetUsername = prodServerUser
    deployTargetPassword = prodServerPassword

elif targetServer == 'lab' or targetServer == 'LAB':
    deployTargetServerUrl = labServerUrl
    deployTargetUsername = labServerUser
    deployTargetPassword = labServerPassword
else:
    deployTargetServerUrl = labServerUrl
    deployTargetUsername = labServerUser
    deployTargetPassword = labServerPassword

matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', deployTargetServerUrl)

if matchObj:  
    hostAddr = matchObj.group(1)
    hostPort = matchObj.group(2)
    print "Target server host=", hostAddr 
    print "Target server port=", hostPort
    
try:
    CompositeManager.initConnection(hostAddr, 
                        hostPort, 
                        deployTargetUsername, 
                        deployTargetPassword)
    clmMBean = CompositeManager.getCompositeLifeCycleMBean()
    if clmMBean == None:
        print 'Cannot find composite lifecycle mbean.'
        sys.exit()
        
    deployedComposites = CompositeManager.listDeployedComposites(clmMBean)
    compList = deployedComposites.split('\n')
    del compList[0:2]
    # Re organize the list, only the compositeName will be left
    for i in range(len(compList)):
        if compList[i] != '':
            #print "compList[i] = " + compList[i]
            iList = compList[i].split(",")
            #for j in range(len(iList)):
            #print "iList=", iList[0], iList[1]
            deployedCompList.append(iList[0].strip()+iList[1].strip())
        else:
            pass
    
    deployedCompos = " ".join(deployedCompList)
    # print "Deployed composite List:" 
    # print deployedComposites
 
except Exception, detail:
       print 'Exception:', detail
       sys.exit()

# Based on the appHome( Current working directory ), find the composites.properties file
appHome = os.getcwd()
if os.path.exists(appHome + "/composites.properties"):
    print "Found composites.properties under " + appHome
    prop = open(appHome + "/composites.properties", "r")
else:
    print "No properties file found under " + appHome
    sys.exit()

for line in prop:
    matchObj = re.match(r'(composite\d+=)(.*)', line)
    if matchObj: 
        composite = matchObj.groups('1')
        paramList = composite[1].split(",")
        compositeName = os.path.basename(paramList[0])
        compositeFullPath = (appHome  +'/' + compositeName).strip()
        print 'compositeFullPath=' , compositeFullPath
        print 'compositeName=' , compositeName
        # sar Location
        sarLoc = compositeFullPath + '/deploy/sca_' + compositeName + '_rev' + paramList[1] + '.jar'

        # Repackage the jar file
        if repack:
            try:
               workingDir = '/tmp/rpack' + str(random.randint(1000, 9999))
               targetJarHome = compositeFullPath + '/deploy'
               targetJarName = 'sca_' + compositeName + '_rev' + paramList[1] + '.jar'
               outMsg = commands.getstatusoutput('/home/oraclesoa/wlst/rpack.sh ' + targetJarHome + ' ' + targetJarName + ' ' + workingDir)
               outMsgList = list(outMsg)
               print "Return code from rpack.sh:", outMsgList[0]
               print "Message from rpack.sh:", outMsgList[1]
               if outMsgList[0] > 0:
                   sys.exit()
               else:
                   print "Execute outside script is done"
            except (IOError, os.error), why:
               print "Error occurred while executing outside shell script: " +  str(why)
            except Error, err:
               print "Error occurred while executing outside shell script: " + (err.args[0])
        else:
            pass

        if paramList[2] == 'true':
            ow = true
        else:
            ow = false
            
        if paramList[3] == 'true':
            fd = true
        else:
            fd = false
            
        # Automatically check if the configuration file is created,
        # and use it when deploying
        # The configuration plan's file name must be:
        #  compositeName + 'cfgplan_DEV1.xml' or 
        #  compositeName + 'cfgplan_DEV2.xml' or 
        #  compositeName + 'cfgplan_TQA.xml' or 
        #  compositeName + 'cfgplan_PROD.xml' or 
        if targetServer == 'lab' or targetServer == 'LAB':
            configurationPlan = compositeFullPath + '/' + compositeName + '_cfgplan_LAB.xml'
        elif targetServer == 'dev1' or targetServer == 'DEV1':
            configurationPlan = compositeFullPath + '/' + compositeName + '_cfgplan_DEV1.xml'
        elif targetServer == 'dev2' or targetServer == 'DEV2':
            configurationPlan = compositeFullPath + '/' + compositeName + '_cfgplan_DEV2.xml'
        elif targetServer == 'tqa' or targetServer == 'TQA':
            configurationPlan = compositeFullPath + '/' + compositeName + '_cfgplan_TQA.xml'
        elif targetServer == 'prod' or targetServer == 'PROD':
            configurationPlan = compositeFullPath + '/' + compositeName + '_cfgplan_PROD.xml'
        else:
            configurationPlan = compositeFullPath + '/' + compositeName + '_cfgplan.xml'

# Check if the composite has been deployed to the same server
# Undeploy the composite application before running the deployment
        matchString = compositeName + '[' + paramList[1] + ']' + 'partition=' + paramList[4].strip()
        if (deployedCompos.find(matchString) == -1):
            print compositeName + '[' + paramList[1] + ']' + " is the first time to deploy...."
        else:
            print compositeName + '[' + paramList[1] + ']' + " had been deployed before, undeploy it first...."
            sca_undeployComposite(deployTargetServerUrl, 
                        compositeName,
                        paramList[1],
                        user=deployTargetUsername,
                        password=deployTargetPassword,
                        partition=paramList[4])

# Deploy with plan
        if os.path.isfile(configurationPlan):
            print "Configuration plan to apply when deploying:"
            print configurationPlan

            sca_deployComposite(deployTargetServerUrl, 
                                sarLoc, 
                                ow, 
                                user=deployTargetUsername, 
                                password=deployTargetPassword, 
                                forceDefault=fd, 
                                configplan=configurationPlan, 
                                partition=paramList[4])
# Deploy without plan
        else:
            print "The followind configuration Plan was not found:"
            print "<<" + configurationPlan + ">>"

            sca_deployComposite(deployTargetServerUrl, 
                                sarLoc, 
                                ow, 
                                user=deployTargetUsername, 
                                password=deployTargetPassword, 
                                forceDefault=fd, 
                                partition=paramList[4])
# loop until all composites have been done.
print "Done"

