#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : listGroupMembers.py
# Description: This script is list up all users within the group they belong to.
#                   There are currently two LDAP providers: 
#                       (0) DefaultAuthenticator, which is for local user/group
#                       (1) EncanaAD ,Encana domain, which will not be used after migrating work is done.
#                       (2) CenovusAD, the one will be formally used.
#                   This program will list all groups from all avaiable providers right now.
#
# Created by : Richard Wang
# Date       : Aug 30, 2011	
#
###############################################################################################
import re
import sys
import os.path
from weblogic.management.security.authentication import MemberGroupListerMBean
from weblogic.management.security.authentication import UserReaderMBean
from weblogic.management.security.authentication import GroupReaderMBean
from weblogic.management.security.authentication import GroupEditorMBean
import wlstwrapper as ww

loadProperties('/home/oraclesoa/.serverEnv.properties')
execfile("/ofmwscripts/wlstCustomUtils.py")
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script to list group numbers authorized to access to the specified server.
         Usage: listGroupMembers.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''

targetServer = ''
# Check parameters
args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
print "Target Server:" + targetServer

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)

realm = cmo.getSecurityConfiguration().getDefaultRealm()
authProviders = realm.getAuthenticationProviders()

print 'List users categorized by group under the realm of ' + realm.getName() 

for provider in authProviders:
    print '----------------------------------------------------------------------------------------'
    print 'Provider Name: ' + provider.getName()
    if provider.getName() == 'DefaultAuthenticator': 
        cursor =  provider.listGroups("*",0) 
        while provider.haveCurrent(cursor): 
            groupName = provider.getCurrentName(cursor)    
            usergroup = provider.listAllUsersInGroup(groupName,"*",0) 
            print '----------------------------------------------------------------------------------------'
            print 'Local Group: ' + groupName 
            num = 1
            for user in usergroup: 
                print num, '--------', user
                num = num+1
            provider.advance(cursor) 
        provider.close(cursor) 
    else:
        if provider.getName() == 'DefaultIdentityAsserter':
            continue
        else:
            if provider.getName() == 'CenovusAD':
                userList = provider.listGroupMembers('OracleSOAAdmin', '*', 0)
                print '----------------------------------------------------------------------------------------'
                print 'CenovusAD users under the group <<OracleSOAAdmin>>:'
                print '----------------------------------------------------------------------------------------'
                num = 1
                while provider.haveCurrent(userList):
                    print num,'-------- '+ provider.getCurrentName(userList)
                    provider.advance(userList)
                    num = num+1
                provider.close(userList)

                userList = provider.listGroupMembers('OracleSOADeveloper', '*', 0)
                print '----------------------------------------------------------------------------------------'
                print 'CenovusAD users under the group <<OracleSOADeveloper>>:'
                print '----------------------------------------------------------------------------------------'
                num=1
                while provider.haveCurrent(userList):
                    print num,'-------- '+ provider.getCurrentName(userList)
                    provider.advance(userList)
                    num=num+1
                provider.close(userList)
            else:
                if provider.getName() == 'AD':
                    userList = provider.listGroupMembers('OracleSOAAdmin', '*', 0)
                    print '----------------------------------------------------------------------------------------'
                    print 'EncanaAD users under the group <<OracleSOAAdmin>>:'
                    print '----------------------------------------------------------------------------------------'
                    num=1
                    while provider.haveCurrent(userList):
                        print num,'-------- '+ provider.getCurrentName(userList)
                        provider.advance(userList)
                        num=num+1
                    provider.close(userList)

                    userList = provider.listGroupMembers('OracleSOADeveloper', '*', 0)
                    print '----------------------------------------------------------------------------------------'
                    print 'EncanaAD users under the group <<OracleSOADeveloper>>:'
                    print '----------------------------------------------------------------------------------------'
                    num=1
                    while provider.haveCurrent(userList):
                        print num,'-------- '+ provider.getCurrentName(userList)
                        provider.advance(userList)
                        num=num+1
                    provider.close(userList)
