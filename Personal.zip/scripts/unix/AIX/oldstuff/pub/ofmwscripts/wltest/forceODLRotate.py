#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

#=======================================================================================
# Description: This script is used for rotating Oracle Diagnostic log file immediately when 
#                    urgently need to reproduce issues and want to use a new ODL log file for 
#                    gathering the newly generated log messages.
# 
# Note:            The Log file will be rotated a few seconeds later after issuing this command.
#
# Usage:        From command line, key in the script name with the flag of true 
#                   or false like below:
#
#                  ./forceODLRotate.py    
#
#=======================================================================================
import re, sys, traceback
from datetime import datetime

print 'Force the ODL file to perform rotation.....'
#=======================================================================================
# Process the changes
#=======================================================================================

loadProperties('/home/oraclesoa/wlst/serverEnv.properties')

managedServerUrl = re.sub(':7001', ':8001', domainUrl)
connect(username, password, domainUrl)

now = datetime.now()

print str(now)

delayedTime =  str(now.hour)  + ':' + str(now.minute + 1) 

print 'Rotate timepoint will be:' , delayedTime

configureLogHandler(name="odl-handler", rotationFrequency="daily", baseRotationTime=delayedTime )

print 'Done.'

#=======================================================================================
# Exit WLST.
#=======================================================================================
exit()

