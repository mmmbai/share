#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : backupAllMetadata.py
# Description: This script is for exporting metadata from the MDS_repository to a pre-defined
#              directory. At this time, the repository partition is fixed to be
#              soa-infra (Application), it may be changed for applying any specified
#              applications.
# Created by : Richard Wang
# Date       : Sep 15, 2011
###############################################################################################
import re
import sys
import os
import datetime
applicationName = 'soa-infra'
mdsNamespace = "/apps/soa/**"
mdsExportBasePath = "/u01/MDS/"

       		
def monitorDBAdapter(serverName):
    cd("ServerRuntimes/"+str(serverName)+"/ApplicationRuntimes/DbAdapter/ComponentRuntimes/DbAdapter/ConnectionPools")
    connectionPools = ls(returnMap='true')
    print '--------------------------------------------------------------------------------'
    print 'DBAdapter Runtime details for '+ serverName
    print '-------------------------------------------------------------------------------'

    print '%10s %13s %15s %18s' % ('Connection Pool', 'State', 'Current', 'Created')
    print '%10s %10s %24s %21s' % ('', '', 'Capacity', 'Connections')
    print '--------------------------------------------------------------------------------'
	#print 'Active Connections Current Count ' + get('ActiveConnectionsCurrentCount')
    for connectionPool in connectionPools:
       ##if connectionPool!='eis/DB/SOADemo':
          cd('/')
          cd("ServerRuntimes/"+str(serverName)+"/ApplicationRuntimes/DbAdapter/ComponentRuntimes/DbAdapter/ConnectionPools/"+str(connectionPool))
          print '%15s %15s %10s %20s' % (cmo.getName(), cmo.getState(), cmo.getCurrentCapacity(), cmo.getConnectionsCreatedTotalCount())

    print '--------------------------------------------------------------------------------	'		

# Connect to the AdminServer
connect("weblogic", "tqa0fmw@dm1n123", "t3://tqasoaadmin.cenovus.com:7001")
#connect("weblogic", "soaprod01", "t3://prodsoaadmin.cenovus.com:7001")
'''
serverRuntime()
dsMBeans = cmo.getJDBCServiceRuntime().getJDBCDataSourceRuntimeMBeans() 
ds_name = "Soaevents" 
for ds in dsMBeans: 
      if (ds_name == ds.getName()): 
			print 'DS name is: '+ds.getName() 
			print 'State is ' +ds.getState()
			print ds.testPool()
'''			
targetServerName ="soa_server2"
servers=cmo.getServers()
domainRuntime()
print '--------------------------------------------------------------------------------	'
server_name ="soa_server2"
#ls()
cd("/ServerRuntimes/" + targetServerName+"/JDBCServiceRuntime/"+targetServerName+"/JDBCDataSourceRuntimeMBeans/SOAEvents")
#cd("/ServerRuntimes/" + targetServerName)
ls()
print'---------------'
'''
print 'JDBC Details'
print 'Active Connections Current Count '
print get('ActiveConnectionsCurrentCount')
print 'Active Connections High Count ' 
print get('ActiveConnectionsHighCount')
print 'Connection Delay Time '
print get('ConnectionDelayTime')
print 'Connections Total Count '
print get('ConnectionsTotalCount')
print 'Failures To Reconnect Count '
print get('FailuresToReconnectCount')
print 'Leaked Connection Count '
print get('LeakedConnectionCount')

'''

#cd("/JDBCDataSourceRuntimeMBeans/ConnectionPool")
#ls()
#if cmo.getState() == 'RUNNING':  
#monitorDBAdapter(targetServerName)



disconnect()
exit()

