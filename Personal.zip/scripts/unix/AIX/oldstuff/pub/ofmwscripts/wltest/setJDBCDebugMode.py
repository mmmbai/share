#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#
#  This script is to list up all JMS resources defined in the FMW environment and their status
#
#  Created by: Michael Bai
#  Created on : Feb. 21, 2012
#  Modified by: Richard Wang (May 3, 2012)
#
###############################################################################################################
import re, sys, traceback, wlstwrapper as ww 
execfile("/ofmwscripts/wlstCustomUtils.py")

usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to switch JDBC debug mode between 'ON' and 'OFF'

         Usage: setJMSDebugMode.py -e environment -m JDBC_DEBUG_MODE
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA, or PROD
            -m: JDBC_DEBUG_MODE, must be ON or OFF
'''

def setJDBCDebugMode( soaServer, flag ):
    # Compose the path to the MBean based on the SOA Server name
    path = 'Servers/' + soaServer + '/ServerDebug/' + soaServer;
    cd(path);
    set('DebugJDBCConn',flag);
    set('DebugJDBCDriverLogging',flag);
    set('DebugJDBCInternal',flag);
    set('DebugJDBCONS',flag);
    set('DebugJDBCRAC',flag);
    set('DebugJDBCRMI',flag);
    set('DebugJDBCSQL',flag);
    return
    
# Main routine
targetServer = ''
isCluster = False
mode = ''
sw = ''

# Determine the target environment
args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-m':
        mode = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]

print "Target Server:" + targetServer
print "Debug Mode:" + mode

if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

if mode != 'ON' and mode != 'OFF':
    print ww.bcolors.RED + "Invalid debug mode" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
elif mode == 'ON':
    sw = 'true'
else:
    sw = 'false'

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)
    edit()
    startEdit()
    setJDBCDebugMode('soa_server1', sw) 
    if isCluster:
        setJDBCDebugMode('soa_server2', sw) 
    save();
    activate()
    disconnect()
    exit(exitcode=0)
