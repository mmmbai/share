#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : createPartitions.py
# Description: This script is usually for creating multi-partitions as a part of system 
#                    environment configuration.  As it is not used often, the partition list 
#                    is defined in this script, but the system information is referred from 
#                    serverEnv.properties file.
#
#Note            : This command is for those of specific managed servers .
#                     Please be careful using the managed server port number. 
#                     If the URL is cluster admin server, then all partitions will be created in
#                     all cluster members.
#
# Created by : Richard Wang
# Date          : Aug 18, 2011
#
###############################################################################################
import re
import sys
import os.path
import wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to create a new partition in specified SOA server.
         Usage: createPartition.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
            -p: Partition name
'''

print "Create a new partition....."
#=======================================================================================
# Process the changes
#=======================================================================================
targetServer = ''
partitionName = ''
args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-p':
        partitionName = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '' or partitionName == '':
    print ww.bcolors.RED + "Invalid target server or partition name?" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

# Connect to the AdminServer
print "Target Server:" + targetServer
print "Partition Name:" + partitionName

serverUrl = getServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    try:
        connect(os.getenv('un'), os.getenv('pw'), serverUrl)
        sca_deletePartition(partitionName)
    except Exception, detail:
        print 'Exception:', detail
        dumpStack()
        sys.exit()

disconnect()
exit()

