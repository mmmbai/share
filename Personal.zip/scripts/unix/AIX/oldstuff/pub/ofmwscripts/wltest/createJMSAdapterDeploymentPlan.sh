#!/usr/bin/env  bash

ADAPTER_HOME=/u01/app/oracle/fmw/Oracle_SOA1/soa/connectors

# parse the optional argument
VERBOSE=0;

if [[ $1 = -fn ]]
then
	VERBOSE=1;
	shift;
fi

if (( VERBOSE == 0 ))
then
	echo "You have to specify the parameter '-fn'."
	exit 
else
	if [[ $1 = '' ]]
	then
		echo "The plan file name with full path must be provided!"
		echo "For example, /u01/domains/soa_domain/Plan/JMSPlan.xml"
	else
		echo "Deployment file name is :" $1
		export CLASSPATH=$CLASSPATH:/u01/app/oracle/fmw/wlserver_10.3/server/lib/weblogic.jar
		java weblogic.PlanGenerator -plan $1 $ADAPTER_HOME/JmsAdapter.rar
	fi
fi
exit
