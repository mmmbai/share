#!/usr/bin/perl -w
# This script is to pickup blocks around the target word specified by -t parameter 
# from a specified file by -f parameter. Especially for the following files:
#    soa_server*.log, 
#    soa_server*.out 
#    soa_server*-diagnostic.log
# Please be notice that because the boundary between different message blocks
# are very hard to distinguish, and different file may have different boundry,
# the block picked up by this script is not a precise sometimes.
#
# Usage
# ggrep.pl -t <target pattern> -f <input file>

use strict;
use Getopt::Long;
use Term::ANSIColor;

sub backwardSearch{
    my ($fileName, $totalLines, $linecount, $boundary) = @_;
    my @backwardMatchs = ();
    my $pid = open(RFH, "tac $fileName |") or die "$!\n";
    my $startLine = $totalLines - $linecount + 1;
    my $subLineCount = 0;
    while (<RFH>){
        # chomp($_);
        $subLineCount++;
        if ($subLineCount > $startLine){
            push(@backwardMatchs, $_);
            if ( /($boundary)/ ) {
                last;
            }
        }
    }
    close (RFH);
    #foreach (@backwardMatchs){
    #    print;
    #}
    return (reverse(@backwardMatchs));
}

sub forwardSearch{
    my ($fileName, $totalLines, $fromLine, $boundary) = @_;
    my @forwardMatchs = ();
    my $pid = open(FH, "$fileName") or die "$!\n";
    my $lineCount = 0;
    while (<FH>){
        $lineCount++;
        if ($lineCount >= $fromLine){
            push(@forwardMatchs, $_);
            if ( /($boundary)/ ) {
                last;
            }
        }
    }
    close(FH);
    return ( @forwardMatchs );
}

my($target, $file);

GetOptions(
    "target=s"   => \$target,
    "file=s"    => \$file,
    );

die "$0 -t <target pattern> -f <input file>" unless ($target && $file);

# For test, Boundary = "WANG"
# my $boundary = "WANG";
my $boundary;
my @oneMatch = ();
my @beforeMatchs = ();
my @afterMatchs = ();
my $oneline = "";
my $matching;
my $linecount = 0;
my $subLinecount = 0;

if( defined( $file ) && -e $file ){
    open( IN, $file ) || die "couldn't open file";
    if ( $file =~ /diagnostic/ ){
        $boundary = "\\[(19|20)\\d\\d-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])";
    }elsif (( $file =~ /soa_server[12]\.out/ ) || ($file =~ /soa_server[12]\.log/ )){
        $boundary = "\\#*\\<(Mar|Jun|Jan|Feb|Apr|May|Jul|Aug|Sep|Oct|Nov|Dec)\\s+(([1-9])|([1-2][0-9])|(3[0-1]))";
    }else {
        $boundary = "\$\\n";
    }

my $totalLines = (qx/wc -l < $file/) + 1;
print "TOTAL LINES = " . $totalLines . "\n";

    while( my $line = readline *IN){
        
        $linecount++;
        if( $line =~ /($target)/ ){
            # $matching = "true";
            ## Do backward search util find the StartLine
            print colored ("-----------------------------------------------------Line Number=$.",  'bold yellow on_red'); 
            print colored ("--------------------------------------------------------------", 'bold yellow on_red'), "\n"; 
            if ( $line =~ /^($boundary)/ ){
                push(@beforeMatchs, $line);
            } else{
                @beforeMatchs = backwardSearch($file, $totalLines, $linecount, $boundary);
            }
            ## Do forword search until find the Endline
            @afterMatchs = forwardSearch($file, $totalLines, $linecount - 1, $boundary);
            ## Concatenate the matches
            @oneMatch = (@beforeMatchs, @afterMatchs);
            foreach (@oneMatch){
                print;
            }
            next;
        }
    }
}