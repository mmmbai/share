import sys  
from java.util import Date  
  
ECODE='\n \033[0m' # ending of color code  
  
def ThreadCnt():  
    try:  
        print 'Connecting to Admin server....'  
        connect(userConfigFile=ucf, userKeyFile=ukf, url='t3://admindns:port')  
    except:  
        print 'Admin Server NOT in RUNNING state....'  
    urldict={}  
    serverlist=getRunningServerNames()  # Getting Serverlist  
    for svr in serverlist:  
        cd("/Servers/"+svr.getName())  
        urldict[svr.getName()]='t3://'+get('ListenAddress')+':'+str(get('ListenPort'))  
  
    x = raw_input('Enter a server instance name : ')  
    try:  
        connect(userConfigFile=ucf, userKeyFile=ukf,url=urldict[x])  
        serverRuntime()  
        openSocks = cmo.getOpenSocketsCurrentCount();  
        print('Open Sockets:: ' + str(openSocks));  
        cd('serverRuntime:/ThreadPoolRuntime/ThreadPoolRuntime/')  
        compReq = cmo.getCompletedRequestCount()  
        status = cmo.getHealthState()  
        hoggingThreads = cmo.getHoggingThreadCount()  
        totalThreads = cmo.getExecuteThreadTotalCount()  
        idleThrds = cmo.getExecuteThreadIdleCount()  
        pending = cmo.getPendingUserRequestCount()  
        qLen = cmo.getQueueLength()  
        thruput = cmo.getThroughput()  
        if idleThrds == 0:  
            pstr='\033[1;47;31m'    # RED color  
        else:  
            pstr='\033[1;40;32m'    # GREEN color  
        print(pstr+'Status of the Server: ' + str(status)  +ECODE  
            +'The completed Requests: ' + str(compReq) +ECODE'  
            +'Total the threads no s: ' + str(totalThreads)+ECODE  
            +'The Idle threads: ' + str(idleThrds)+ECODE  
            +'Hogging threads : ' + str(hoggingThreads)+ECODE  
            +'Pending : ' + str(pending)+ECODE  
            +'ThreadPool QueueLength: ' + str(qLen)+ECODE  
            +'Server (Throughput): ' +str(thruput)+ECODE)  
    except:  
        print 'Exception... Unable to connect to given Server', x  
        pass  
    quit()  
  
def quit():  
    d = Date() # now  
    print  d  
    print '\033[1;40;32mHit any key to Re-RUN this script ...'+ECODE  
    Ans = raw_input("Are you sure Quit from WLST... (y/n)")  
    if (Ans == 'y'):  
         disconnect()  
        stopRedirect()  
        exit()  
    else:  
        ThreadCnt()  
  
def getRunningServerNames():  
    domainConfig()  
    return cmo.getServers()  
  
if __name__== "main":  
    redirect('./logs/ThreadCntwlst.log', 'false')  
    ThreadCnt()  
    print 'done'     