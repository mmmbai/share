#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
import sys, re, traceback, wlstwrapper as ww 
execfile("/ofmwscripts/wlstCustomUtils.py")

usageText = '''
                <<<<< Pre-condition to run this script >>>>>
        This script is used for rotating log file immediately when urgently 
        need to reproduce issues and want to set a new log file for gathering 
        the newly generated log messages.
        (including AdminServer.log, soa_server1.log and soa_server2(in case of cluster).
        
        Usage: forceLogRotate.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, (TST), TQA, or PROD
'''
targetServer = ''

# Check parameters 
args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]

print "Target Server:" + targetServer

if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    exit(exitcode=100)

adminServerUrl = getAdminServerT3Url(targetServer)
if adminServerUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    exit(exitcode=100)
else:
    connect(os.getenv('un'), os.getenv('pw'), adminServerUrl)
    #edit()
    #startEdit()
    domainRuntime()
    cd('ServerRuntimes/AdminServer/LogRuntime/AdminServer')
    #force the immediate rotation of the server log file
    cmo.forceLogRotation()
    print 'The AdminServer log file has been force rotated.'
    disconnect()
    
    managedServerUrl = re.sub(':7001', ':8001', adminServerUrl)
    connect(os.getenv('un'), os.getenv('pw'), managedServerUrl)
    serverRuntime()
    #domainRuntime()
    if isCluster:
        cd('LogRuntime/soa_server1')
        cmo.forceLogRotation()
        print 'The soa_server1 log file has been force rotated.'
        cd('LogRuntime/soa_server2')
        cmo.forceLogRotation()
        print 'The soa_server2 log file has been force rotated.'
    else:
        cd('LogRuntime/soa_server1')
        cmo.forceLogRotation()
        print 'The soa_server1 log file has been force rotated.'
    disconnect()
    #save()
    #activate()
#=======================================================================================
# Exit WLST.
#=======================================================================================
exit(exitcode=0)
