#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : importMetadata.py nameSpaceOfDocument
# Description: This script is for importing metadata from a pre-defined directory to 
#              the MDS_repository. At this time, the repository partition is fixed to be 
#              soa-infra (Application), it may be changed for applying any specified
#              applications.
#
#              (1) Server infomation is from serverEnv.properties
#              (2) All the Metadata is stored under the /home/oraclesoa/appDock/ with 
#                  different folder name.
#                  In the serverEnv.properties file, we defined a 'mdBaseDir' as default 
#                  mds folder. if no parameter specified, all the metadata under forementioned 
#                  folder will be imported, but you can specify w folder name which is under
#                  /home/oraclesoa/appDock/ for a specific mds like XXXXXXX to import from, 
#                  in this case, the path to metadata or directory of the metadata should 
#                  be /home/oraclesoa/appDock/XXXXXXXX plus the sub-directory you 
#                  specified:
#                  importMetadata.py
#                  importMetadata.py XXXXXXXX 
#
# Created by : Richard Wang
# Date       : Nov 8, 2011    
#        
###############################################################################################             
import re
import sys
import os

applicationName = 'soa-infra'

# Load server properties
loadProperties('/home/oraclesoa/wltest/serverEnv.properties')

# Check parameters
params = len(sys.argv) - 1

if params == 1:
    pathToMD = '/home/oraclesoa/appDock/' + sys.argv[1]
else:
    pathToMD = mdBaseDir.strip(' ')

print 'The path to metadata or folder to deploy is :' , pathToMD
yesno = raw_input('Are you going to continue(Yes/yes/y OR No/no/n)?')
if (yesno.strip().upper() != 'Y' and yesno.strip().upper() != 'YES'):
    sys.exit()

# Connect to the AdminServer
connect(mdsDestinationUser, mdsDestinationPassword, mdsDestinationDomainUrl)
domainConfig() 

print 'Run import.....'
try:
    importMetadata(application=applicationName,
                    server=mdsDestinationManagedServer.strip(' '), 
                    fromLocation=pathToMD, docs='/**')
except WLSTException:
    dumpStack()
    
print 'Done.'
disconnect()
exit()

