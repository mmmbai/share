#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : startApps.py
# Description: This script is always being called from "startApps" bash script to
#        to perform starting multiple applications defined in deploy.properties file.
# Created by : Richard Wang
# Date       : July 12, 2011    
#        
###############################################################################################             
import re
import sys
import os.path
import wlstwrapper as ww
from weblogic.management.security.authentication import MemberGroupListerMBean
from weblogic.management.security.authentication import UserReaderMBean
from weblogic.management.security.authentication import GroupReaderMBean
execfile("/ofmwscripts/wlstCustomUtils.py")
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script to list all users who are granted to access this server.
         Usage: listUsers.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''

targetServer = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

showAllAuthenticatorUserList  = 'false'
userNameWildcard = '*'

serverUrl = getAdminServerT3Url(targetServer) 
# Connect to the AdminServer
connect(os.getenv('un'), os.getenv('pw'), serverUrl)

realm = cmo.getSecurityConfiguration().getDefaultRealm()
authProviders = realm.getAuthenticationProviders()

for provider in authProviders:
    if isinstance(provider, UserReaderMBean):
        authName= provider.getName()

        if showAllAuthenticatorUserList == 'true':
            userList = provider.listUsers(str(userNameWildcard),int(0))
            print '======================================================================'
            print 'Below are the List of USERS which are in the: "'+provider.getName+'"'
            print '======================================================================'
            num=1
            while provider.haveCurrent(userList):
                print num,'- '+ provider.getCurrentName(userList)
                provider.advance(userList)
                num=num+1
            provider.close(userList)

        else:
            if authName == 'DefaultAuthenticator':
                print '======================================================================'
                print "Local users: "
                print '======================================================================'
                userList = provider.listUsers(userNameWildcard,int(0))
                num=1
                while provider.haveCurrent(userList):
                    print num,'-------- '+ provider.getCurrentName(userList)
                    provider.advance(userList)
                    num=num+1
                provider.close(userList)
            else:
                if authName == 'CenovusAD':
                    userList = provider.listGroupMembers('OracleSOAAdmin', '*', 0)
                    print '======================================================================'
                    print 'CenovusAD users under the group <<OracleSOAAdmin>>:'
                    print '======================================================================'
                    num=1
                    while provider.haveCurrent(userList):
                        print num,'-------- '+ provider.getCurrentName(userList)
                        provider.advance(userList)
                        num=num+1
                    provider.close(userList)

                    userList = provider.listGroupMembers('OracleSOADeveloper', '*', 0)
                    print '======================================================================'
                    print 'CenovusAD users under the group <<OracleSOADeveloper>>:'
                    print '======================================================================'
                    num=1
                    while provider.haveCurrent(userList):
                        print num,'-------- '+ provider.getCurrentName(userList)
                        provider.advance(userList)
                        num=num+1
                    provider.close(userList)
                else:
                    if authName == 'AD':
                        userList = provider.listGroupMembers('OracleSOAAdmin', '*', 0)
                        print '======================================================================'
                        print 'EncanaAD users under the group <<OracleSOAAdmin>>:'
                        print '======================================================================'
                        num=1
                        while provider.haveCurrent(userList):
                            print num,'-------- '+ provider.getCurrentName(userList)
                            provider.advance(userList)
                            num=num+1
                        provider.close(userList)

                        userList = provider.listGroupMembers('OracleSOADeveloper', '*', 0)
                        print '======================================================================'
                        print 'EncanaAD users under the group <<OracleSOADeveloper>>:'
                        print '======================================================================'
                        num=1
                        while provider.haveCurrent(userList):
                            print num,'-------- '+ provider.getCurrentName(userList)
                            provider.advance(userList)
                            num=num+1
                        provider.close(userList)
disconnect()
exit()

