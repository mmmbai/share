#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
connect('weblogic','labsoa01','iv00046p.cenovus.com:7001')
from time import strftime
from java.text import SimpleDateFormat
serverName = 'soa_server1'
counter = 0
sleepTime = 30000
threadSnapNo = 2
for counter in range(threadSnapNo):
    currentDate = java.util.Date().toString()
    myDate = currentDate.split(' ');
    finalDate = myDate[3]
    java.lang.Thread.sleep(sleepTime)
    fileName = 'dump' + '_' + serverName + '_' + finalDate + '_' + str(counter) + '.dmp'
    threadDump('true', fileName, serverName)
disconnect()
