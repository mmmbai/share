#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : listDeployedComposites.py  [ LAB | DEV1 | DEV2 | TQA | PROD ]
# Description: This script is to display all deployed composites
# Created by : Richard Wang
# Modified Date: Jan 31, 2012
#
###############################################################################################
import re
import sys
import os.path
import commands
from oracle.fabric.management.deployedcomposites import CompositeManager

loadProperties('/home/oraclesoa/.serverEnv.properties')
TEMP_FILE='/home/oraclesoa/.deployedComposites'

# Check parameters
params = len(sys.argv) - 1

if params == 1:
    targetServer = sys.argv[1]
else:
    if params == 0:
        targetServer = defaultTargetServer


deployedCompos = None
deployedCompList = []

# print "Target Server:" + targetServer

if targetServer == 'dev1' or targetServer == 'DEV1':
    deployTargetServerUrl = dev1ServerUrl
    deployTargetUsername = dev1ServerUser
    deployTargetPassword = dev1ServerPassword
elif targetServer == 'dev2' or targetServer == 'DEV2':
    deployTargetServerUrl = dev2ServerUrl
    deployTargetUsername = dev2ServerUser
    deployTargetPassword = dev2ServerPassword
elif targetServer == 'tqa' or targetServer == 'TQA':
    deployTargetServerUrl = tqaServerUrl
    deployTargetUsername = tqaServerUser
    deployTargetPassword = tqaServerPassword
elif targetServer == 'prod' or targetServer == 'PROD':
    deployTargetServerUrl = prodServerUrl
    deployTargetUsername = prodServerUser
    deployTargetPassword = prodServerPassword
elif targetServer == 'tst' or targetServer == 'TST':
    deployTargetServerUrl = tstServerUrl
    deployTargetUsername = tstServerUser
    deployTargetPassword = tstServerPassword


elif targetServer == 'lab' or targetServer == 'LAB':
    deployTargetServerUrl = labServerUrl
    deployTargetUsername = labServerUser
    deployTargetPassword = labServerPassword
else:
    print "No valid server selected."
    sys.exit()

matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', deployTargetServerUrl)

if matchObj:  
    hostAddr = matchObj.group(1)
    hostPort = matchObj.group(2)
    # print "Target server host=", hostAddr 
    # print "Target server port=", hostPort
    
try:
    CompositeManager.initConnection(hostAddr, 
                        hostPort, 
                        deployTargetUsername, 
                        deployTargetPassword)
    clmMBean = CompositeManager.getCompositeLifeCycleMBean()
    if clmMBean == None:
        print 'Cannot find composite lifecycle mbean.'
        sys.exit()
        
    deployedComposites = CompositeManager.listDeployedComposites(clmMBean)
    # compList = deployedComposites.split('\n')
    # del compList[0:2]
    tf = open(TEMP_FILE,'w')
    tf.writelines(deployedComposites)
    tf.close()
except Exception, detail:
       print 'Exception:', detail
       sys.exit()

print "Done"
    
