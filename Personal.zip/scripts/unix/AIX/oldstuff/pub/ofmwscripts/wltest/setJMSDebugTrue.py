#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#
#  This script is to list up all JMS resources defined in the FMW environment and their status
#
#  Created by: Michael Bai
#  Created on : Feb. 21, 2012
#
###############################################################################################################
import re, sys, traceback
loadProperties('/home/oraclesoa/wlst/serverEnv.properties')

# Connect to the soa
connect(username, password, domainUrl)
edit();	
startEdit();		
cd('Servers/soa_server1/ServerDebug/soa_server1');		
set('DebugJMSBackEnd','true');
set('DebugJMSBoot','true');
set('DebugJMSCDS','true');
set('DebugJMSCommon','true');
set('DebugJMSConfig','true');
set('DebugJMSDispatcher','true');
set('DebugJMSDistTopic','true');
set('DebugJMSDurableSubscribers','true');
set('DebugJMSFrontEnd','true');
set('DebugJMSJDBCScavengeOnFlush','true');
set('DebugJMSLocking','true');
set('DebugJMSMessagePath','true');
set('DebugJMSModule','true');
set('DebugJMSPauseResume','true');
set('DebugJMSSAF','true');
set('DebugJMSStore','true');
set('DebugJMST3Server','true');
set('DebugJMSWrappers','true');
set('DebugJMSXA','true');
save();	
activate();