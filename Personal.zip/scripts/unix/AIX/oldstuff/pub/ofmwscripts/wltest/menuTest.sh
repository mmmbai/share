#!/bin/bash

# setup colors
ESC_SEQ="\x1b["
COL_RESET=$ESC_SEQ"39;49;00m"
COL_RED=$ESC_SEQ"31;01m"
COL_YELLOW=$ESC_SEQ"33;01m"
COL_CYAN=$ESC_SEQ"36;01m"
COL_GREEN=$ESC_SEQ"32;01m"
COL_MAGENTA=$ESC_SEQ"35;01m"
COL_BLUE=$ESC_SEQ"34;01m"

COL_QUIT=`echo -e ${COL_YELLOW}"Return to Main"${COL_RESET}`
COL_EXIT=`echo -e ${COL_RED}"EXIT"${COL_RESET}`
COL_MAIN_TITLE=`echo -e ${COL_GREEN}"Choose a number for the type of Integration you wish to start/stop or ${COL_EXIT}"${COL_RESET}`
COL_JDE_TITLE=`echo -e ${COL_CYAN}"Choose a number for the JDE  Adapter or ${COL_QUIT}"${COL_RESET}`
COL_ADB_TITLE=`echo -e ${COL_BLUE}"Choose a number for the ADB Adapter or ${COL_QUIT}"${COL_RESET}`
COL_REPO_TITLE=`echo -e ${COL_MAGENTA}"Choose a number for a repository or ${COL_QUIT}"${COL_RESET}`
COL_TEMPLATE_TITLE=`echo -e ${COL_CYAN}"Choose a number for the template or ${COL_QUIT}"${COL_RESET}`
COL_SERVICES_TITLE=`echo -e ${COL_CYAN}"Choose a number for the Service or ${COL_QUIT}"${COL_RESET}`

function start_message
{
	echo ""
	echo -e ${COL_RED}"Note: Remember to enter any adapters last."${COL_RESET}
	echo ""
}

function completion_message
{
	echo "Exiting gracefully...check your results at: ${FOLDER_PATH}"
	echo ""
	echo "Be sure to test your scripts using the commands:"
	echo "${FOLDER_PATH}/${FOLDER_LABEL}.at.stop.status"
	echo "${FOLDER_PATH}/${FOLDER_LABEL}.at.start.status"
	echo ""
	echo -e ${COL_BLUE}"Create your AT job now with the following paths:"${COL_RESET}
	echo "${FOLDER_PATH}/${FOLDER_LABEL}.at.stop"
	echo "${FOLDER_PATH}/${FOLDER_LABEL}.at.start"
}

function remove_directory
{
        DIRECTORY="${1}"
        if [[ -d ${DIRECTORY} ]]; then
                rm -rf ${DIRECTORY}
        fi
}

function get_jde_adapter_list
{
        ls -l /apps/tibco/Adapters/ | grep -i 'jde' | grep '^lrwxr' | awk -F' ' '{ print $9 }' > ${TEMP_FILE}
}


function get_services_list
{
	ls /apps/tibco/Services/ | grep '^K' >> ${TEMP_FILE}
}

function adb_adapter_selection
{
	echo ${COL_ADB_TITLE}
        select ADB_ADAPTER in $(<${TEMP_FILE}) "${COL_QUIT}"
        do
	        if [[ "${ADB_ADAPTER}" = "${COL_QUIT}" ]]; then
     			display_main_menu_choices
        	   	rm -f ${TEMP_FILE}
	                break # go back to higher menu
		else
	        	echo "Writing logger and command /apps/tibco/AdapterControl ${ADB_ADAPTER} (stop/start)"
	                # write the command into the AT file
                	write_adb_command "${ADB_ADAPTER}"
   		fi
        done
}


function display_main_menu_choices
{
	echo ""
	echo -e ${COL_GREEN}"----------------------------------"
	echo -e "You are now back at the main menu."
	echo -e "----------------------------------"${COL_RESET}

	echo ${COL_MAIN_TITLE}
	echo "Please make another selection:"
	echo "(1) Engine"
	echo "(2) JDE Adapter"
	echo "(3) AD Adapter"
	echo "(4) Template Selection"
	echo "(5) Service Selection"
	echo -e "(6) ${COL_EXIT}"${COL_RESET}
	echo ""
}

function services_selection
{
        echo ${COL_SERVICES_TITLE}
                select SERVICE in $(<${TEMP_FILE}) "${COL_QUIT}"
                do
                        if [[ "${SERVICE}" = "${COL_QUIT}" ]]; then
                                display_main_menu_choices
                                rm -f ${TEMP_FILE}
                                break # go back to higher menu
                        else
                                echo "Writing logger and command /apps/tibco/Services/${SERVICE}"
                                # write the command into the AT file
                                write_services_command "/apps/tibco/Services/${SERVICE}"
                        fi
                done
}

function template_selection
{
	echo ${COL_TEMPLATE_TITLE}

	select TEMPLATE in $(<${TEMP_FILE}) "${COL_QUIT}"
	do
		if [[ "${TEMPLATE}" = "${COL_QUIT}" ]]; then
			rm -f ${TEMP_FILE}
			break # go back to higher menu
		else
			echo "Creating stop and start files for template ${TEMPLATE}"
			# copy the cws template stop and start files
			copy_template_files ${TEMPLATE}
			create_status_files
			make_files_executable
		fi
	done
}

function make_files_executable
{
	# chmod +x on each file in the directory
	chmod +x "${FOLDER_PATH}/${FOLDER_LABEL}.at.stop"
	chmod +x "${FOLDER_PATH}/${FOLDER_LABEL}.at.start"
	chmod +x "${FOLDER_PATH}/${FOLDER_LABEL}.at.stop.status"
	chmod +x "${FOLDER_PATH}/${FOLDER_LABEL}.at.start.status"
}

function main_menu
{
	# clear the screen
	clear

	# display a welcome message with some instructions

	echo ${COL_MAIN_TITLE}
	start_message

	select INTEGRATION in "Engine" "JDE Adapter" "AD Adapter" "Template Selection" "Services Selection" "${COL_EXIT}"
	do
	        case "${INTEGRATION}" in
                      "Engine")
                                # add in selection of all engine in Repositories directory
                                get_repository_list
                                repository_selection "${TEMP_FILE}"
			;;
	                "JDE Adapter")
	                        # add in selection of all JDE Adapters for this server
	                	get_jde_adapter_list
				jde_adapter_selection "${TEMP_FILE}"
			;;
	                "AD Adapter")
	                        # add in selection of all AD Adapters for this server
				get_adb_adapter_list
				adb_adapter_selection "${TEMP_FILE}"
	                ;;
			"Template Selection")
				# the user wishes to choose from the ~/lib/shell_lib/templates directory
				get_template_list
				template_selection "${TEMP_FILE}"
				completion_message
				exit 0
			;;
			"Services Selection")
				# add in selection of all ~/Services scripts on this server
				get_services_list
				services_selection "${TEMP_FILE}"
			;;
	                "${COL_EXIT}")
				create_start_file
				create_status_files
				make_files_executable
				completion_message
	                        exit 0
			;;
	                *)
	                        echo "Invalid selection, exiting now!"
	                        remove_directory "${FOLDER_PATH}"
	                        exit -1
	                ;;
	        esac
	done
}
