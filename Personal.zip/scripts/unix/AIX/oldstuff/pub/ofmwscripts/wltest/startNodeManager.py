#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : startNodeManger.py
# Description: This script is to start Node Manager on the node you logged in. 
#              First, check if the node manager is already up or not.
# Created by : Richard Wang
# Date       : May 15, 2012
# Updated    : 
#
###############################################################################################
import sys
import os
import wlstwrapper as ww

loadProperties('/home/oraclesoa/.serverEnv.properties')
if nmIsVerbose.lower() == 'true':
    isVerbose = True
else:
    isVerbose = False
try:
    startNodeManager(verbose=nmIsVerbose.lower(),
            NodeManagerHome=nmHome,
            ListenPort=nmPort,
            ListenAddress=nmHost)
    nmDisconnect()
    exit(exitcode=0)
except WLSTException, detail:
       print 'Exception:', detail
       dumpStack()
       exit(exitcode=100)
