#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# This program is called by other, not a standalone executable version.
# Usage:         startComposite.py TargetServer Partition Composite Revision 
# Created by:    Richard Wang
# Created Date:  March 15, 2012
###############################################################################################
import re
import sys
import os.path
import commands
resourceProp = ''
loadProperties('/home/oraclesoa/.serverEnv.properties')
args = sys.argv[:]
targetServer = args[1].strip()
part = args[2].strip()
compositeName = args[3].strip()
compositeRev = args[4].strip()

print "TargetServer:" + targetServer
print "compositeName =" + compositeName
print "compositeRev =" + compositeRev
print "partition =" + part

if targetServer == 'dev1' or targetServer == 'DEV1':
    deployTargetServerUrl = dev1ServerUrl
    deployTargetUsername = dev1ServerUser
    deployTargetPassword = dev1ServerPassword
elif targetServer == 'dev2' or targetServer == 'DEV2':
    deployTargetServerUrl = dev2ServerUrl
    deployTargetUsername = dev2ServerUser
    deployTargetPassword = dev2ServerPassword
elif targetServer == 'tqa' or targetServer == 'TQA':
    deployTargetServerUrl = tqaServerUrl
    deployTargetUsername = tqaServerUser
    deployTargetPassword = tqaServerPassword
elif targetServer == 'prod' or targetServer == 'PROD':
    deployTargetServerUrl = prodServerUrl
    deployTargetUsername = prodServerUser
    deployTargetPassword = prodServerPassword
elif targetServer == 'lab' or targetServer == 'LAB':
    deployTargetServerUrl = labServerUrl
    deployTargetUsername = labServerUser
    deployTargetPassword = labServerPassword
else:
    print "No valid SOA server specified."
    sys.exit()
try:
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', deployTargetServerUrl)
    if matchObj:  
        hostAddr = matchObj.group(1)
        hostPort = matchObj.group(2)
        print "Target server host=", hostAddr 
        print "Target server port=", hostPort
        sca_startComposite(hostAddr,
                            hostPort,
                            deployTargetUsername,
                            deployTargetPassword, 
                            compositeName,
                            compositeRev,
                            partition=part)
except Exception, detail:
       print 'Exception:', detail
       sys.exit()

print "Done"
    


