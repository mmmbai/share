#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#
#  This script is to check the health of Threads Pool in a regular time interval
#
#  Created by: Richard Wang
#  Created on : Feb 18, 2012
#
###############################################################################################################

import re, sys, string, traceback
import wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
    Usage: monitorServers.py -e environment
           -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''

MAIL_TITLE = '"ALERT: Server state Health is in WARNING !!! " '
MAILING_LIST= ("Azhar.Manzoor@cenovus.com," + 
              "michael.bai@cenovus.com," +
              "richard.wang@cenovus.com," +
              "jim.he@cenovus.com")

def serverStatus(server):
    cd('/ServerLifeCycleRuntimes/' + server)
    return cmo.getState()

def getServerNames():
    domainConfig()
    return cmo.getServers()

def sendMailString():
    os.system('/bin/mailx -s ' + MAIL_TITLE + '  ' + MAILING_LIST + ' < rw_file')
    print '*********  ALERT MAIL HAS BEEN SENT  ***********'
    print ''

def alertServerHealth(env, serverName, healthState):
    state ="Checking HealthState: " + str(healthState)
    check = string.find(state,"RUNNING")
    if check == -1 and (serverName == 'soa_server1' 
                        or serverName == 'AdminServer'
                        or serverName == 'soa_server2'): 
        print '!!!! ALERT !!!! ' + serverName + ' is not in RUNNING state'
        print ''
        message =  'Please Check the server ' + serverName + ' of ' + env + ' is not in RUNNING State.'
        cmd = "echo " + message +" > rw_file"
        os.system(cmd)
        sendMailString()
        sys.exit()
    else:
        pass

def printHeapSizeInfo(env):
    serverNames=getServerNames()
    domainRuntime()
    print " Server       Heap Max   Heap Current   Heap Free Current   Heap Free Percent   Throughput"
    print "------------------------------------------------------------------------------------------"

    for name in serverNames:
        serverState = serverStatus(name.getName())
        if serverState == "RUNNING":
            # print "\nServer " + name.getName() + " is " + serverState
            cd("/ServerRuntimes/"+name.getName()+"/ThreadPoolRuntime/ThreadPoolRuntime")
            tput=cmo.getThroughput()
            cd("/ServerRuntimes/" + name.getName() + "/JVMRuntime/" + name.getName())
            heapSizeMax=cmo.getHeapSizeMax()
            heapSizeCurrent=cmo.getHeapSizeCurrent()
            heapFreeCurrent=cmo.getHeapFreeCurrent()
            heapFreePercent=cmo.getHeapFreePercent()
            print "%12s %6d MB  %10d MB  %14d MB  %14d%1s  %14.2f" % (
                        name.getName(),
                        heapSizeMax / (1024 * 1024), 
                        heapSizeCurrent / (1024 * 1024), 
                        heapFreeCurrent / (1024 * 1024), 
                        heapFreePercent,
                        '%',
                        tput) 
        else:
            alertServerHealth(env, name.getName(), serverState)
    print "-------------------------------------------------------------------------------------------"

env = ''
args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        env = args[1].strip().upper()
        args = args[2:]
    elif current_arg != '':
        mdsData = current_arg
        args = args[1:]
    else:
        # Move index
        args = args[1:]
if env == '':
    print ww.bcolors.RED + "Invalid target server?" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
serverUrl = getAdminServerT3Url(env)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    print "Target Server:" + serverUrl

# Connect to the AdminServer
connect(os.getenv('un'), os.getenv('pw'), serverUrl)

while 1:
    printHeapSizeInfo(env)
    Thread.sleep(int(checkInterval_in_Milliseconds))

sys.exit()
