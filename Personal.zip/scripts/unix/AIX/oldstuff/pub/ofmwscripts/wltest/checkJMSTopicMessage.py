#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#
#  This script is to list up all JMS resources defined in the FMW environment and their status
#
#  Created by: Michael Bai
#  Created on : Feb 23, 2012
#
###############################################################################################################
import re
import sys
import os.path
import commands
import wlstwrapper as ww
import time
execfile("/ofmwscripts/wlstCustomUtils.py")
systime=time


# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         Usage: -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA, or PROD

'''
# Check parameters
targetServer = ''
args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]   
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server?" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()    

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
    
connect(os.getenv('un'), os.getenv('pw'), serverUrl)
# Get all servers 
allServers=domainRuntimeService.getServerRuntimes()

clear = lambda: os.system('clear') 

if (len(allServers) > 0):
    for server in allServers:
        jmsRuntime = server.getJMSRuntime()
        jmsServers = jmsRuntime.getJMSServers();

        print "There are ", len(jmsServers), " jmsServers defined in this environment."
        for jmsServer in jmsServers:
            if(jmsServer.getName()=='CenovusJMSServer'):
                
                while 1==1:
                    clear()
                    print systime.strftime("%Y-%m-%d %H:%M:%S"),' Server:', jmsServer.getName(), ' Health:',  jmsServer.getHealthState()
                    destinations = jmsServer.getDestinations()
                    print "There are ", len(destinations), " destinations in this JMS server."
                    print 'DestinationType       Distination  Name                                MessagesCurrentCount'
                    for destination in destinations:      
                        if(destination.getDestinationType()=='Topic'):
                            Str1=destination.getName()
                            Str2=Str1.split('!')[1]
                            print '%-12s' %(destination.getDestinationType()), '%-70s' %(Str2),  destination.getMessagesCurrentCount()                        
                            for dur in destination.getDurableSubscribers():                                          
                                print  '   Durable   %-70s' %(dur.getSubscriptionName()),  dur.getMessagesCurrentCount()
                            #print
                    systime.sleep(10)

