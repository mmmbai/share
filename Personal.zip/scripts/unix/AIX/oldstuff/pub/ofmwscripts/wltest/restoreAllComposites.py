#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : restoreAllComposites.py
# Description: This script is to backup all deployed composites from a specific folder
#              just in case the SOA server crashed and need to get all composites back
# Created by : Richard Wang
# Date       : Feb 3, 2012
#        
###############################################################################################
import re
import sys
import os.path
import commands
from java.io import File
from oracle.fabric.management.deployedcomposites import CompositeManager
import wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")

# Destination folder
storeHome = '/ofmwmedia/cenovus_apps/'
# Preformatted UsageText
usageText = '''
    Usage: restoreAllComposites.py [-u update-type] -e environment
           -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''
# from optparse import OptionParser
updateType = 'all'
env = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        env = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]

print "Environment=" + env
if env == '':
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    destHomeDir = storeHome + env + '/'

deployTargetServerUrl = getServerHTTPUrl(env)
if deployTargetServerUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

else:
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', deployTargetServerUrl)
    if matchObj:  
        hostAddr = matchObj.group(1)
        hostPort = matchObj.group(2)
        print "Target server host=", hostAddr 
        print "Target server port=", hostPort


# Compose the command.....
lsCmd = "ls -l " + destHomeDir + " | egrep '^d' "

partitionList = commands.getoutput(lsCmd).split("\n")
# print composites by partition

if len(partitionList) == 0 or partitionList == None:
    print "No partitions defined for under " + destHomeDir + " !!!"
else:
    for partitionLongName in partitionList:
        tmpStrList = partitionLongName.split()
        partitionShortName = tmpStrList[8]
        print "Partition Name = " + tmpStrList[8]
        destPartitionDir = destHomeDir + partitionShortName
        try:
            for aComposite in File(destPartitionDir).listFiles():
                print "[" + os.path.basename(str(aComposite)) + ']'
                sca_deployComposite(deployTargetServerUrl,
                            str(aComposite),
                            true,
                            user=os.getenv('un'),
                            password=os.getenv('pw'),
                            forceDefault=true,
                            partition=partitionShortName)
        except Exception, detail:
            print 'Exception:', detail
exit()
