#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : startSOAServer.py
# Description: This script is to start SOAServer on the node you logged in. 
#              First, check if the node manager is already up or not.
# Created by : Richard Wang
# Date       : May 15, 2012
# Updated    : 
#
###############################################################################################
import sys
import os
import wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")

usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script to start managed SOA server directly from Node Manager.
         Usage: stopClusterSOAServer.py -e env_name -s soa_server_name
            -e: Only the following environments are clustered: TST, TQA, PROD
            -s: soa_server_name, it depends on the node environment where
                this script is executed from. please refer to the following:
                TST  (paeud-two-node cluster, iv00045p)---soa_server1
                TST  (paeud-two-node cluster, iv00045p)---soa_server2
                TQA  (two-node cluster, iv00094p)---------soa_server1
                TQA  (two-node cluster, iv00095p)---------soa_server2
                PROD (two-node cluster, iv00076p)---------soa_server1
                PROD (two-node cluster, iv00077p)---------soa_server2
'''
targetServer = ''
soaServer = ''
args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
        current_arg = args[0]
    elif current_arg == '-s':
        soaServer = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
print "Target Cluster Evnironment:" + targetServer
print "Target SOA Server Name:" + soaServer

if targetServer == '' or targetServer != 'TST' and targetServer != 'TQA' and targetServer != 'PROD':
     print ww.bcolors.RED + "Bad soa server name." + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    exit(exitcode=100)

if soaServer == '' or ( soaServer != 'soa_server1' and soaServer != 'soa_server2'):
    print ww.bcolors.RED + "Bad soa server name." + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    exit(exitcode=100)
    
serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    try:
        connect(os.getenv('un'), os.getenv('pw'), serverUrl)
        shutdown(soaServer,'Cluster')
        disconnect()
        exit(0)
    except WLSTException, detail:
        print 'Exception:', detail
        dumpStack()
        exit(exitcode=100)
