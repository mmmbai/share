#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : deleteMetadata.py documentNameWithPath
# Example    : deleteMetadata.py /apps/soa/infrastructure/xsd/v1/parentShema.xsd 
# Description: To delete MDS documents , the documentName can be wildcard or any specific name
# Note       : The path of MDS can't be removed by anyway once it is created at first time.
# Created by : Richard Wang
# Date       : Oct 28, 2011
#
###############################################################################################
import re
import sys
import os, wlstwrapper as ww 
execfile("/ofmwscripts/wlstCustomUtils.py")
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script only function with the following prerequisites:
           [1] The Application Name of MDS is fixed as 'soa-infra';
           [2] The ~/.serverEnv.properties file is referred from this script;
           [3] The target server ABBRIVATION must be provided as the first parameter.
           [4] The MDS data target (folder/document in tree-structure format must specify,
               in case of folder, from which all documents will be deleted but the folder 
               structure (namespace) can't be deleted, in case of document, only the 
               document will be deleted.
               
         Usage: deleteMetadata.py -e environment -t mds-data-root-folder-name
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
            -t: mds-data
            Be very careful to specify this name,or will create garbage namespace!!!
'''

applicationName = 'soa-infra'

# Load server properties
loadProperties('/home/oraclesoa/.serverEnv.properties')
# Check parameters
targetServer = ''
mdsData = ''
args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-t':
        mdsData = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
print "Target Server:" + targetServer

if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

if mdsData == '':
    print ww.bcolors.RED + "No MDS target specified." + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

serverUrl = getServerT3Url(targetServer)
targetSOAServerName = getSOAServer(targetServer)

if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)

    print 'Run deleteMetadata....'

    try:
        deleteMetadata(application=applicationName, 
                    server=targetSOAServerName,
                    cancelOnException='false', 
                    excludeExtendedMetadata='true', 
                    excludeAllCust='true', 
                    docs=mdsData)
    except WLSTException:
        dumpStack()
    print 'Done.'
disconnect()
exit()

