#!/usr/bin/env  bash

PLAN_HOME=/u01/domains/lab_domain/Plan
ADAPTER_HOME=/u01/app/oracle/fmw/Oracle_SOA1/soa/connectors

export CLASSPATH=$CLASSPATH:/u01/app/oracle/fmw/wlserver_10.3/server/lib/weblogic.jar
java weblogic.Deployer -adminurl t3://iv00046p:7001 -user weblogic -password xxxxxxxx -update -name JmsAdapter -plan $PLAN_HOME/JMSPlan.xml 
 
exit
