#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : startAdminServer.py
# Description: This script is to start AdminServer on the node you logged in. 
#              First, check if the node manager is already up or not.
# Created by : Richard Wang
# Date       : May 15, 2012
# Updated    : 
#
###############################################################################################
import sys
import os
import wlstwrapper as ww

# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to check the status of the specified managed server
         through Node Manager and AdminServer, there must be a Node Manager 
         running on the node where you run this script.
         Usage: checkSOAServerStatus.py -s soa_server_name
            -s: SOA server name, can be soa_server1 or soa_server2
'''

loadProperties('/home/oraclesoa/.serverEnv.properties')
ww.init(nmusername, nmpassword)
soaServer = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-s':
        soaServer = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if soaServer == '' or ( soaServer != 'soa_server1' and soaServer != 'soa_server2'):
    print ww.bcolors.RED + "Bad soa server name." + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    exit(exitcode=100)

try:
    nmConnect(os.getenv('un'), 
                os.getenv('pw'),
                nmHost,
                nmPort,
                nmDomainName,
                nmDomainDir,
                nmType,
                nmIsVerbose.lower()
                )
    nmServerStatus(soaServer)
    nmDisconnect()
except WLSTException, detail:
       print 'Exception:', detail
       dumpStack()
       exit(exitcode=100)
exit(exitcode=0)