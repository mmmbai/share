#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
execfile("/ofmwscripts/wlstCustomUtils.py")

userId = raw_input('Enter username:')
print userId
MaskingPassword().start()
passWd = raw_input("Enter password: ")
MaskingPassword().stop() 
print passWd