#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

import sys, traceback, wlstwrapper as ww 
execfile("/ofmwscripts/wlstCustomUtils.py")

usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is used for catchig stack traces to stdout dynamically
         when urgently need to reproduce issues and want to get more detailed 
         information.

         Usage: setStackTraceToStdout.py -e environment -m mode
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA, or PROD
            -m: Mode of dealing with StackTrace, must be ON or OFF
'''
targetServer = ''
mode = ''
sw = ''

# Check parameters 
args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-m':
        mode = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]

print "Target Server:" + targetServer
print "Mode:" + mode

if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    exit(exitcode=100)

if mode != 'ON' and mode != 'OFF':
    print ww.bcolors.RED + "Invalid mode" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    exit(exitcode=100)

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    exit(exitcode=100)
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)
    edit()
    startEdit()

    if isCluster:
        if mode == 'ON':
            cd('/Clusters/soa_cluster/Servers/soa_server1/Log/soa_server1')
            cmo.setStdoutLogStack(True)
            cmo.setStacktraceDepth(-1)
            cd('/Clusters/soa_cluster/Servers/soa_server2/Log/soa_server2')
            cmo.setStdoutLogStack(True)
            cmo.setStacktraceDepth(-1)
        else:
            cd('/Clusters/soa_cluster/Servers/soa_server1/Log/soa_server1')
            cmo.setStdoutLogStack(False)
            cmo.setStacktraceDepth(5)
            cd('/Clusters/soa_cluster/Servers/soa_server2/Log/soa_server2')
            cmo.setStdoutLogStack(False)
            cmo.setStacktraceDepth(5)
        
    else:
        cd('/Servers/soa_server1/Log/soa_server1')
        if mode == 'ON':
            cmo.setStdoutLogStack(True)
            cmo.setStacktraceDepth(-1)
        else:
            cmo.setStdoutLogStack(False)
            cmo.setStacktraceDepth(5)

    save()
    activate()
#=======================================================================================
# Exit WLST.
#=======================================================================================
disconnect()
exit(exitcode=0)

