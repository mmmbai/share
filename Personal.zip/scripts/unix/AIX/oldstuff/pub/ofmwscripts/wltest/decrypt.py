#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
import os, re, sys, wlstwrapper as ww


dataBuffer = []
print "Input file =", sys.argv[1] , '\n'
print "Output file =", sys.argv[2] , '\n'

inFile = open(sys.argv[1], 'r')
dataBuffer.extend(inFile.readlines())
inFile.close() 

outFile = open(sys.argv[2], 'w')
rx = re.compile(r'^#*=')
for aLine in dataBuffer:
    matchObj = rx.match(aLine)
    if matchObj: 
        continue
    else:
        unObj = re.search(".*username=(.*)", aLine)
        pwObj = re.search(".*password=(.*)", aLine)
        if unObj:
            un = ww.decrypt(unObj.group(1))
            aLine = aLine.replace(unObj.group(1), un)

        elif pwObj:
            pw = ww.decrypt(pwObj.group(1))
            aLine = aLine.replace(pwObj.group(1), pw)
        else:
            pass

    # print aLine
    outFile.write(aLine)

outFile.close()
sys.exit()

