execfile('env.py')
nmConnect('weblogic', 'labsoa01', 'iv00046p', '5556' , 'lab_domain','/u01/domains/lab_domain' ,'ssl')
nmKill('AdminServer')
