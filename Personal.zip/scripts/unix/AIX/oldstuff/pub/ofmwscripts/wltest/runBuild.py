#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

############################################################################
# This is a comprehensive tool for building function, including compiling, 
# packaging stages, all of them will be done on SOA server side.
#
# Created by Richard Wang
# Created on April, 2, 2012
############################################################################ 
import sys
import re
import os
import os.path
import commands

# Load system related properties
loadProperties('/home/oraclesoa/.serverEnv.properties')

# Based on the appHome( Current working directory ), find the composites.properties file
appHome = os.getcwd()
if os.path.exists(appHome + "/composites.properties"):
    print "Found composites.properties under " + appHome
    prop = open(appHome + "/composites.properties", "r")
else:
    print "No 'composites.properties' file found under " + appHome
    sys.exit()

try:
    for line in prop:
        matchObj = re.match(r'(composite\d+=)(.*)', line)
        if matchObj: 
            composite = matchObj.groups('1')
            paramList = composite[1].split(",")
            compositeName = os.path.basename(paramList[0])
            compositeFullPath = appHome  +'/' + compositeName

            applicationHome = os.path.dirname(compositeFullPath)
            revision = str.strip(paramList[1])
            ow = eval(str.strip(paramList[2]))
            fd = eval(str.strip(paramList[3]))
            partition = str.strip(paramList[4])

            print 'compositeFullPath=' , compositeFullPath
            print 'applicationHome =' , applicationHome
            print 'compositeName=' , compositeName
            print 'Revision=', revision
            print 'Partition=', partition
            print 'OverWriten=', ow
            print 'Force Default=', fd
                
            # adf-config.xml validation check
            if os.path.isfile(applicationHome + '/.adf/META-INF/adf-config.xml'):
                print "Source adf-config.xml:", applicationHome + '/.adf/META-INF/adf-config.xml'
                if not os.path.exists (compositeFullPath + '/SCA-INF/classes/META-INF/'):
                    os.makedirs (compositeFullPath + '/SCA-INF/classes/META-INF/')
                else:
                    pass
                try:
                    print "Embedding the Application level adf-config.xml into project level...."

                    #shutil.copy2(applicationHome + '/.adf/META-INF/adf-config.xml',
                    shutil.copy2(applicationHome + '/.adf/META-INF/adf-config.xml',
                                 compositeFullPath + '/SCA-INF/classes/META-INF/')
                    print "adf-config.xml is embeded."

                    # Also copy jps-config.xml only it exists
                    if os.path.exists(applicationHome + '/.adf/META-INF/jps-config.xml'):
                        shutil.copy2(applicationHome + '/.adf/META-INF/jps-config.xml',
                                 compositeFullPath + '/SCA-INF/classes/META-INF/')
                        print "jps-config.xml is embeded."
                    else:
                        pass
                except (IOError, os.error), why:
                        errors.extend(applicationHome + '/.adf/META-INF/*-config.xml',
                                      compositeFullPath + '/SCA-INF/classes/META-INF/', str(why))
            else:
                print "No application level adf-config.xml found. "

            # Supposing a composite app must has composite.xml
            if os.path.isfile(compositeFullPath + '/composite.xml'):
                print 'Found a composite:' + compositeFullPath + ', invoke compiling and packaging....'
                # Generate jar/sar file name
                # CompositeName
                #Revision
                sca_package(compositeFullPath,
                            compositeName,
                            revision,
                            oracleHome=oracleSOAHome
                            )
            else:
                print "No composite.xml file founded."

except Exception, detail:
    print 'Exception:', detail
