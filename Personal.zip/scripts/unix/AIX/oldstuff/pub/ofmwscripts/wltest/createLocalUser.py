#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

import os

# Get userName 
user = raw_input("Please Enter User Name:")

# Get password
password = raw_input("Please input password:")

# groups = ['Deployers', 'Monitors', 'Operators']

loadProperties('/home/oraclesoa/wlst/serverEnv.properties')

# Connect to the AdminServer
connect(username, password, domainUrl)

serverConfig()
print 'lookup DefaultAuthenticator' 

atnr=cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider('DefaultAuthenticator')
print 'create Local User ' + user

atnr.createUser(user,password,user)

# for i in groups:
# 	print "Add ", user, "to group ", i
# 	atnr.addMemberToGroup(group,user)

print "Done."
exit()
