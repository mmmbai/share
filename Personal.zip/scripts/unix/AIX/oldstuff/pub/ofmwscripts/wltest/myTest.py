#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
import re, sys, traceback, string, wlstwrapper as ww
from cStringIO import StringIO 

execfile("/ofmwscripts/wlstCustomUtils.py")

backup = sys.stdout
sys.stdout = StringIO()

print "xxxxxxxxxxxxxxxxxxxxxxxxxxxx4444yyyyyyyyyyyyyyyyyyyyyyyyyy\n"
print "xxxxxxxxxxxxxxxxxxxxxxxxxxxx500yyyyyyyyyyyyyyyyyyyyyyyyyyy\n"
print "xxxxxxxxxxxxxxxxxxxxxxxxxxxx88888yyyyyyyyyyyyyyyyyyyyyyyyy\n"

thisOut = sys.stdout.getvalue()
sys.stdout.close()
sys.stdout = backup

ret = string.find(thisOut, '500')
print "ret:", ret
print thisOut
#if ret != -1:
#if ret != -1:
#    print thisOut
#    print ww.bcolors.RED + "!!!!!!  Failure result returned from API !!!!!!" + ww.bcolors.ENDC
exit
