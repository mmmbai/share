#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#
#  This script is to list up all JMS resources defined in the FMW environment and their status
#
#  Created by: Richard Wang
#  Created on : Aug. 28, 2011
#
###############################################################################################################

import re, sys, wlstwrapper as ww, traceback
execfile("/ofmwscripts/wlstCustomUtils.py")
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to check all JMS' status.
         Usage: checkJMSConnection.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''
targetServer = ''
args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

print "Target Server:" + targetServer

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)

print "Check all JMS resources' status....."
#=======================================================================================
# Process the changes
#=======================================================================================


# Get all servers 
allServers=domainRuntimeService.getServerRuntimes()

if (len(allServers) > 0):
    for server in allServers:
        jmsRuntime = server.getJMSRuntime()
        
        jmsServers = jmsRuntime.getJMSServers();
        print "There are ", len(jmsServers), " jmsServers defined in this environment."
        for jmsServer in jmsServers:
            print '*******************************************', jmsServer.getName(),  jmsServer.getHealthState()
            destinations = jmsServer.getDestinations()
            print "There are ", len(destinations), " destinations in this JMS server."
            for destination in destinations:
                print '>>>>>>>>>>Distination>>>>>>>>>>>>>>>>>', destination.getName()
                print '  BytesCurrentCount           ' ,  destination.getBytesCurrentCount()
                print '  BytesHighCount              ' ,  destination.getBytesHighCount()
                print '  BytesPendingCount           ' ,  destination.getBytesPendingCount()
                print '  BytesReceivedCount          ' ,  destination.getBytesReceivedCount()
                print '  BytesThresholdTime          ' ,  destination.getBytesThresholdTime()
                print '  ConsumersCurrentCount       ' ,  destination.getConsumersCurrentCount()
                print '  ConsumersHighCount          ' ,  destination.getConsumersHighCount()
                print '  ConsumersTotalCount         ' ,  destination.getConsumersTotalCount()
                print '  ConsumptionPausedState      ' ,  destination.getConsumptionPausedState()
                print '  '
                # print '  DestinationInfo             ' ,  destination.getDestinationInfo()
                print '  '
                print '  DestinationType             ' ,  destination.getDestinationType()
                print '  InsertionPaused             ' ,  destination.isInsertionPaused()
                print '  InsertionPausedState        ' ,  destination.getInsertionPausedState()
                print '  MessagesCurrentCount        ' ,  destination.getMessagesCurrentCount()
                print '  MessagesDeletedCurrentCount ' ,  destination.getMessagesDeletedCurrentCount()
                print '  MessagesHighCount           ' ,  destination.getMessagesHighCount()
                print '  MessagesMovedCurrentCount   ' ,  destination.getMessagesMovedCurrentCount()
                print '  MessagesPendingCount        ' ,  destination.getMessagesPendingCount()
                print '  MessagesReceivedCount       ' ,  destination.getMessagesReceivedCount()
                print '  MessagesThresholdTime       ' ,  destination.getMessagesThresholdTime()
                # print '  Parent                      ' ,  destination.getParent()
                print '  Paused                      ' ,  destination.isPaused()
                print '  ProductionPaused            ' ,  destination.isProductionPaused()
                print '  ProductionPausedState       ' ,  destination.getProductionPausedState()
                print '  State                       ' ,  destination.getState()
                print '  Type                        ' ,  destination.getType()
