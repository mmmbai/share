#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : createThreadsDump.py
# Description: This script is to create the thread dump of AdminServer and its ManagedServers.
# 
# usage      : createThreadsDump.py <serverName>
# 
#              Where serverName can be : 
#                          1. AdminServer 
#                          2. soa_server1 or soa_server2(depends on what managedServer name)
#
# Created by : Richard Wang
# Date       : Jan, 3, 2012     
#        
###############################################################################################             
import re
import sys
import os.path

loadProperties('/home/oraclesoa/wlst/serverEnv.properties')

# Check parameters
params = len(sys.argv) - 1
if params == 1:
    serverName = sys.argv[1]
else:
    serverName = 'AdminServer'

print 'The target server is :' , serverName

# Connect to the AdminServer
connect(username, password, domainUrl)

cd ('Servers')
ls()
cd (serverName)
ls()
threadDump()

exit()

