#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : createCompositeList.py -e Server_Abbr
# Description: This script is to create a composites list based on the check-out from the 
#              CVS server for a specific SOA server environment.
#              
#              All check-out for all SOA servers is located in 
#                   /home/oraclesoa/appDock and being categorized by SREVER Abbrivations.
#              
#              Server_Abbr must be one of LAB, DEV1, DEV2, TEST, TQA or PROD
#
# Used properties files:  serverEnv.properties
#
# Created by : Richard Wang
# Date on    : March 22, 2012
#
###############################################################################################
import re
import sys
import os.path
import commands

# Preformatted UsageText
usageText = '''
    Usage: createCompositeList.py -e Server_Abbr
           -e: Environment, it can be one of LAB, DEV1, DEV2, TST, TQA or PROD
'''
subPBuffer = []
mainPBuffer = []

# Load properties file
loadProperties('/home/oraclesoa/.serverEnv.properties')

params = len(sys.argv) - 1
if params == 0:
    print usageText
    sys.exit()

args = sys.argv[:] 
if args[1] == '-e':
    env = args[2].strip()
    print "Target Server:" + env
else:
    print usageText
    sys.exit()

if env.upper() == 'DEV1':
    targetServerUrl = dev1AServerT3Url
    targetUsername = dev1ServerUser
    targetPassword = dev1ServerPassword
    appBaseDir = "/home/oraclesoa/appDock/DEV1/"
elif env.upper() == 'DEV2':
    targetServerUrl = dev2AServerT3Url
    targetUsername = dev2ServerUser
    targetPassword = dev2ServerPassword
    appBaseDir = "/home/oraclesoa/appDock/DEV2/"
elif env.upper() == 'TQA':
    targetServerUrl = tqaAServerT3Url
    targetUsername = tqaServerUser
    targetPassword = tqaServerPassword
    appBaseDir = "/home/oraclesoa/appDock/TQA/"
elif env.upper() == 'PROD':
    targetServerUrl = prodAServerT3Url
    targetUsername = prodServerUser
    targetPassword = prodServerPassword
    appBaseDir = "/home/oraclesoa/appDock/PROD/"
elif env.upper() == 'LAB':
    targetServerUrl = labAServerT3Url
    targetUsername = labServerUser
    targetPassword = labServerPassword
    appBaseDir = "/home/oraclesoa/appDock/TEST/"
else:
    print "Bad Server name!!!"
    print usageText
    sys.exit()

mainPFile = appBaseDir + "compositeList.properties"
subPFile = "composites.properties"
# Run command find to get all adf-config.xml files
findCmd = 'find ' + appBaseDir + ' -name ' + subPFile + ' -print'
fileList = commands.getoutput(findCmd).split('\n')

for aFile in fileList:
    # print 'Target file = ', aFile , '\n'
    # Read in one file into dataBuffer
    inFile = open(aFile, 'r')
    subPBuffer.extend(inFile.readlines())
    inFile.close() 
    
    outFile = open(mainPFile, 'w')
    # Parse Data and replace 
    for aLine in subPBuffer:
        if not re.match('.?#+', aLine):
            outFile.write(aLine)
    outFile.close()
    
# Sanity check from another angle

# Run command find to get all sca_*.jar files
findCmd = 'find ' + appBaseDir + ' -name sca_*.jar -print'
fileList = commands.getoutput(findCmd).split('\n')

# Getting mainPFile in nikomu!
tmpInFile = open(mainPFile, 'r')
mainPBuffer.extend(tmpInFile.readlines())
tmpInFile.close() 

regex = re.compile('^composite=(.*,)')

commonNum = 0
for oneFile in fileList:
    print "---->" + oneFile
    # Get the file Dir and File Name
    compositeName = os.path.basename(oneFile)
    compositeFullPath = os.path.dirname(oneFile).strip()
    compositeFullPath = os.path.dirname(compositeFullPath).strip()
    projectName = os.path.basename(compositeFullPath)
    outFile = open(mainPFile, 'w')
    # Parse Data and replace 
    print "====> " + projectName
    for aLine in mainPBuffer:
        matchObj1 = re.search(projectName, aLine)
        if matchObj1:
            print "Match! " + projectName
            aLine = regex.sub("\1", aFile, count=1)
            # aLine = regex.sub("\1", str(commonNum))
        outFile.write(aLine)
    
    outFile.close()

exit()

