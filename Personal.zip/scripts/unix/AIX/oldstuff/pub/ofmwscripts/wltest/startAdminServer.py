#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : startAdminServer.py
# Description: This script is to start AdminServer on the node you logged in. 
#              First, check if the node manager is already up or not.
# Created by : Richard Wang
# Date       : May 15, 2012
# Updated    : 
#
###############################################################################################
import sys
import os
import wlstwrapper as ww

loadProperties('/home/oraclesoa/.serverEnv.properties')
ww.init(nmusername, nmpassword)
try:
    nmConnect(os.getenv('un'), 
                os.getenv('pw'),
                nmHost,
                nmPort,
                nmDomainName,
                nmDomainDir,
                nmType,
                nmIsVerbose.lower()
                )
    nmStart('AdminServer')
    nmDisconnect()
except WLSTException, detail:
       print 'Exception:', detail
       dumpStack()
       exit(exitcode=100)
exit(exitcode=0)
