#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#
#  This script is to list up all JMS resources defined in the FMW environment and their status
#
#  Created by: Michael Bai
#  Created on : Feb. 21, 2012
#
###############################################################################################################
import re, sys, traceback
loadProperties('/home/oraclesoa/wlst/serverEnv.properties')

# Connect to the soa
connect(username, password, domainUrl)
cd('Servers/soa_server1/ServerDebug/soa_server1');		
ls();