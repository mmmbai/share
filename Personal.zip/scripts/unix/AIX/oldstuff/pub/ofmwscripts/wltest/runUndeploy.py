#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : runUndeploy.py
# Description: This script is to call sca_undeploy wlst command to perform undeployment  
#              of multiple composite applications defined in deploy.properties file.
# Created by : Richard Wang
# Date       : Sep 6, 2011    
#        
###############################################################################################
import re
import sys
import os.path
import commands
import wlstwrapper as ww
from oracle.fabric.management.deployedcomposites import CompositeManager
execfile("/ofmwscripts/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
    Usage: runUndeploy.py -e environment [-p partition ] -c composite [-r revision] 
           -e: Environment, mandatory.it must be LAB, DEV1 DEV2 TST, TQA or PROD
           -p: Partition, which you want to un-deploy from, default is "default"
           -c: Composite, this is a mandatory parameter that you must specify
           -r: Revision, the revision number of the composite you want to un-deploy, default is 1.0
'''
# from optparse import OptionParser
com = ''
rev = ''
par = ''
env = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        env = args[1].strip()
        args = args[2:]
    elif current_arg == '-p':
        par = args[1].strip()
        args = args[2:]
    elif current_arg == '-r':
        rev= args[1].strip()
        args = args[2:]
    elif current_arg == '-c':
        com = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]

if com == '' or env == '':
    print usageText
    sys.exit()

if par == '':
    par = 'default'

if rev== '':
    rev = '1.0'
    
print "Environment=" + env
print "Partition=" + par
print "Revision=" + rev
print "Composite=" + com


deployedCompos = None
deployedCompList = []

serverUrl = getServerHTTPUrl(env)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    matchObj = re.match(r'http:\/\/(.+):([0-9]{4})', serverUrl)

if matchObj:  
    hostAddr = matchObj.group(1)
    hostPort = matchObj.group(2)
    print "Target server host=", hostAddr 
    print "Target server port=", hostPort
    
try:
    CompositeManager.initConnection(hostAddr, 
                        hostPort, 
                        os.getenv('un'), 
                        os.getenv('pw'))
    clmMBean = CompositeManager.getCompositeLifeCycleMBean()
    if clmMBean == None:
        print 'Cannot find composite lifecycle mbean.'
        sys.exit()
        
    deployedComposites = CompositeManager.listDeployedComposites(clmMBean)
    compList = deployedComposites.split('\n')
    del compList[0:2]
    # Re organize the list, only the compositeName will be left
    targetComposite = ''
    targetRevision = ''
    targetPartition = ''
    for i in range(len(compList)):
        if compList[i] != '':
            #print "compList[i] = " + compList[i]
            iList = compList[i].split(",")
            matchCompInfo = re.match(r'[0-9]+.\s*(.+)\[([0-9]+\.[0-9]+)\]', iList[0])
            if matchCompInfo:
                targetComposite = matchCompInfo.group(1)
                targetRevision = matchCompInfo.group(2)
            else:
                print "Problem happened when parsing " + iList[0] + " skip it." 
                continue

            # Get Partition
            matchPartitionInfo = re.match(r'partition=(.+)', iList[1].strip())
            if matchPartitionInfo:
                targetPartition = matchPartitionInfo.group(1)
            else:
                print "Problem happened when parsing " + iList[1] + " skip it." 
                continue
            # Undeploy only if the patrition is matched
            #print "targetComposite=" + targetComposite
            #print "Composite=" + com
            #print "targetRevision=" + targetRevision
            #print "Revision=" + rev
            #print "targetPartition=" + targetPartition
            #print "Partition=" + par

            if targetPartition == par and targetComposite == com and targetRevision == rev:
                print "Found target composite, undeploy it....."
                sca_undeployComposite(serverUrl, 
                               targetComposite, 
                               targetRevision, 
                               user=os.getenv('un'), 
                               password=os.getenv('pw'), 
                               partition=targetPartition)

                print com + '[' + rev + '] has been un-deployed from ' + par + ' partition.\n'
                break
            else:
                pass

except Exception, detail:
       print 'Exception:', detail
       sys.exit()
