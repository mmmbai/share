#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : runCompile.py
# Description: This script is for batch compiling the composite applications defined in the
# application.properties file.
#
# Created by : Richard Wang
# Date       : Aug 31, 2011
#
###############################################################################################
import re
import sys
import os.path
import commands

# Load properties file
loadProperties('./serverEnv.properties')

# Connect to the AdminServer
# connect(username, password, domainUrl)

# Read applications from the properties
if os.path.exists("/home/oraclesoa/appDock/applications.properties"):
    prop = open("/home/oraclesoa/appDock/applications.properties", "r")
else:
    print "No properties file found."
    sys.exit()

# Parse Applications information
for line in prop:

    matchObj = re.match(r'(composite\d+\s=\s)(.*)', line)
    if matchObj: 
        composite = matchObj.groups('1')
        paramList = composite[1].split(",")

        compositeFullPath = appDockDir +'/' + paramList[0] + '/'
        print 'compositeFullPath=' , compositeFullPath
        # Supposing a composite app must has composite.xml
        if os.path.isfile(compositeFullPath + '/composite.xml'):
            print 'Found a composite:' + compositeFullPath + ', invoke compiling....'
            sca_compile(compositeFullPath + 'composite.xml', 
                        displayLevel=2, 
                        oracleHome=oracleSOAHome,
                        error="/tmp/error.out")

exit()
