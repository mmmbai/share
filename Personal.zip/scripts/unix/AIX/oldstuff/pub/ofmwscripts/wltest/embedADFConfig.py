#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : embedADFConfig.py
# Description: This script is for checking adf-config.xml usablity before calling system
#              compile/package/deploy.
#              
#              The adf-config.xml mainly resides in exists in two location within one
#              JDeveloper's application:
#              (1) JDeveloper Application Level:
#                  ApplicationName/.adf/META-INF/adf-config.xml
#              (2) JDeveloper Project Level:
#                  ApplicationName/ProjectName/SCA-INF/classes/META-INF/adf-config.xml
#              In case of using compile/package/deploy on server side, only the project level
#              adf-config.xml can be used. So what this script does is 
#                a. Check if there is a application level adf-config.xml
#                   If there is, copy it to the projects under this application
#                b. If there is not, the script ignore this project, regards it as 
#                   "no adf-config.xml is needed".
# Note:        Please ask developers to keep in mind that the application level adf-config.xml
#              must be a valid one and MDS credentials need to be ready there.
#
# Used properties files:  serverEnv.properties
#
# Created by : Richard Wang
# Date       : Dec 20, 2011
#
###############################################################################################
import re
import sys
import os.path
import commands

# Create a Data Buffer for storing the data from adf-config.xml
dataBuffer = []


# Load properties file
loadProperties('/home/oraclesoa/.serverEnv.properties')

# Run command find to get all adf-config.xml files
findCmd = 'find ' + appDockDir + ' -name adf-config.xml -print'
fileList = commands.getoutput(findCmd).split('\n')

for aFile in fileList:
    print "Target file =", aFile , '\n'
    # Read in one file into dataBuffer
    inFile = open(aFile, 'r')
    dataBuffer.extend(inFile.readlines())
    inFile.close() 
    
    outFile = open(aFile, 'w')
        # Parse Data and replace 
    for aLine in dataBuffer:
        matchObj1 = re.search(oldMdsJDBCUserName, aLine)
        matchObj2 = re.search(oldMdsJDBCPassword, aLine)
        matchObj3 = re.search(oldMdsJDBCUrl, aLine)
        if matchObj1:
            aLine = aLine.replace(oldMdsJDBCUserName, newMdsJDBCUserName)
        elif matchObj2:
            aLine = aLine.replace(oldMdsJDBCPassword, newMdsJDBCPassword)
        elif matchObj3:
            aLine = aLine.replace(oldMdsJDBCUrl, newMdsJDBCUrl)
        
        outFile.write(aLine)
    
    outFile.close()

exit()

