#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

#=======================================================================================
# Description: This script is used for changing the log severity level dynamically
#              when urgently need to reproduce issues and want to get more detailed 
#              information.
#=======================================================================================
import sys, traceback, wlstwrapper as ww
from cStringIO import StringIO 

execfile("/ofmwscripts/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to set Log Level based on specified options:
         The original API takes more options, here, we only take
         some 'MUST" ones for easily using, as to the rest of options 
         we take the default values.

         Usage: setLogLevel.py -e environment -s target_server -n logger_name -l level
         
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
            -s: Target_Server, currently, soa_server1 or soa_server2, depends.
            -n: Logger_name, A logger name. An empty string denotes the root logger
            -l: level,The level name. It can be either a Java level or an ODL level. 
                Some valid Java levels are: 
                    SEVERE, WARNING, INFO, CONFIG, FINE, FINER, OR FINEST. 
                Valid ODL levels include a message type followed by a colon and a 
                message level. The valid ODL message types are: 
                    INCIDENT_ERROR, ERROR, WARNING, NOTIFICATION, TRACE, and UNKNOWN. 
                The message level is represented by an integer value that qualifies the 
                message type. Possible values are from 1 (highest severity) through 32 
                (lowest severity).
'''
targetServer = ''
sn = ''
ln = ''
ll = ''
isRunTime = True
isPersit = True

#=======================================================================================
# Check parameters 
# 
# The log severity level has to be specified as script parameter
#=======================================================================================
args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-s':
        sn = args[1].strip().lower()
        args = args[1:]
    elif current_arg == '-n':
        ln = args[1].strip()
        args = args[1:]
    elif current_arg == '-l':
        ll = args[1].strip()
        args = args[1:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
if sn != 'soa_server1' and sn != 'soa_server2' :
    print ww.bcolors.RED + "Invalid Server Name" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
if ln == '':
    print ww.bcolors.RED + "No Logger Name specified, means you will change all OAM colloctors." + ww.bcolors.ENDC
    print ww.bcolors.RED + "This is not a recommended selection." + ww.bcolors.ENDC
    yesno = raw_input('Are you going to continue(Yes/yes/y OR No/no/n)?')
    if (yesno.strip().upper() != 'Y' and yesno.strip().upper() != 'YES'):
        sys.exit()
    else:
        pass
if ll == '':
    print ww.bcolors.RED + "Invalid Logger Level" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)
    backup = sys.stdout
    sys.stdout = StringIO()
    currentLL = getLogLevel(target=sn, logger=ln)
    out = sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = backup
    print "\nCurrent LogLevel:" + out
    print "It will be change to:" + ll
    print 'starting setting log level.....'
    setLogLevel(target=sn, logger=ln, level=ll, persist=isPersit, runtime=isRunTime)
    print "Done"
#=======================================================================================
# Exit WLST.
#=======================================================================================
disconnect()
exit()

