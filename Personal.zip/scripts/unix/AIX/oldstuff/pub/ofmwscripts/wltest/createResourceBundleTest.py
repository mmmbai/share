#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
##############################################################################################
# File Name  : createJmsBundle.py
# Description: This script is to create the following system resources:
#              (1) Creating JMS topics, queues connection factory and connection pool 
#                  based on the Business Area, Business Object and the naming rules 
#                  provided
#
#              (2) Creating DB resources, including connection pools, datasources, 
#                  multidatasources
#                  and JDBC drivers based on the Business Area, Business Object and 
#                  the naming rules provided.
#
#                  The related server information and basic common information for creating 
#                  the system resources is defined in the serverEnv.properties.
#
#                  With regard to the JDBC, Queue/Topic specific information is defined in 
#                  resourceBundle.properties.
#
#              (3) One parameter with the following value can be specified:

#                   update  : With updated deployment plan update the adapter in place
#                   redeploy: Destroy all adapter's instance, deploy it again, in case some
#                   applications using the adapter, redeploy may cause problem........

#                  If you don't specify any parameter, the script will treat it as update
#
# Created by   : Richard Wang, Michael Bai
# Create Date  : Dec 8, 2011
# Last Modified:  Jan 20, 2012
#
#############################################################################################
#Conditionally import wlstModule only when script is executed with jython
# if __name__ == '__main__': 
#    from wlstModule import *#@UnusedWildImport
from java.lang import System
import string
import re
import sys
import os.path
import traceback
import wlstwrapper as ww
# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
        This script has to be run from any nodes of the environment you specified!!!
        Usage: runDdeploy.py -e environment -p bundle-properties-file
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
            -r: Re-Deploy-Mode, if not specified, use update-mode(default mode)
'''

# Global varibales 
resourceProp = '/home/oraclesoa/.resourceBundle.properties'
username = ''
password = ''
domainUrl = ''

clusterName = ''
managedServerName = 'soa_server1'

jmsServerName = ''
jmsModuleName = ''
jmsAdapterName = ''
jmsAdapterPath=''
jmsPlanPath=''

dbAdapterName = ''
dbAdapterPath=''
dbPlanPath=''

queueInfoList = list()
topicInfoList = list()
dsInfoList = list()

#=================================================================
#   Internal Functions
#=================================================================
def parsePropInfo():
    try:
    
        if os.path.exists(resourceProp):
            prop = open(resourceProp, "r")
            
            # Pick up topic list
            for line in prop:
                matchObj = re.match(r'topic\d+=(.*)', line)
                if matchObj: 
                    print "Topic=>", matchObj.group(1)
                    topicInfoList.append(matchObj.group(1).split(','))

            prop.seek(0)
            
            # Pick up queue List
            for line in prop:
                matchObj = re.match(r'queue\d+=(.*)', line)
                if matchObj: 
                    print "Queue=>", matchObj.group(1)
                    queueInfoList.append(matchObj.group(1).split(','))

            prop.seek(0)
            
            # Pick up DB List
            for line in prop:
                matchObj = re.match(r'ds\d+=\s*(.*)', line)
                if matchObj: 
                    dsInfoList.append(matchObj.group(1).split(','))

            for oneDs in dsInfoList:
                print oneDs

    except:
        print "Error occurred:", sys.exc_info()[0]
        raise    
#=================================================================
#  The following modules are for modifying JMS Plan
#=================================================================
def makeJMSDeploymentPlan(connectionPoolName,sourceJNDI,isTopic):
    myPlan=loadApplication(jmsAdapterPath, jmsPlanPath)
    cpClassName='oracle.tip.adapter.jms.IJmsConnectionFactory'
    cpVariablePropertyValue=''
    cpVariableValue=connectionPoolName
    cpVariableName='Varible_'+connectionPoolName+'_'+cpVariablePropertyValue
    xpath=makexpath(cpClassName,connectionPoolName,cpVariablePropertyValue)
    makeDeploymentPlanVariable(jmsAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)

    cpVariablePropertyValue='ConnectionFactoryLocation'
    cpVariableValue=sourceJNDI
    cpVariableName='Varible_'+connectionPoolName+'_'+cpVariablePropertyValue
    xpath=makexpath(cpClassName,connectionPoolName,cpVariablePropertyValue)
    makeDeploymentPlanVariable(jmsAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)
    
    cpVariablePropertyValue='IsTopic'
    cpVariableValue=isTopic
    cpVariableName='Varible_'+connectionPoolName+'_'+cpVariablePropertyValue
    xpath=makexpath(cpClassName,connectionPoolName,cpVariablePropertyValue)
    makeDeploymentPlanVariable(jmsAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)
    myPlan.save();

#=================================================================
#  The following modules are for modifying JMS Plan
#=================================================================
def makexpath(className,cpVariableValue,cpVariablePropertyValue):
    xpathBase1='/weblogic-connector/outbound-resource-adapter/connection-definition-group/[connection-factory-interface="'
    xpathBase2=className
    xpathBase3='"]/connection-instance/[jndi-name="'
    xpathBase4=cpVariableValue
    if    cpVariablePropertyValue=='':
        xpathBase5='"]/jndi-name'
        xpath=xpathBase1+xpathBase2+xpathBase3+xpathBase4+xpathBase5
    else:
        xpathBase5='"]/connection-properties/properties/property/[name="'
        xpathBase6=cpVariablePropertyValue
        xpathBase7='"]/value'
        xpath=xpathBase1+xpathBase2+xpathBase3+xpathBase4+xpathBase5+xpathBase6+xpathBase7
    return xpath

#=================================================================
#  The following modules are for modifying JMS Plan
#=================================================================
def makeDeploymentPlanVariable(appName,wlstPlan, name, value, xpath, origin='planbased'):
    moduleDescriptorName='META-INF/weblogic-ra.xml'
    moduleOverrideName=appName+'.rar'
    while wlstPlan.getVariable(name):
        wlstPlan.destroyVariable(name)

    while wlstPlan.getVariableAssignment(name, moduleOverrideName, moduleDescriptorName):
        wlstPlan.destroyVariableAssignment(name, moduleOverrideName, moduleDescriptorName)
    variableAssignment = wlstPlan.createVariableAssignment(name, moduleOverrideName, moduleDescriptorName)
    variableAssignment.setXpath(xpath)
    variableAssignment.setOrigin(origin)
    wlstPlan.createVariable(name, value)

#=================================================================
#  The following modules are for modifying JDBC Plan
#=================================================================
def  makeDBDeploymentPlan(dbJNDI, connectionPoolJNDI):

    myPlan=loadApplication(dbAdapterPath, dbPlanPath)
    cpClassName='javax.resource.cci.ConnectionFactory'
    cpVariablePropertyValue=''
    cpVariableValue=connectionPoolJNDI
    cpVariableName='Varible_' + connectionPoolJNDI + '_' +cpVariablePropertyValue

    xpath=makexpath(cpClassName,connectionPoolJNDI,cpVariablePropertyValue)
    makeDeploymentPlanVariable(dbAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)

    cpVariablePropertyValue='xADataSourceName'
    cpVariableValue=dbJNDI
    cpVariableName='Varible_'+connectionPoolJNDI+'_'+cpVariablePropertyValue
    xpath=makexpath(cpClassName,connectionPoolJNDI,cpVariablePropertyValue)
    makeDeploymentPlanVariable(dbAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)
    myPlan.save();

#=================================================================
#   Create Topic, Connection Factory, connection pool....
#=================================================================
def createTopicBundle(businessArea, businessObject):
    try:
        startEdit()    
        # Get target Cluster or Managed Server
        if clusterName != '':
            servermb=getMBean("Clusters/" + clusterName)
        elif managedServerName != '':
            servermb=getMBean("Servers/" + managedServerName)
            
        if servermb is None:
            print 'The Managed server has not been found, please create it first.'
            raise ValueError
    
        # Create JMS Module if it is not created yet   
        jmsModulemb = getMBean("JMSSystemResources/" + jmsModuleName)
        if jmsModulemb is None:
            print 'The JMS module ', jmsModuleName, ' has not been found, create...'
            jmsModulemb = create(jmsModuleName,"JMSSystemResource")
            # Target the resource to the Target Manager Server
            print 'Add your managed server as the target of your JMSSystemResource (JMS Module)...'
            jmsModulemb.addTarget(servermb)
            print '...Done'
        else:
            print 'The JMS Module exists.'
    
        # Get JMS Resource
        jmsResourceObj = jmsModulemb.getJMSResource()
    
        # Create JMS Server if it dose not exist
        jmsServermb = getMBean("JMSServers/" + jmsServerName)
        if jmsServermb is None:
            print 'No specified JMSServer exists, create...'
            jmsServermb = create(jmsServerName, 'JMSServer')
            # Target the resource to ONE and ONLY ONE Target Manager Server
            # If this is a cluster configuration, the target server is one of the migratable Manager Server.
            print 'Also add your managed server as the target of your JMSServer...'
            jmsServermb.addTarget(servermb)
            print '...Done.'
        else:
            print 'The JMSServer already exists.'
####################################No SubDeployment is needed ###################################################
        # Create Sub Deployment if it has not been created
        # subDepmb = jmsModulemb.lookupSubDeployment(jmsSubDeploymentName.strip()) 
        # cd('/')
        # pwd()
        # subDepmb = getMBean("JMSSystemResources/" + jmsModuleName + "/SubDeployments/" + jmsSubDeploymentName)
        # subDepmb = getMBean("JMSSystemResources/CenovusSOAJMSModule/SubDeployments/defaultSubDeployment")
        # print "SUBDEPMB>>>>>>>>" , subDepmb
        # if subDepmb is None:
            # Create sub Deployment
            # print 'No specified subDeployment exists, create...'
            # subDepmb = jmsModulemb.createSubDeployment(jmsSubDeploymentName)  
            # Add your JMSServer as the target of your subDeployment
            # print 'Add your JMSServer as the target of your subDeployment'
            # subDepmb.addTarget(jmsServermb)
            # print '...Done.'
        # else:
            # print 'The specified subDeployment already exists'
##################################################################################################################
        # Compose Topic name
        if businessArea == 'none':
           jmsTopicName = businessObject + 'Topic'
           jmsTopicJNDIName = 'jms/' + businessObject + '/Topic'
           # Distributed Topic
           # jmsDTopicName = businessObject + 'Topic'
           # jmsDTopicJNDIName = 'jms/' + businessObject + '/Topic'

        else:
           jmsTopicName = businessArea + businessObject + 'Topic'
           jmsTopicJNDIName = 'jms/' + businessArea + '/' + businessObject + '/Topic'
           # Distributed Topic
           # jmsDTopicName = businessArea + businessObject + 'Topic'
           # jmsDTopicJNDIName = 'jms/' + businessArea + '/' + businessObject + '/Topic'
        # Create queue/topic if it has not been created yet
        jmsTopic = jmsResourceObj.lookupTopic(jmsTopicName)
        if jmsTopic is None:
            print 'No specified queue/topic exists, create...'
            jmsTopic = jmsResourceObj.createTopic(jmsTopicName)
            print '...Done.'
            
            # Set JNDI name of Topic
            print 'Set JNDI name for the Topic.'
            jmsTopic.setJNDIName(jmsTopicJNDIName)
        else:
            print 'The specified topic already Exists.'

        # Distributed Topic
        #jmsDTopic = jmsResourceObj.lookupDistributedTopic(jmsDTopicName)
        #if jmsDTopic is None:
        #    print 'Create Distributed Topic.'
        #    jmsDTopic = jmsResourceObj.createDistributedTopic(jmsDTopicName)
        #    print 'Set JNDI name for created distributed Topic.'
        #    jmsDTopic.setJNDIName(jmsDTopicJNDIName)
        #    print 'Add the Topic to the distribued Topic.'
        #    jmsDTopic.createDistributedTopicMember(jmsTopicName)
        #else:
        #    print 'The specified Distributed topic already Exists.'
            # jmsDTopic.createDistributedTopicMember(jmsTopicName)
        # Compose Topic Connection Factory Name
        if businessArea == 'none':
           jmsTopicINCFName = businessObject + 'INTopicCF'
           jmsTopicINCFJNDIName = 'jms/' + businessObject + 'IN' + '/Topic/CF'
           jmsTopicINCPJNDIName = 'eis/'+ businessObject + '/IN/Topic'
           jmsTopicOUTCFName = businessObject + 'OUTTopicCF'
           jmsTopicOUTCFJNDIName = 'jms/' + businessObject + 'OUT' + '/Topic/CF'
           jmsTopicOUTCPJNDIName = 'eis/'+ businessObject + '/OUT/Topic'
        else:
           jmsTopicINCFName = businessArea + businessObject + 'INTopicCF'
           jmsTopicINCFJNDIName = 'jms/' + businessArea + '/' + businessObject + 'IN' + '/Topic/CF'
           jmsTopicINCPJNDIName = 'eis/'+ businessArea +'/'+ businessObject + '/IN/Topic'
           jmsTopicOUTCFName = businessArea + businessObject + 'OUTTopicCF'
           jmsTopicOUTCFJNDIName = 'jms/' + businessArea + '/' + businessObject + 'OUT' + '/Topic/CF'
           jmsTopicOUTCPJNDIName = 'eis/'+ businessArea + '/' + businessObject + '/OUT/Topic'

        # Create JMS connection factory if it has not been created
        jmsTopicINCF = jmsResourceObj.lookupConnectionFactory(jmsTopicINCFName)
        if jmsTopicINCF is None:
            print 'Create the connection factory of your IN queue/topic...'
            jmsTopicINCF = jmsResourceObj.createConnectionFactory(jmsTopicINCFName) 
            jmsTopicINCF.setJNDIName(jmsTopicINCFJNDIName)
            jmsTopicINCF.setDefaultTargetingEnabled(true)
            print '...Done.'
            
        else:
            print 'The specified IN Connection Factory already exists.'
 
        # Create JMS connection factory if it has not been created
        jmsTopicOUTCF = jmsResourceObj.lookupConnectionFactory(jmsTopicOUTCFName)
        if jmsTopicOUTCF is None:
            print 'Create the connection factory of your OUT queue/topic...'
            jmsTopicOUTCF = jmsResourceObj.createConnectionFactory(jmsTopicOUTCFName) 
            jmsTopicOUTCF.setJNDIName(jmsTopicOUTCFJNDIName)
            jmsTopicOUTCF.setDefaultTargetingEnabled(true)

            print "Set default Cliend-ID..."

            cp=jmsTopicOUTCF.getClientParams()
            cp.setClientId(jmsTopicOUTCF.getName())
            cp.setClientIdPolicy('Unrestricted')
            cp.setSubscriptionSharingPolicy('Sharable')
            print ".....................Client-ID is set"

            print '...Done.'
            
        else:
            print 'The specified OUT Connection Factory already exists.'
        
        makeJMSDeploymentPlan(jmsTopicINCPJNDIName,jmsTopicINCFJNDIName, 'true')
        
        makeJMSDeploymentPlan(jmsTopicOUTCPJNDIName,jmsTopicOUTCFJNDIName, 'true')
##################################################################################################
        # Set sub deployment name
        jmsTopic.setSubDeploymentName(jmsSubDeploymentName)
        # jmsDTopic.setSubDeploymentName(jmsSubDeploymentName)
        # jmsTopicINCF.setSubDeploymentName(jmsSubDeploymentName)
        # jmsTopicOUTCF.setSubDeploymentName(jmsSubDeploymentName)
##################################################################################################
        print "script returns successfully from creating topics."   
    except Exception, e:
        print e 
        dumpStack()
        raise 
 
#=================================================================
#   Create Queue, Connection Factory, connection pool....
#=================================================================
def createQueueBundle(businessArea, businessObject):
    try:
        startEdit()    
        # Get target Cluster or Managed Server
        if clusterName != '':
            servermb=getMBean("Clusters/" + clusterName)
        elif managedServerName != '':
            servermb=getMBean("Servers/" + managedServerName)
            
        if servermb is None:
            print 'The Managed server has not been found, please create it first.'
            raise ValueError
    
        # Create JMS Module if it is not created yet   
        jmsModulemb = getMBean("JMSSystemResources/" + jmsModuleName)
        if jmsModulemb is None:
            print 'The JMS module ', jmsModuleName, ' has not been found, create...'
            jmsModulemb = create(jmsModuleName,"JMSSystemResource")
            # Target the resource to the Target Manager Server
            print 'Add your managed server as the target of your JMSSystemResources (JMS Module)...'
            jmsModulemb.addTarget(servermb)
            print '...Done'
        else:
            print 'The JMS Module exists.'
    
        # Get JMS Resource
        jmsResourceObj = jmsModulemb.getJMSResource()
    
        # Create JMS Server if it dose not exist
        jmsServermb = getMBean("JMSServers/" + jmsServerName)
        if jmsServermb is None:
            print 'No specified JMSServer exists, create...'
            create(jmsServerName)
            # Target the resource to the Target Manager Server
            print 'Also add your managed server as the target of your JMSServer...'
            jmsServermb.addTarget(servermb)
            print '...Done.'
        else:
            print 'The JMSServer already exists.'
#################################################################################################################
        # Create Sub Deployment if it has not been created
        # subDepmb = jmsModulemb.lookupSubDeployment(jmsSubDeploymentName.strip())
        # cd('/')
        # pwd()
        # subDepmb = getMBean("JMSSystemResources/" + jmsModuleName + "/SubDeployments/" + jmsSubDeploymentName)
        # subDepmb = getMBean("JMSSystemResources/CenovusSOAJMSModule/SubDeployments/defaultSubDeployment")
        # subDepPath = "JMSSystemResources/" + jmsModuleName + "/SubDeployments/" + jmsSubDeploymentName
        # subDepmb = getMBean(suDepPath)
        # if subDepmb is None:
            # Create sub Deployment
            # print 'No specified subDeployment exists, create...'
            # subDepmb = jmsModulemb.createSubDeployment(jmsSubDeploymentName)  
            # Add your JMSServer as the target of your subDeployment
            # print 'Add your JMSServer as the target of your subDeployment'
            # subDepmb.addTarget(jmsServermb)
            # print '...Done.'
        # else:
            # print 'The specified subDeployment already exists'
################################################################################################################
        # Compose Queue name
        # Compose Queue name
        if businessArea == 'none':
           jmsQueueName = businessObject + 'Queue4Dist'
           jmsQueueJNDIName = 'jms/' + businessObject + '/Queue4Dist'
           # Distributed Queue
           jmsDQueueName = businessObject + 'Queue'
           jmsDQueueJNDIName = 'jms/' + businessObject + '/Queue'
        else:
           jmsQueueName = businessArea + businessObject + 'Queue4Dist'
           jmsQueueJNDIName = 'jms/' + businessArea + '/' + businessObject + '/Queue4Dist'
           # Distributed Queue
           jmsDQueueName = businessArea + businessObject + 'Queue'
           jmsDQueueJNDIName = 'jms/' + businessArea + '/' + businessObject + '/Queue'
        
        # Compose Topic Connection Factory Name
        if businessArea == 'none':
           jmsQueueCFName = businessObject + 'QueueCF'
           jmsQueueCFJNDIName = 'jms/' + businessObject + 'INOUT' + '/Queue/CF'
           jmsQueueCPJNDIName = 'eis/' + businessObject + '/INOUT/Queue'
        else:
           jmsQueueCFName = businessArea + businessObject + 'QueueCF'
           jmsQueueCFJNDIName = 'jms/' + businessArea + '/' + businessObject + 'INOUT' + '/Queue/CF'
           jmsQueueCPJNDIName = 'eis/' + businessArea + '/' + businessObject + '/INOUT/Queue'

        # Create queue/topic if it has not been created yet
        jmsQueue = jmsResourceObj.lookupQueue(jmsQueueName)
        if jmsQueue is None:
            print 'No specified queue/topic exists, create...'
            jmsQueue = jmsResourceObj.createQueue(jmsQueueName)
            print '...Done.'
            
            # Set JNDI name of queue
            print 'Set JNDI name for the queue.'
            jmsQueue.setJNDIName(jmsQueueJNDIName)
        else:
            print 'The specified queue/topic already Exists.'

        # Distributed Queue
        jmsDQueue = jmsResourceObj.lookupDistributedQueue(jmsDQueueName)
        if jmsDQueue is None:
            print 'Create Distributed Queue.'
            jmsDQueue = jmsResourceObj.createDistributedQueue(jmsDQueueName)
            print 'Set JNDI name for created distributed queue.'
            jmsDQueue.setJNDIName(jmsDQueueJNDIName)
            print 'Add the queue to the distribued queue.'
            jmsDQueue.createDistributedQueueMember(jmsQueueName)
        else:
            print 'The specified Distributed queue/topic already Exists.'
            # jmsDQueue.createDistributedQueueMember(jmsQueueName)

        # Create JMS connection factory if it has not been created
        jmsQueueCF = jmsResourceObj.lookupConnectionFactory(jmsQueueCFName)
        if jmsQueueCF is None:
            print 'Create the connection factory of your queue/topic...'
            jmsQueueCF = jmsResourceObj.createConnectionFactory(jmsQueueCFName) 
            jmsQueueCF.setJNDIName(jmsQueueCFJNDIName)
            jmsQueueCF.setDefaultTargetingEnabled(true)

            print '...Done.'
            
        else:
            print 'The specified IN and OUT Connection Factory already exists.'

#####################################################################################
        # Set sub deployment name
        jmsQueue.setSubDeploymentName(jmsSubDeploymentName)
        # jmsDQueue.setSubDeploymentName(jmsSubDeploymentName)
        # jmsQueueCF.setSubDeploymentName(jmsSubDeploymentName)
#####################################################################################
        makeJMSDeploymentPlan(jmsQueueCPJNDIName,jmsQueueCFJNDIName, 'false')
        
        print "script returns successfully from creating queues."   
    except Exception, e:
        print e 

        dumpStack()
        raise 
#=================================================================
#   Set Data Source to target server...............
#=================================================================
def associateDataSourceWithTarget(jdbcDataSourceName):
    startEdit()
    jdbcDataSourcemb = getMBean("JDBCSystemResources/" + jdbcDataSourceName)
    # Target the resource to the Target Manager Server
    print 'Add your managed server as the target of your JDBCSystemResource...'
    jdbcDataSourcemb.addTarget(getMBean("/Servers/" + managedServerName))
    print '...Done.'
    save()
    activate(block='true')

#=================================================================
#   Create JDBC system resource
#=================================================================
def createJDBC(businessArea, 
                         businessObject,
                         jdbcUrl,
                         jdbcDriverName,
                         jdbcUserName,
                         jdbcPassword):
    try:
        # Check if the jdbc system resource already exists, if no such resouse with the same name does not exist, 
        # Then create it first.
        startEdit()
        if businessObject.title() == 'None':
            jdbcDataSourceName = businessArea.title()
            jdbcDataSourceJNDIName = 'jdbc/' + businessArea
            jdbcConnectionPoolJNDIName = 'eis/db/' + businessArea
        else:
            jdbcDataSourceName = businessArea.title() + businessObject.title()
            jdbcDataSourceJNDIName = 'jdbc/' + businessArea  + '/' + businessObject
            jdbcConnectionPoolJNDIName = 'eis/db/' + businessArea  + '/' + businessObject

        jdbcDataSourcemb = getMBean("JDBCSystemResources/" + jdbcDataSourceName)
        if jdbcDataSourcemb is None:
            print 'The JDBC DataSource ', jdbcDataSourceName, ' has not been found, create...'
            cd('/')

            jdbcSR = create( jdbcDataSourceName, "JDBCSystemResource")

            jdbcResource = jdbcSR.getJDBCResource()

            jdbcResource.setName(jdbcDataSourceName)

            # Create Data Source Parameters
            dpBean =  jdbcResource.getJDBCDataSourceParams()
            dpBean.setGlobalTransactionsProtocol('TwoPhaseCommit')

            jdbcJNDINameArray = [jdbcDataSourceJNDIName]
            dpBean.setJNDINames(jdbcJNDINameArray)

            # Create the Driver Params
            drBean = jdbcResource.getJDBCDriverParams()
            drBean.setPassword(jdbcPassword) 
            drBean.setUrl(jdbcUrl)
            drBean.setDriverName(jdbcDriverName)

            # Set JDBC Driver properties
            propBean = drBean.getProperties()
            driverProps = Properties()
            driverProps.setProperty("user",jdbcUserName)

            e = driverProps.propertyNames()
            while e.hasMoreElements() :
                propName = e.nextElement()
                myBean = propBean.createProperty(propName)
                myBean.setValue(driverProps.getProperty(propName))

            # Create the Connection Pool Params
            ppBean = jdbcResource.getJDBCConnectionPoolParams()
            ppBean.setInitialCapacity(int(dbConnectionPoolInitialCapacity))
            ppBean.setMaxCapacity(int(dbConnectionPoolMaxCapacity))
            ppBean.setCapacityIncrement(int(dbConnectionPoolCapacityIncrement))
            ppBean.setTestConnectionsOnReserve(true)
            ppBean.setTestTableName('SQL SELECT 1 FROM DUAL')
            if (dbConnectionPoolShrinkPeriodMinutes != None) or (dbConnectionPoolShrinkPeriodMinutes != ''):
                ppBean.setShrinkFrequencySeconds(int(dbConnectionPoolShrinkPeriodMinutes))
            if (dbConnectionPoolLoginDelaySeconds != None) or  (dbConnectionPoolLoginDelaySeconds != ''):
                ppBean.setLoginDelaySeconds(int(dbConnectionPoolLoginDelaySeconds))

            # Create the KeepXaConnTillTxComplete 
            xaBean = jdbcResource.getJDBCXAParams()
            xaBean.setKeepXaConnTillTxComplete(1)
            xaBean.setXaRetryDurationSeconds(300)
            xaBean.setXaTransactionTimeout(120)
            xaBean.setXaSetTransactionTimeout(true)
            xaBean.setXaEndOnlyOnce(true)

            cd('/')
                    # Get target Cluster or Managed Server
            if clusterName != '':
                servermb=getMBean("Clusters/" + clusterName)
            elif managedServerName != '':
                servermb=getMBean("Servers/" + managedServerName)
            
            if servermb is None:
                print 'The Cluster/Managed server has not been found, please create it first.'
                raise ValueError

            # Target the resource to the Cluster/Target Manager Server
            print 'Add your managed server as the target of your JDBCSystemResource...'
            jdbcSR.addTarget(servermb)
            save()
            activate(block='true');
            makeDBDeploymentPlan(jdbcDataSourceJNDIName, jdbcConnectionPoolJNDIName)
            print '...Done'

        else:
            print 'The JDBC Data Source ',  jdbcDataSourceName, ' exists.'
    except Exception, e:
        print e 

        dumpStack()
        raise 
#=================================================================
#   Re-deploy
#=================================================================
def  redeployJMSAdapter():
    print "Redeploy JmsAdapter with updated plan...."
    startEdit()	
    activate(block='true');
    cd('/AppDeployments/JmsAdapter/Targets');
    redeploy(jmsAdapterName, jmsPlanPath,targets=cmo.getTargets());

def  redeployDBAdapter():
    print "Redeploy DBAdapter with updated plan...."
    startEdit()	
    activate(block='true');
    cd('/AppDeployments/DbAdapter/Targets');
    redeploy(dbAdapterName, dbPlanPath,targets=cmo.getTargets());

#=================================================================
#   Update JmsAdapter and DBAdapter with updated deployment plans
#=================================================================
def  updateJMSAdapter():
    print "Update JmsAdapter with updated plan...."
    startEdit()	
    activate(block='true');
    cd('/AppDeployments/JmsAdapter/Targets');
    updateApplication(jmsAdapterName, jmsPlanPath,targets=cmo.getTargets());

def  updateDBAdapter():
    print "Update DBAdapter with updated plan...."
    startEdit()	
    activate(block='true');
    cd('/AppDeployments/DbAdapter/Targets');
    updateApplication(dbAdapterName, dbPlanPath,targets=cmo.getTargets());


	#=================================================================
#   Main process
#=================================================================
 

execfile("/ofmwscripts/wlstCustomUtils.py")
resBundleProp ='/home/oraclesoa/.resourceBundle.properties'
targetServer = ''
reDeployMode = False

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-r':
        reDeployMode = True
        args = args[1:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

serverUrl = getAdminServerT3Url(targetServer)

if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    sList = getHostNameList(targetServer)
    lServer = getLocalHostName()
    if not lServer in sList:
        print ww.bcolors.RED + "This Script with -e " + targetServer + " has to be run from one of the following servers:" + ww.bcolors.ENDC
        print ww.bcolors.WARNING , sList , ww.bcolors.ENDC
        sys.exit()
    print "Target Server:" + targetServer
    
    if targetServer == 'TST' or targetServer == 'TQA' or targetServer == 'PROD':
        print "This is a clustered Environment"
        isCluster = True
    else:
        print "This is a NONE-clustered Environment"
        isCluster = False

try: 
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)
    print "Resource Bundle Properties:" + resBundleProp
    parsePropInfo()
    edit()

    # Create Data Source
    for oneDS in dsInfoList:         
        print 'createJDBC(', oneDS[0].strip(), oneDS[1] .strip(), oneDS[2].strip(), oneDS[3].strip(), oneDS[4].strip(), oneDS[5].strip(), ')'
        createJDBC(oneDS[0].strip(), 
                           oneDS[1].strip() ,
                           oneDS[2].strip(),
                           oneDS[3].strip(),
                           oneDS[4].strip(),
                           oneDS[5].strip())

    # Create Topic Bundle
    for oneTopic in topicInfoList:      
        print 'createTopicBundle(' , oneTopic[0], oneTopic[1] , ')'
        createTopicBundle(oneTopic[0].strip(), oneTopic[1].strip() )

    for oneQueue in queueInfoList:
        print 'createQueueBundle(', oneQueue[0].strip(), oneQueue[1].strip(), ')'
        createQueueBundle(oneQueue[0].strip(), oneQueue[1].strip()) 

    if reDeployMode == 'redeploy':
	# Re-deploy the JMS plan and DB plan
       if len(queueInfoList) > 0 or len(topicInfoList) > 0:
         if jmsPlanPath != '':
            redeployJMSAdapter()
       if len(dsInfoList) > 0:
         if dbPlanPath != '':
            redeployDBAdapter()
    else:
	# UPdate JmsAdapter and DBAdapter with updated JMS plan and DB plan
       if len(queueInfoList) > 0 or len(topicInfoList) > 0:
         if jmsPlanPath != '':
            updateJMSAdapter()
       if len(dsInfoList) > 0:
         if dbPlanPath != '':
            updateDBAdapter()

except Exception, e:
    print e 
    print "Error while creating your system resources!!!!"
    dumpStack()
    raise 

