#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
import os, sys, wlstwrapper as ww
from weblogic.management.security.authentication import GroupEditorMBean
execfile("/ofmwscripts/wlstCustomUtils.py")
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script is to confirm a user's role in the specified SOA server.
         Usage: checkUserRoles.py -e environment -u user_name
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
            -u: User name you want tto confirm
'''

user = ''
targetServer = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-u':
        user = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)

    atnr=cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider("CenovusAD")
    if atnr.isMember('OracleSOAAdmin', user, true) == 0:  
        print  user + " dose not have admin privilege of OracleSOAAdmin"
    else:
        print  user + " has admin privilege of OracleSOAAdmin"
        
    if atnr.isMember('OracleSOADeveloper', user, true) == 0:  
        print user + " dose not have developer privilege of OracleSOADeveloper"
    else:
        print  user + " has developer privilege of OracleSOADeveloper"

disconnect()
exit()