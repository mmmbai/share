#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
import os, sys, wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")

usageText = '''
                <<<<< Read Me >>>>>
         This script is to list all custom DataSources' user and password.

         Usage: listAllCustomDataSourcePW.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''
systemDSList = [
                'BAMDataSource',
                'EDNDataSource',
                'EDNLocalTxDataSource',
                'OraSDPMDataSource',
                'SOADataSource',
                'SOALocalTxDataSource',
                'mds-owsm',
                'mds-soa'
                ]
allDSList = ()
targetServer = ''

args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

print "Target Server:" + targetServer

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    if os.getenv('un') is None or os.getenv('pw') is None:
        print "Currently user you logged in is:" + os.getenv('USER')
        userid = raw_input("Please enter your user ID:")
        passwd = raw_input("Please enter your password:")
        connect(userid, passwd, serverUrl)
    else:
        connect(os.getenv('un'), os.getenv('pw'), serverUrl)
        
    edit()
    startEdit()
    cd('JDBCSystemResources')
    allDSList=cmo.getJDBCSystemResources()
    for oneDS in allDSList:
        dsName = oneDS.getName()
        if not dsName in systemDSList:
            cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCDriverParams/'+dsName+'/Properties/'+dsName+'/Properties/user')
            userName = get('Value')
            cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCDriverParams/'+dsName)
            es = get('PasswordEncrypted')
            print userName
            print es
        else:
            pass
            # print  'Changing the Password for DataSource ', dsName
            # cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCDriverParams/'+dsName)
            # set('PasswordEncrypted',es)
    #save()
    #activate()
 
    disconnect()
    sys.exit()
