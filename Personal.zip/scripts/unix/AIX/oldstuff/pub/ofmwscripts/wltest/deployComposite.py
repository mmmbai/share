#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

############################################################################
# By using SOA custom WLST commands, no matter the application's status,
# it can be deployed.
############################################################################ 
import sys
import re
import os
import os.path
import commands
#
# Define all necessary variables, but the can be replaced by command params
# Please refer to the usage 
# 

loadProperties('./serverEnv.properties')

# Default value when no parameters specified

# Check parameters, if there is not enough parameters, ask to input them
# by default, otherwise use userName and password passed from parameters
params = len(sys.argv)

if params == 1:
    print "At least you need to specify a composite name you want to deploy...Please try again."
    exit()
elif params == 2:
    compositeName = sys.argv[1]
    revision = ''
elif params == 3:
    compositeName = sys.argv[1]
    revision = sys.argv[2]
elif params == 4:
    compositeName = sys.argv[1]
    revision = sys.argv[2]
    if sys.argv[3] == 'true':
        overwrite = true
    elif sys.argv[3] == 'false':
        overwrite = false
elif params == 5:
    compositeName = sys.argv[1]
    revision = sys.argv[2]
    
    if sys.argv[3] == 'true':
        overwrite = true
    elif sys.argv[3] == 'false':
        overwrite = false
    
    if sys.argv[4] == 'true':
        fDefault = true
    elif sys.argv[4] == 'false':
        fDefault = false


# Get composite's full path name from the applications.properties
grepCmd = 'grep ' + compositeName + ' ' + appDockDir + '/applications.properties'

compositeAttr = commands.getoutput(grepCmd)

matchObj = re.match(r'composite\d+\s=\s(.*)', compositeAttr)
if matchObj:
    compositePath = matchObj.group(1).split(',')[0]
    
    if revision == '':
        revision = matchObj.group(1).split(',')[1]
    
    if params == 2 or params == 3 or params == 4:
        ow = matchObj.group(1).split(',')[2]
        fd = matchObj.group(1).split(',')[3]
    
    if params == 3 or params == 4:
        fd = matchObj.group(1).split(',')[3]
        
    
    if ow == 'true':
        overwrite = true
    else:
        overwrite = false
        
    if fd == 'true':
        fDefault = true
    else:
        fDefault = false

    partition = matchObj.group(1).split(',')[4]
    
    compositeFullPath = appDockDir + '/' + matchObj.group(1).split(',')[0]
    
    # Get Configuration Plan
    configurationPlan = compositeFullPath + '/' + compositeName + '_cfgplan_' + deployEnv + '.xml'
    if os.path.isfile(configurationPlan):
        print "Configuration plan for the specified deployment environment:"
        print configurationPlan
    else:
        print "No configuration plan can use."
    
    sarLoc = compositeFullPath + '/deploy/sca_' + compositeName + '_rev' + revision + '.jar'
    
    # Call SOA wlst deploy command with userName and password
    sca_deployComposite(deployTargetServerUrl, 
                        sarLoc, 
                        overwrite, 
                        user=username, 
                        password=password, 
                        forceDefault=fDefault, 
                        configplan=configurationPlan, 
                        partition=partition)
    exit()
else:
    print "No the composite could be found."
    exit()

