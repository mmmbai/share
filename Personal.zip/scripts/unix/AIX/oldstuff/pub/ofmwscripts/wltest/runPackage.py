#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : runPackage.py
# Description: This script is for packaging the composite applications registered in 
#              the applications.properties.
#
# Created by : Richard Wang
# Date       : Oct 20, 2011    
#
###############################################################################################
import re
import sys
import os
import os.path
import commands

# Load system related properties
loadProperties('/home/oraclesoa/.serverEnv.properties')

# Based on the appHome( Current working directory ), find the composites.properties file
appHome = os.getcwd()
if os.path.exists(appHome + "/composites.properties"):
    print "Found composites.properties under " + appHome
    prop = open(appHome + "/composites.properties", "r")
else:
    print "No composites.properties file found under " + appHome
    sys.exit()

# Parse Applications information
for line in prop:
    matchObj = re.match(r'(composite\d+=)(.*)', line)
    if matchObj: 
        composite = matchObj.groups('1')
        paramList = composite[1].split(",")
        compositeName = os.path.basename(paramList[0])
        compositeFullPath = appHome  +'/' + compositeName
        print 'compositeFullPath=' , compositeFullPath
        print 'compositeName=' , compositeName
        # sar Location
        sarFileName = compositeFullPath + '/deploy/sca_' + compositeName + '_rev' + paramList[1] + '.jar'

        if os.path.isfile(compositeFullPath + '/composite.xml'):
            print 'Found a composite.xml:' + compositeFullPath + ', invoke packaging....'
            # Generate jar/sar file name
            # CompositeName
            #Revision
            revision = paramList[1]
            sca_package(compositeFullPath,
                        compositeName,
                        revision,
                        oracleHome=oracleSOAHome
                        )
            print sarFileName + " has been generated successfully."
exit()
