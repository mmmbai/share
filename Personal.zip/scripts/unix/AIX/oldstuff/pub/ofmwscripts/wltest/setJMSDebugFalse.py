#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh 
###############################################################################################################
#
#  This script is to list up all JMS resources defined in the FMW environment and their status
#
#  Created by: Michael Bai
#  Created on : Feb. 21, 2012
#
###############################################################################################################
import re, sys, traceback
loadProperties('/home/oraclesoa/wlst/serverEnv.properties')

# Connect to the soa
connect(username, password, domainUrl)
edit();	
startEdit();		
cd('Servers/soa_server1/ServerDebug/soa_server1');		
set('DebugJMSBackEnd','false');
set('DebugJMSBoot','false');
set('DebugJMSCDS','false');
set('DebugJMSCommon','false');
set('DebugJMSConfig','false');
set('DebugJMSDispatcher','false');
set('DebugJMSDistTopic','false');
set('DebugJMSDurableSubscribers','false');
set('DebugJMSFrontEnd','false');
set('DebugJMSJDBCScavengeOnFlush','false');
set('DebugJMSLocking','false');
set('DebugJMSMessagePath','false');
set('DebugJMSModule','false');
set('DebugJMSPauseResume','false');
set('DebugJMSSAF','false');
set('DebugJMSStore','false');
set('DebugJMST3Server','false');
set('DebugJMSWrappers','false');
set('DebugJMSXA','false');
save();	
activate();