#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
##############################################################################################
# File Name  : createJmsBundle.py
# Description: This script is to create the following system resources:
#              (1) Creating JMS topics, queues connection factory and connection pool 
#                  based on the Business Area, Business Object and the naming rules 
#                  provided
#
#              (2) Creating DB resources, including connection pools, datasources, 
#                  multidatasources
#                  and JDBC drivers based on the Business Area, Business Object and 
#                  the naming rules provided.
#
#                  The related server information and basic common information for creating 
#                  the system resources is defined in the serverEnv.properties.
#
#                  With regard to the JDBC, Queue/Topic specific information is defined in 
#                  resourceBundle.properties.
#
#              (3) One parameter with the following value can be specified:

#                   update  : With updated deployment plan update the adapter in place
#                   redeploy: Destroy all adapter's instance, deploy it again, in case some
#                   applications using the adapter, redeploy may cause problem........

#                  If you don't specify any parameter, the script will treat it as update
#
# Created by   : Richard Wang, Michael Bai
# Create Date  : Dec 8, 2011
# Last Modified: Jun 6, 2012
#
#############################################################################################
#Conditionally import wlstModule only when script is executed with jython
#if __name__ == '__main__': 
#    from wlstModule import *#@UnusedWildImport
from java.lang import System
import string
import re
import sys
import os.path
import traceback
import wlstwrapper as ww
# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
        This script has to be run from any nodes of the environment you specified!!!
        Usage: runDdeploy.py -e environment -p bundle-properties-file
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
            -r: Re-Deploy-Mode, if not specified, use update-mode(default mode)
'''
# Global varibales 

jmsServer = ''
jmsModule = ''
jmsAdapterName = ''
jmsSubDeployment = ''
jmsResourceObj = ''
dbAdapterName = ''
dbAdapterPath=''
dbPlanPath=''

queueInfoList = list()
topicInfoList = list()
dsInfoList = list()

#=================================================================
#   Internal Functions
#=================================================================
def parsePropInfo():
    try:
    
        if os.path.exists(resBundleProp):
            prop = open(resBundleProp, "r")
            
            # Pick up topic list
            for line in prop:
                matchObj = re.match(r'topic\d+=(.*)', line)
                if matchObj: 
                    print "Topic=>", matchObj.group(1)
                    topicInfoList.append(matchObj.group(1).split(','))

            prop.seek(0)
            
            # Pick up queue List
            for line in prop:
                matchObj = re.match(r'queue\d+=(.*)', line)
                if matchObj: 
                    print "Queue=>", matchObj.group(1)
                    queueInfoList.append(matchObj.group(1).split(','))

            prop.seek(0)
            
            # Pick up DB List
            for line in prop:
                matchObj = re.match(r'ds\d+=\s*(.*)', line)
                if matchObj: 
                    dsInfoList.append(matchObj.group(1).split(','))

            for oneDs in dsInfoList:
                print oneDs

    except:
        print "Error occurred:", sys.exc_info()[0]
        raise    
#=================================================================
#  The following modules are for modifying JMS Plan
#=================================================================
def makeJMSDeploymentPlan(connectionPoolName,sourceJNDI,isTopic, clientID):
    print "jmsAdapterPath=" + jmsAdapterPath
    print "jmsPlanPath=" + jmsPlanPath
    print "clientID=" + clientID
    myPlan=loadApplication(jmsAdapterPath, jmsPlanPath)
    cpClassName='oracle.tip.adapter.jms.IJmsConnectionFactory'
    cpVariablePropertyValue=''
    cpVariableValue=connectionPoolName
    cpVariableName='Varible_'+connectionPoolName+'_'+cpVariablePropertyValue
    xpath=makexpath(cpClassName,connectionPoolName,cpVariablePropertyValue)
    makeDeploymentPlanVariable(jmsAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)

    cpVariablePropertyValue='ConnectionFactoryLocation'
    cpVariableValue=sourceJNDI
    cpVariableName='Varible_'+connectionPoolName+'_'+cpVariablePropertyValue
    xpath=makexpath(cpClassName,connectionPoolName,cpVariablePropertyValue)
    makeDeploymentPlanVariable(jmsAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)
    
    if clientID != 'none':
        cpVariablePropertyValue='FactoryProperties'
        cpVariableValue=clientID
        cpVariableName='Varible_'+connectionPoolName+'_'+cpVariablePropertyValue
        xpath=makexpath(cpClassName,connectionPoolName,cpVariablePropertyValue)
        makeDeploymentPlanVariable(jmsAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)

    cpVariablePropertyValue='IsTopic'
    cpVariableValue=isTopic
    cpVariableName='Varible_'+connectionPoolName+'_'+cpVariablePropertyValue
    xpath=makexpath(cpClassName,connectionPoolName,cpVariablePropertyValue)
    makeDeploymentPlanVariable(jmsAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)
    myPlan.save();

#=================================================================
#  The following modules are for modifying JMS Plan
#=================================================================
def makexpath(className,cpVariableValue,cpVariablePropertyValue):
    xpathBase1='/weblogic-connector/outbound-resource-adapter/connection-definition-group/[connection-factory-interface="'
    xpathBase2=className
    xpathBase3='"]/connection-instance/[jndi-name="'
    xpathBase4=cpVariableValue
    if    cpVariablePropertyValue=='':
        xpathBase5='"]/jndi-name'
        xpath=xpathBase1+xpathBase2+xpathBase3+xpathBase4+xpathBase5
    else:
        xpathBase5='"]/connection-properties/properties/property/[name="'
        xpathBase6=cpVariablePropertyValue
        xpathBase7='"]/value'
        xpath=xpathBase1+xpathBase2+xpathBase3+xpathBase4+xpathBase5+xpathBase6+xpathBase7
    return xpath

#=================================================================
#  The following modules are for modifying JMS Plan
#=================================================================
def makeDeploymentPlanVariable(appName,wlstPlan, name, value, xpath, origin='planbased'):
    moduleDescriptorName='META-INF/weblogic-ra.xml'
    moduleOverrideName=appName+'.rar'
    while wlstPlan.getVariable(name):
        wlstPlan.destroyVariable(name)

    while wlstPlan.getVariableAssignment(name, moduleOverrideName, moduleDescriptorName):
        wlstPlan.destroyVariableAssignment(name, moduleOverrideName, moduleDescriptorName)
    variableAssignment = wlstPlan.createVariableAssignment(name, moduleOverrideName, moduleDescriptorName)
    variableAssignment.setXpath(xpath)
    variableAssignment.setOrigin(origin)
    wlstPlan.createVariable(name, value)

#=================================================================
#  The following modules are for modifying JDBC Plan
#=================================================================
def  makeDBDeploymentPlan(dbJNDI, connectionPoolJNDI):
    print "dbAdapterPath=" + dbAdapterPath
    print "dbPlanPath=" + dbPlanPath
    myPlan=loadApplication(dbAdapterPath, dbPlanPath)
    cpClassName='javax.resource.cci.ConnectionFactory'
    cpVariablePropertyValue=''
    cpVariableValue=connectionPoolJNDI
    cpVariableName='Varible_' + connectionPoolJNDI + '_' +cpVariablePropertyValue

    xpath=makexpath(cpClassName,connectionPoolJNDI,cpVariablePropertyValue)
    makeDeploymentPlanVariable(dbAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)

    cpVariablePropertyValue='xADataSourceName'
    cpVariableValue=dbJNDI
    cpVariableName='Varible_'+connectionPoolJNDI+'_'+cpVariablePropertyValue
    xpath=makexpath(cpClassName,connectionPoolJNDI,cpVariablePropertyValue)
    makeDeploymentPlanVariable(dbAdapterName,myPlan, cpVariableName,cpVariableValue,xpath)
    myPlan.save();

#=================================================================
#   Create Topic, Connection Factory, connection pool....
#=================================================================
def createTopicBundle(businessArea, businessObject):
    try:
        startEdit()

        # Compose Topic name
        if businessArea == 'none':
           # Distributed Topic
           jmsDTopicName = businessObject + 'Topic'
           jmsDTopicJNDIName = 'jms/' + businessObject + '/Topic'

        else:
            # Distributed Topic
           jmsDTopicName = businessArea + businessObject + 'Topic'
           jmsDTopicJNDIName = 'jms/' + businessArea + '/' + businessObject + '/Topic'
        # Create Uniform Distributed topic if it has not been created yet

        # Distributed Topic
        jmsDTopic = jmsResourceObj.lookupUniformDistributedTopic(jmsDTopicName)
        if jmsDTopic is None:
            print 'Create UNIFORM Distributed Topic.'
            jmsDTopic = jmsResourceObj.createUniformDistributedTopic(jmsDTopicName)
            print 'Set JNDI name for created distributed Topic.'
            jmsDTopic.setJNDIName(jmsDTopicJNDIName)
            jmsDTopic.setForwardingPolicy('Partitioned')
            jmsDTopic.setDefaultTargetingEnabled(true);
        else:
            print 'The specified Distributed topic already Exists.'
            
        
        # Compose Topic Connection Factory Name
        if businessArea == 'none':
           jmsTopicCFName = businessObject + 'TopicCF'
           jmsTopicCFJNDIName = 'jms/' + businessObject + 'INOUT' + '/Topic/CF'
           jmsTopicCPJNDIName = 'eis/'+ businessObject + '/INOUT/Topic'
        else:
           jmsTopicCFName = businessArea + businessObject + 'TopicCF'
           jmsTopicCFJNDIName = 'jms/' + businessArea + '/' + businessObject + 'INOUT' + '/Topic/CF'
           jmsTopicCPJNDIName = 'eis/'+ businessArea + '/' + businessObject + '/INOUT/Topic'

        # Create JMS connection factory if it has not been created
        jmsTopicCF = jmsResourceObj.lookupConnectionFactory(jmsTopicCFName)
        if jmsTopicCF is None:
            print 'Create the connection factory of your queue/topic...'
            jmsTopicCF = jmsResourceObj.createConnectionFactory(jmsTopicCFName) 
            jmsTopicCF.setJNDIName(jmsTopicCFJNDIName)
            #jmsTopicCF.getDefaultDeliveryParams().setDefaultUnitOfOrder('.System');
            #jmsTopicCF.getTransactionParams().setTransactionTimeout(3600);
            jmsTopicCF.getTransactionParams().setXAConnectionFactoryEnabled(true);
            jmsTopicCF.setDefaultTargetingEnabled(true);
         
            print "Set default Cliend-ID..."

            cp=jmsTopicCF.getClientParams()
            # cp.setClientId(jmsTopicCF.getName())
            cp.setClientIdPolicy('Unrestricted')
            cp.setSubscriptionSharingPolicy('Sharable')
            # print ".....................Client-ID is set"

            print '...Done.'
            
        else:
            print 'The specified OUT Connection Factory already exists.'
       
        activate()

        makeJMSDeploymentPlan(jmsTopicCPJNDIName,jmsTopicCFJNDIName, 'true', jmsDTopicName)

        print "script returns successfully from creating topics."   
    except Exception, e:
        print e 
        dumpStack()
        raise 
 
#=================================================================
#   Create Queue, Connection Factory, connection pool....
#=================================================================
def createQueueBundle(businessArea, businessObject):
    try:
        startEdit()
        # Compose Queue name
        if businessArea == 'none':
           jmsDQueueName = businessObject + 'Queue'
           jmsDQueueJNDIName = 'jms/' + businessObject + '/Queue'
           jmsQueueCFName = businessObject + 'QueueCF'
           jmsQueueCFJNDIName = 'jms/' + businessObject + 'INOUT' + '/Queue/CF'
           jmsQueueCPJNDIName = 'eis/' + businessObject + '/INOUT/Queue'
        else:
           jmsDQueueName = businessArea + businessObject + 'Queue'
           jmsDQueueJNDIName = 'jms/' + businessArea + '/' + businessObject + '/Queue'
           jmsQueueCFName = businessArea + businessObject + 'QueueCF'
           jmsQueueCFJNDIName = 'jms/' + businessArea + '/' + businessObject + 'INOUT' + '/Queue/CF'
           jmsQueueCPJNDIName = 'eis/' + businessArea + '/' + businessObject + '/INOUT/Queue'

        # Distributed Queue
        jmsDQueue = jmsResourceObj.lookupDistributedQueue(jmsDQueueName)
        if jmsDQueue is None:
           print 'Create Distributed Queue.'
           jmsDQueue = jmsResourceObj.createDistributedQueue(jmsDQueueName)
           print 'Set JNDI name for created distributed queue.'
           jmsDQueue.setJNDIName(jmsDQueueJNDIName)
           jmsDQueue.setLoadBalancingPolicy('Round-Robin');
        else:
           print 'The specified Distributed queue/topic already Exists.'

        if isCluster:
            # Create two member queues
            if businessArea == 'none':
               jmsMemberQueueName1 = businessObject + 'MemberQ1'
               jmsMemberQueueJNDIName1 = 'jms/' + businessObject + '/MemberQ1'
               jmsMemberQueueName2 = businessObject + 'MemberQ2'
               jmsMemberQueueJNDIName2 = 'jms/' + businessObject + '/MemberQ2'
            else:
               jmsMemberQueueName1 = businessArea + businessObject + 'MemberQ1'
               jmsMemberQueueJNDIName1 = 'jms/' + businessArea + '/' + businessObject + '/MemberQ1'
               jmsMemberQueueName2 = businessArea + businessObject + 'MemberQ2'
               jmsMemberQueueJNDIName2 = 'jms/' + businessArea + '/' + businessObject + '/MemberQ2'
            
            jmsQueue1 = jmsResourceObj.lookupQueue(jmsMemberQueueName1)
            if jmsQueue1 is None:
                print 'No specified queue/topic exists, create...'
                jmsQueue1 = jmsResourceObj.createQueue(jmsMemberQueueName1)
                # Set JNDI name of queue
                print 'Set JNDI name for the queue.'
                jmsQueue1.setJNDIName(jmsMemberQueueJNDIName1)
                jmsQueue1.setSubDeploymentName(jmsSubDeployment1.strip())
            else:
                print 'The specified queue/topic already Exists.'
            
            print 'Add the queue to the distribued queue.'
            jmsDQueue.createDistributedQueueMember(jmsMemberQueueName1)
#
            jmsQueue2 = jmsResourceObj.lookupQueue(jmsMemberQueueName2)
            
            if jmsQueue2 is None:
                print 'No specified queue/topic exists, create...'
                jmsQueue2 = jmsResourceObj.createQueue(jmsMemberQueueName2)
                print '...Done.'
                
                # Set JNDI name of queue
                print 'Set JNDI name for the queue.'
                jmsQueue2.setJNDIName(jmsMemberQueueJNDIName2)
                jmsQueue2.setSubDeploymentName(jmsSubDeployment2.strip())
            else:
                print 'The specified queue/topic already Exists.'
#
            print 'Add the queue to the distribued queue.'
            jmsDQueue.createDistributedQueueMember(jmsMemberQueueName2)
        else:
            # Create member queue if it has not been created yet
            # Compose Queue name
            if businessArea == 'none':
               jmsMemberQueueName = businessObject + 'MemberQ'
               jmsMemberQueueJNDIName = 'jms/' + businessObject + '/MemberQ'
            else:
               jmsMemberQueueName = businessArea + businessObject + 'MemberQ'
               jmsMemberQueueJNDIName = 'jms/' + businessArea + '/' + businessObject + '/MemberQ'
               
            # Create queue/topic if it has not been created yet
            jmsQueue = jmsResourceObj.lookupQueue(jmsMemberQueueName)
            if jmsQueue is None:
                print 'No specified queue/topic exists, create...'
                jmsQueue = jmsResourceObj.createQueue(jmsMemberQueueName)
                print '...Done.'
                
                # Set JNDI name of queue
                print 'Set JNDI name for the queue.'
                jmsQueue.setJNDIName(jmsMemberQueueJNDIName)
                jmsQueue.setSubDeploymentName(jmsSubDeployment.strip())
            else:
                print 'The specified queue/topic already Exists.'

            print 'Add the queue to the distribued queue.'
            jmsDQueue.createDistributedQueueMember(jmsMemberQueueName)
            print '...Done.'
    
        activate()

        makeJMSDeploymentPlan(jmsQueueCPJNDIName,jmsQueueCFJNDIName, 'false', 'none')
        
        print "script returns successfully from creating queues."   
    except Exception, e:
        print e 

        dumpStack()
        raise 
#=================================================================
#   Set Data Source to target server...............
#=================================================================
def associateDataSourceWithTarget(jdbcDataSourceName):
    startEdit()
    jdbcDataSourcemb = getMBean("JDBCSystemResources/" + jdbcDataSourceName)
    # Target the resource to the Target Manager Server
    print 'Add your managed server as the target of your JDBCSystemResource...'
    jdbcDataSourcemb.addTarget(getMBean("/Servers/" + managedServerName))
    print '...Done.'
    save()
    activate(block='true')

#=================================================================
#   Create JDBC system resource
#=================================================================
def createJDBC(businessArea, 
                         businessObject,
                         jdbcUrl,
                         jdbcDriverName,
                         jdbcUserName,
                         jdbcPassword):
    try:
        # Check if the jdbc system resource already exists, if no such resouse with the same name does not exist, 
        # Then create it first.
        startEdit()
        if businessObject.title() == 'None':
            jdbcDataSourceName = businessArea.title()
            jdbcDataSourceJNDIName = 'jdbc/' + businessArea
            jdbcConnectionPoolJNDIName = 'eis/db/' + businessArea
        else:
            jdbcDataSourceName = businessArea.title() + businessObject.title()
            jdbcDataSourceJNDIName = 'jdbc/' + businessArea  + '/' + businessObject
            jdbcConnectionPoolJNDIName = 'eis/db/' + businessArea  + '/' + businessObject

        jdbcDataSourcemb = getMBean("JDBCSystemResources/" + jdbcDataSourceName)
        if jdbcDataSourcemb is None:
            print 'The JDBC DataSource ', jdbcDataSourceName, ' has not been found, create...'
            cd('/')

            jdbcSR = create( jdbcDataSourceName, "JDBCSystemResource")

            jdbcResource = jdbcSR.getJDBCResource()

            jdbcResource.setName(jdbcDataSourceName)

            # Create Data Source Parameters
            dpBean =  jdbcResource.getJDBCDataSourceParams()
            dpBean.setGlobalTransactionsProtocol('TwoPhaseCommit')

            jdbcJNDINameArray = [jdbcDataSourceJNDIName]
            dpBean.setJNDINames(jdbcJNDINameArray)

            # Create the Driver Params
            drBean = jdbcResource.getJDBCDriverParams()
            drBean.setPassword(jdbcPassword) 
            drBean.setUrl(jdbcUrl)
            drBean.setDriverName(jdbcDriverName)

            # Set JDBC Driver properties
            propBean = drBean.getProperties()
            driverProps = Properties()
            driverProps.setProperty("user",jdbcUserName)

            e = driverProps.propertyNames()
            while e.hasMoreElements() :
                propName = e.nextElement()
                myBean = propBean.createProperty(propName)
                myBean.setValue(driverProps.getProperty(propName))

            # Create the Connection Pool Params
            ppBean = jdbcResource.getJDBCConnectionPoolParams()
            ppBean.setInitialCapacity(int(dbConnectionPoolInitialCapacity))
            ppBean.setMaxCapacity(int(dbConnectionPoolMaxCapacity))
            ppBean.setCapacityIncrement(int(dbConnectionPoolCapacityIncrement))
            ppBean.setTestConnectionsOnReserve(true)
            ppBean.setTestTableName('SQL SELECT 1 FROM DUAL')
            if (dbConnectionPoolShrinkPeriodMinutes != None) or (dbConnectionPoolShrinkPeriodMinutes != ''):
                ppBean.setShrinkFrequencySeconds(int(dbConnectionPoolShrinkPeriodMinutes))
            if (dbConnectionPoolLoginDelaySeconds != None) or  (dbConnectionPoolLoginDelaySeconds != ''):
                ppBean.setLoginDelaySeconds(int(dbConnectionPoolLoginDelaySeconds))

            # Create the KeepXaConnTillTxComplete 
            xaBean = jdbcResource.getJDBCXAParams()
            xaBean.setKeepXaConnTillTxComplete(1)
            xaBean.setXaRetryDurationSeconds(300)
            xaBean.setXaTransactionTimeout(120)
            xaBean.setXaSetTransactionTimeout(true)
            xaBean.setXaEndOnlyOnce(true)

            cd('/')
                    # Get target Cluster or Managed Server
            if clusterName != '':
                servermb=getMBean("Clusters/" + clusterName)
            elif managedServerName != '':
                servermb=getMBean("Servers/" + managedServerName)
            
            if servermb is None:
                print 'The Cluster/Managed server has not been found, please create it first.'
                raise ValueError

            # Target the resource to the Cluster/Target Manager Server
            print 'Add your managed server as the target of your JDBCSystemResource...'
            jdbcSR.addTarget(servermb)
            save()
            activate(block='true');
            makeDBDeploymentPlan(jdbcDataSourceJNDIName, jdbcConnectionPoolJNDIName)
            print '...Done'

        else:
            print 'The JDBC Data Source ',  jdbcDataSourceName, ' exists.'
    except Exception, e:
        print e 

        dumpStack()
        raise 
#=================================================================
#   Re-deploy
#=================================================================
def  redeployJMSAdapter():
    print "Redeploy JmsAdapter with updated plan...."
    startEdit()	
    activate(block='true');
    cd('/AppDeployments/JmsAdapter/Targets');
    redeploy(jmsAdapterName, jmsPlanPath,targets=cmo.getTargets());

def  redeployDBAdapter():
    print "Redeploy DBAdapter with updated plan...."
    startEdit()	
    activate(block='true');
    cd('/AppDeployments/DbAdapter/Targets');
    redeploy(dbAdapterName, dbPlanPath,targets=cmo.getTargets());

#=================================================================
#   Update JmsAdapter and DBAdapter with updated deployment plans
#=================================================================
def  updateJMSAdapter():
    print "Update JmsAdapter with updated plan...."
    startEdit()	
    activate(block='true');
    cd('/AppDeployments/JmsAdapter/Targets');
    updateApplication(jmsAdapterName, jmsPlanPath,targets=cmo.getTargets());

def  updateDBAdapter():
    print "Update DBAdapter with updated plan...."
    startEdit()	
    activate(block='true');
    cd('/AppDeployments/DbAdapter/Targets');
    updateApplication(dbAdapterName, dbPlanPath,targets=cmo.getTargets());

#=================================================================
#   Main process
#=================================================================
# Check parameters
execfile("/ofmwscripts/wlstCustomUtils.py")
resBundleProp ='/home/oraclesoa/.resourceBundle.properties'
targetServer = ''
reDeployMode = False

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-r':
        reDeployMode = True
        args = args[1:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

serverUrl = getAdminServerT3Url(targetServer)

if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    sList = getHostNameList(targetServer)
    lServer = getLocalHostName()
    if not lServer in sList:
        print ww.bcolors.RED + "This Script with -e " + targetServer + " has to be run from one of the following servers:" + ww.bcolors.ENDC
        print ww.bcolors.WARNING , sList , ww.bcolors.ENDC
        sys.exit()
    print "Target Server:" + targetServer
    
    if targetServer == 'TST' or targetServer == 'TQA' or targetServer == 'PROD':
        print "This is a clustered Environment"
        isCluster = True
    else:
        print "This is a NONE-clustered Environment"
        isCluster = False

try: 
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)
    print "Resource Bundle Properties:" + resBundleProp
    parsePropInfo()
    edit()

    # Create Data Source
    for oneDS in dsInfoList:         
        print 'createJDBC(', oneDS[0].strip(), oneDS[1] .strip(), oneDS[2].strip(), oneDS[3].strip(), oneDS[4].strip(), oneDS[5].strip(), ')'
        createJDBC(oneDS[0].strip(), 
                           oneDS[1].strip() ,
                           oneDS[2].strip(),
                           oneDS[3].strip(),
                           oneDS[4].strip(),
                           oneDS[5].strip())

    # Sanity check for JMS configuration...  complicated task!
    if isCluster:
        # In case of clustered environment.....
        # For each node, must has one persistence store, JMSServer and subDeployment defined
        # Only two-node cluster can exist in our environment
        startEdit()    
        # Get target Cluster 
        clusterMB1=getMBean("Clusters/soa_cluster/Servers/soa_server1")
        if clusterMB1 is None:
            print 'The soa_server1 has not been found, please create it first.'
            raise ValueError
        
        print 'CREATE FILESTORE1';
        fileStore1MB = getMBean('/FileStores/' + jmsPersistenceStore1)
        if fileStore1MB is None:
            print "None Persistence Store1 exist, create it...."
            cd('/')
            fileStore1MB = cmo.createFileStore(jmsPersistenceStore1);
            fileStore1MB.setDirectory(jmsPersistenceStorePath);
            targets1 = fileStore1MB.getTargets();
            targets1.append(clusterMB1);
            fileStore1MB.setTargets(targets1);
            print " The JMS Persistence Store1 has already been there.";
        
        clusterMB2=getMBean("Clusters/soa_cluster/Servers/soa_server2")
        if clusterMB2 is None:
            print 'The soa_server2 has not been found, please create it first.'
            raise ValueError
            
        print 'CREATE FILESTORE2';
        fileStore2MB = getMBean('/FileStores/' + jmsPersistenceStore2)
        if fileStore2MB is None:
            print "None Persistence Store2 exist, create it...."
            cd('/')
            fileStore2MB = cmo.createFileStore(jmsPersistenceStore2);
            fileStore2MB.setDirectory(jmsPersistenceStorePath);
            targets2 = fileStore2MB.getTargets();
            targets2.append(clusterMB2);
            fileStore2MB.setTargets(targets2);
            print " The JMS Persistence Store2 has already been there.";

        # Create JMS Module if it is not created yet   
        jmsModulemb = getMBean("JMSSystemResources/" + jmsModule)
        if jmsModulemb is None:
            print 'The JMS module ', jmsModule, ' has not been found, create...'
            jmsModulemb = create(jmsModule,"JMSSystemResource")
            # Target the resource to the Target cluster
            print 'Add your cluster as the target of your JMSSystemResource (JMS Module)...'
            jmsModulemb.addTarget(getMBean('Clusters/soa_cluster'))
            print '...Done'
        else:
            print 'The JMS Module exists.'
    
        # Get JMS Resource
        jmsResourceObj = jmsModulemb.getJMSResource()
    
        # Create JMS Server for node-1 if it dose not exist
        # Get soa_server1's MBean 
        soaServer1MB=getMBean("Clusters/soa_cluster/Servers/soa_server1")
        if soaServer1MB is None:
            print 'The soa_server1 has not been found under the specified cluster.'
            raise ValueError

        jmsServerMB1 = getMBean("JMSServers/" + jmsServer1)
        if jmsServerMB1 is None:
            print 'No specified JMSServer exists, create...'
            jmsServerMB1 = create(jmsServer1, 'JMSServer')
            # If this is a cluster configuration, the target server is one of the migratable Manager Server.
            # No!!!! SOA does not support migratable target, forclbly target to soa_server1
            print 'Also add soa_server1 as the target of your JMSServer...'
            jmsServerMB1.setPersistentStore(fileStore1MB);
            jmsServerMB1.addTarget(soaServer1MB)
            print jmsServer1 + " has been created"
        else:
            print 'The JMSServer ' +  jmsServer1 + ' already exists.'
            
        # Create JMS Server for node-2 if it dose not exist
        # Get soa_server2's MBean 
        soaServer2MB=getMBean("Clusters/soa_cluster/Servers/soa_server2")
        if soaServer2MB is None:
            print 'The soa_server2 has not been found under the specified cluster.'
            raise ValueError
        jmsServerMB2 = getMBean("JMSServers/" + jmsServer2)
        if jmsServerMB2 is None:
            print 'No specified JMSServer exists, create...'
            jmsServerMB2 = create(jmsServer2, 'JMSServer')
            # Target the resource to ONE and ONLY ONE Target Manager Server
            # If this is a cluster configuration, the target server is one of the migratable Manager Server.
            print 'Also add soa_server2 as the target of your JMSServer...'
            jmsServerMB2.setPersistentStore(fileStore2MB);
            jmsServerMB2.addTarget(soaServer2MB)
            print jmsServer2 + " has been created"
        else:
            print 'The JMSServer ' +  jmsServer2 + ' already exists.'
     
        # Create SubDeployment for each JMSServer if it has not been created
        subDepmb1 = jmsModulemb.lookupSubDeployment(jmsSubDeployment1.strip()) 
        # cd('/')
        # pwd()
        # subDepmb = getMBean("JMSSystemResources/" + jmsModule + "/SubDeployments/" + jmsSubDeployment)
        # subDepmb = getMBean("JMSSystemResources/CenovusSOAJMSModule/SubDeployments/defaultSubDeployment")
        print "SUBDEPMB1>>>>>>>>" , subDepmb1
        if subDepmb1 is None:
            # Create sub Deployment
            print 'No specified subDeployment exists, create...'
            subDepmb1 = jmsModulemb.createSubDeployment(jmsSubDeployment1.strip())  
            # Add your JMSServer as the target of your subDeployment
            print 'Add your JMSServer' + jmsServer1 + ' as the target of the subDeployment'
            subDepmb1.addTarget(jmsServerMB1)
        else:
            print 'The specified subDeployment already exists'
            
            print '...Done.'
            
        subDepmb2 = jmsModulemb.lookupSubDeployment(jmsSubDeployment2.strip()) 
        print "SUBDEPMB2>>>>>>>>" , subDepmb2
        if subDepmb2 is None:
            # Create sub Deployment
            print 'No specified subDeployment exists, create...'
            subDepmb2 = jmsModulemb.createSubDeployment(jmsSubDeployment2.strip())  
            # Add your JMSServer as the target of your subDeployment
            print 'Add your JMSServer' + jmsServer2 + ' as the target of the subDeployment'
            subDepmb2.addTarget(jmsServerMB2)
        else:
            print 'The specified subDeployment already exists'
            
            print '...Done.'
        activate()

    else:
        # In case of none-clustered environment.....
        startEdit()    
        print 'CREATE FILESTORE';
        soaServer1MB=getMBean("/Servers/soa_server1")
        if soaServer1MB is None:
            print 'The soa_server1 MBean has not been found.'
            raise ValueError

        fileStoreMB = getMBean('/FileStores/' + jmsPersistenceStore)
        if fileStoreMB is None:
            print "None Persistence Store exist, create it...."
            cd('/')
            fileStoreMB = cmo.createFileStore(jmsPersistenceStore);
            fileStoreMB.setDirectory(jmsPersistenceStorePath);
            targets = fileStoreMB.getTargets();
            targets.append(soaServer1MB);
            fileStoreMB.setTargets(targets);
        print " The JMS Persistence Store has already been there.";

        # Create JMS Module if it is not created yet   
        jmsModulemb = getMBean("JMSSystemResources/" + jmsModule)
        if jmsModulemb is None:
            print 'The JMS module ', jmsModule, ' has not been found, create...'
            jmsModulemb = create(jmsModule,"JMSSystemResource")
            # Target the resource to the Target cluster
            print 'Add your cluster as the target of your JMSSystemResource (JMS Module)...'
            jmsModulemb.addTarget(soaServer1MB)
            print '...Done'
        else:
            print 'The JMS Module exists.'
    
        # Get JMS Resource
        jmsResourceObj = jmsModulemb.getJMSResource()

        jmsServerMB1 = getMBean("/JMSServers/" + jmsServer)
        if jmsServerMB1 is None:
            print 'No specified JMSServer exists, create...'
            jmsServerMB1 = create(jmsServer, 'JMSServer')
            # If this is a cluster configuration, the target server is one of the migratable Manager Server.
            # No!!!! SOA does not support migratable target, forclbly target to soa_server1
            print 'Also add soa_server1 as the target of your JMSServer...'
            jmsServerMB1.setPersistentStore(fileStoreMB);
            jmsServerMB1.addTarget(soaServer1MB)
            print jmsServer + " has been created"
        else:
            print 'The JMSServer ' +  jmsServer + ' has already been there.'
            

        # Create SubDeployment if it has not been created
        subDepmb = jmsModulemb.lookupSubDeployment(jmsSubDeployment.strip()) 
        # cd('/')
        # pwd()
        # subDepmb = getMBean("JMSSystemResources/" + jmsModule + "/SubDeployments/" + jmsSubDeployment)
        # subDepmb = getMBean("JMSSystemResources/CenovusSOAJMSModule/SubDeployments/defaultSubDeployment")
        print "SUBDEPMB>>>>>>>>" , subDepmb
        if subDepmb is None:
            # Create sub Deployment
            print 'No specified subDeployment exists, create...'
            subDepmb = jmsModulemb.createSubDeployment(jmsSubDeployment.strip())  
            # Add your JMSServer as the target of your subDeployment
            print 'Add your JMSServer ' + jmsServer + ' as the target of the subDeployment'
            subDepmb.addTarget(jmsServerMB1)
            print '...Done.'
        else:
            print 'The specified subDeployment has already been there.'

        activate()
        
    # Create Topic Bundle
    for oneTopic in topicInfoList:
        print 'createTopicBundle(' , oneTopic[0], oneTopic[1] , ')'
        createTopicBundle(oneTopic[0].strip(), oneTopic[1].strip() )

    for oneQueue in queueInfoList:
        print 'createQueueBundle(', oneQueue[0].strip(), oneQueue[1].strip(), ')'
        createQueueBundle(oneQueue[0].strip(), oneQueue[1].strip()) 

    if reDeployMode:
    # Re-deploy the JMS plan and DB plan
       if len(queueInfoList) > 0 or len(topicInfoList) > 0:
         if jmsPlanPath != '':
            redeployJMSAdapter()
       if len(dsInfoList) > 0:
         if dbPlanPath != '':
            redeployDBAdapter()
    else:
    # UPdate JmsAdapter and DBAdapter with updated JMS plan and DB plan
       if len(queueInfoList) > 0 or len(topicInfoList) > 0:
         if jmsPlanPath != '':
            updateJMSAdapter()
       if len(dsInfoList) > 0:
         if dbPlanPath != '':
            updateDBAdapter()

except Exception, e:
    print e 
    print "Error while creating your system resources!!!!"
    dumpStack()
    raise 

