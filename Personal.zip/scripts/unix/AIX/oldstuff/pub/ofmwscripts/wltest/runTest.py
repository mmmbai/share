#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : runTest.py
# Description: This script is for performing the test of all composite applications registered in 
#                    the applications.properties. All test cases are defined in the test suites
#                    previously defined under the CompositeName/testsuites.
#                    From this script, sca_test wlst command is called (offline).
#
# Created by : Richard Wang
# Date          : Aug 31, 2011    
#
###############################################################################################
import re
import sys
import os
import commands

jndiPropFile = "/home/oraclesoa/.test-jndi.properties"
antTestPropFile = "/u01/app/oracle/fmw/Oracle_SOA1/bin/ant-sca-test.xml"

def reflectPartition():
    print "Set partition....."
    cmdStr = '\'s/name=\"scatest.partition\" value=\".*\"/'
    newStr = 'name=\"scatest.partition\" value=\"' + partition + '\"/g;\' '
    print "perl -p -i.save -e " + cmdStr + newStr + antTestPropFile
    commands.getoutput("perl -p -i.save -e " + cmdStr + newStr + antTestPropFile)
    print "......Done"
    
def initJndiPropFile():
    print "initJndiPropFile....."
    #########################################################################
    #  This jndi properties is only for running test suite by using  wlst
    #  command (sca_test) or ant test utility.
    #########################################################################
    outFile = open(jndiPropFile, 'w')
    aLine = "java.naming.factory.initial=weblogic.jndi.WLInitialContextFactory\n"
    outFile.write(aLine)
    aLine = "dedicated.connection=true\n"
    outFile.write(aLine)
    aLine = "dedicated.rmicontext=true\n"
    outFile.write(aLine)
    aLine = "java.naming.provider.url=" + targetServerUrl + "/soa-infra\n"
    outFile.write(aLine)
    aLine = "java.naming.security.principal=" + targetUsername  + "\n"
    outFile.write(aLine)
    aLine = "java.naming.security.credentials=" + targetPassword + "\n"
    outFile.write(aLine)
    outFile.close()
    print "......Done"

    return 
    
def cleanupJndiPropFile():
    print "Clean up the Jndi properties file...."
    commands.getoutput("cat /dev/null >" + jndiPropFile)
    print "......Done"

    return
########################## Main ##############################################################
# Preformatted UsageText
usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script only function with the following prerequisites:
           [1] This tool can only be invoked after "runDeploy"
           [2] Target server must be the same with "runDeploy"

         Usage: runTest.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''
targetServer = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print usageText
    sys.exit()

# Load server related properties
loadProperties('/home/oraclesoa/.serverEnv.properties')

# Based on the appHome( Current working directory ), find the composites.properties file
appHome = os.getcwd()
if os.path.exists(appHome + "/composites.properties"):
    print "Found composites.properties under " + appHome
    prop = open(appHome + "/composites.properties", "r")
else:
    print "No 'composites.properties' file found under " + appHome
    sys.exit()
    

print "Target Server:" + targetServer

if targetServer == 'dev1' or targetServer == 'DEV1':
    targetServerUrl = dev1MServerT3Url
    targetUsername = dev1ServerUser
    targetPassword = dev1ServerPassword
elif targetServer == 'dev2' or targetServer == 'DEV2':
    targetServerUrl = dev2MServerT3Url
    targetUsername = dev2ServerUser
    targetPassword = dev2ServerPassword
elif targetServer == 'tqa' or targetServer == 'TQA':
    targetServerUrl = tqaMServerT3Url
    targetUsername = tqaServerUser
    targetPassword = tqaServerPassword
elif targetServer == 'tst' or targetServer == 'TST':
    targetServerUrl = tstMServerT3Url
    targetUsername = tstServerUser
    targetPassword = tstServerPassword
elif targetServer == 'prod' or targetServer == 'PROD':
    targetServerUrl = prodMServerT3Url
    targetUsername = prodServerUser
    targetPassword = prodServerPassword
elif targetServer == 'lab' or targetServer == 'LAB':
    targetServerUrl = labMServerT3Url
    targetUsername = labServerUser
    targetPassword = labServerPassword
else:
    print usageText
    sys.exit()

# create temporary jndi.properties for a specific server environment
initJndiPropFile()

# Parse Applications information
try:
    for line in prop:
        matchObj = re.match(r'(composite\d+=)(.*)', line)
        if matchObj: 
            composite = matchObj.groups('1')
            paramList = composite[1].split(",")
            compositeName = os.path.basename(paramList[0])
            compositeFullPath = appHome  +'/' + compositeName

            applicationHome = os.path.dirname(compositeFullPath)
            revision = str.strip(paramList[1])
            ow = eval(str.strip(paramList[2]))
            fd = eval(str.strip(paramList[3]))
            partition = str.strip(paramList[4])
            reflectPartition()
            print 'compositeFullPath=' , compositeFullPath
            print 'applicationHome =' , applicationHome
            print 'compositeName=' , compositeName
            print 'Revision=', revision
            print 'Partition=', partition
            print 'OverWriten=', ow
            print 'Force Default=', fd
            # Because there may be more than one test suites under the folder
            # testsuites, and no naming rule is quoted, just assumpt each folders 
            # under the testsuites folder are presents as one test suite.
            
            # Compose the command.....
            lsCmd = "ls -l " + compositeFullPath + "/testsuites  | egrep '^d' "
            
            testSuiteList = commands.getoutput(lsCmd).split("\n")
            # print testSuiteList

            if len(testSuiteList) == 0 or testSuiteList == None:
                print "No test suites defined for this composite application !!!"
            else:
                for testSuiteLongName in testSuiteList:
                    tmpStrList = testSuiteLongName.split()
                    testSuiteName = tmpStrList[8]
                    if testSuiteName != "CVS":
                        sca_test(compositeName,
                                revision,
                                testSuiteName,
                                jndiPropFile,
                                oracleSOAHome,
                                javaHome)

except Exception, detail:
       print 'Exception:', detail
       sys.exit()

# cleanupJndiPropFile()
exit()

