#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

import os, os.path, sys, wlstwrapper as ww, traceback
execfile("/ofmwscripts/wlstCustomUtils.py")

usageText = '''
         Usage: listLoggers.py -e environment -s soa_server_name -p loggers_pattern
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
            -s: SOA server name, usually it can be soa_server1 or soa_server2
            -p: logger's pattern, for example "oracle.*"
'''
targetServer = ''
soaServer = ''
ptn = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    elif current_arg == '-p':
        ptn = args[1].strip()
        args = args[2:]
    elif current_arg == '-s':
        soaServer = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '' or soaServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
    
if ptn == '':
    ptn = "com.cenovus.*"

print "Target Server:" + targetServer
print "SOA server name:" + soaServer
print "Search Pattern:" + ptn

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)

    listLoggers(target=soaServer, pattern=ptn)
#==========================================================
# Exit WLST.
#==========================================================
disconnect()
exit()

