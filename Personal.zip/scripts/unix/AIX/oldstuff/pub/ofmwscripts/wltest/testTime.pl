#!/usr/bin/perl 
use strict;
use warnings;
my $index = 0;
my $loopCounter = 300000000;
my $startTime = time();
until ($loopCounter == 0 ){
	$index++;
	$loopCounter--;
}

my $endTime = time();
print "Index = $index\n";
my $past = $endTime - $startTime;
print "Used time = " ;
print $past;

exit;

