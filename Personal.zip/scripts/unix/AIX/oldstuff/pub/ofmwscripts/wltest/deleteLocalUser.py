#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

import os

# Get userName 
user = raw_input("Please Enter User Name you want to delete:")

group = raw_input("Please input the group the new user belongs to:")

loadProperties('/home/oraclesoa/wlst/serverEnv.properties')

# Connect to the AdminServer
connect(username, password, domainUrl)

serverConfig()
print 'lookup DefaultAuthenticator' 

atnr=cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider('DefaultAuthenticator')
print 'delete Local User ' + user
atnr.removeMemberFromGroup(group,user)
print 'The ' + user + 'has been deleted from the default group ' + group + '.'
atnr.removeUser(user)
print 'The ' + user + 'has been deleted.'
exit()