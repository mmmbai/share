#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
import os, sys, wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")

usageText = '''
                <<<<< Read Me >>>>>
         This script is to list all applications of WebLogic and their status.

         Usage: checkApps.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''
def appStatus(server_name):
   try:
       mBeans=adminHome.getMBeansByType("ApplicationRuntime")
       for bean in mBeans:
           if server_name != bean.getObjectName().getLocation():
               continue
           components= bean.lookupComponents()
           for componentRTList in components:
               #ejbRTList=componentRTList.getMBeansByType("EJBComponentRuntime")
               app = componentRTList.getParent().getName()
               istate=componentRTList.getDeploymentState()
               if istate == 0:
                   istate='UNPREPARED'
               if istate == 1:
                   istate='PREPARED'
               if istate == 2:
                   istate='ACTIVE'
               if istate == 3:
                   istate='NEW'

               print "%65s %50s %7s" % (str(componentRTList.getName()), app, istate)

   except:
       print "This Server has no Applications"

targetServer = ''

args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

print "Target Server:" + targetServer

serverUrl = getAdminServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    connect(os.getenv('un'), os.getenv('pw'), serverUrl)
    if targetServer == 'TST' or targetServer == 'TQA' or targetServer == 'PROD':
       print (ww.bcolors.RED + '------------------------------ SOA_SERVER1 Application status ' +
              '--------------------------------------------------------------' + ww.bcolors.ENDC)
       appStatus("soa_server1")
       print (ww.bcolors.RED + '------------------------------ SOA_SERVER2 Application status ' +
              '--------------------------------------------------------------' + ww.bcolors.ENDC)
       appStatus("soa_server2")
    else:
       print (ww.bcolors.RED + '------------------------------ SOA_SERVER1 Application status ' +
              '--------------------------------------------------------------' + ww.bcolors.ENDC)
       appStatus("soa_server1")

disconnect()
sys.exit()
