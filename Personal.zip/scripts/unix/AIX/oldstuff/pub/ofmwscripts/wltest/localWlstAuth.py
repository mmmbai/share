import os
import weblogic.security.internal.SerializedSystemIni
import weblogic.security.internal.encryption.ClearOrEncryptedService

def initAuth():
    kPath = os.getenv('SOA_DOMAIN') + "/security"
    es=weblogic.security.internal.SerializedSystemIni.getEncryptionService(kPath)
    ces=weblogic.security.internal.encryption.ClearOrEncryptedService(es)
    os.putenv('un', ces.decrypt(username))
    os.putenv('pw', ces.decrypt(password))
    return 0
def hello():
    print "Hello World!"
    return

