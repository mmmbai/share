#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : stopSOAServer.py
# Description: This script is to stop SOAServer on the node you logged in. 
#              First, check if the node manager is already up or not.
# Created by : Richard Wang
# Date       : May 15, 2012
# Updated    : 
#
###############################################################################################
import sys
import os
import wlstwrapper as ww

usageText = '''
                <<<<< Pre-condition to run this script >>>>>
         This script to start managed SOA server directly from Node Manager.
         Usage: stopSOAServer.py -s soa_server_name
            -s: soa_server_name, it depends on the node environment where
                this script is executed from. please refer to the following:
                LAB  (single node, iv00046p)--------------soa_server1
                DEV1 (single node, iv00047p)--------------soa_server1
                DEV2 (single node, iv00048p)--------------soa_server1
                TST  (paeud-two-node cluster, iv00045p)---soa_server1
                TST  (paeud-two-node cluster, iv00045p)---soa_server2
                TQA-OSB  (single-node, iv00093p)----------osb_server1
                TQA  (two-node cluster, iv00094p)---------soa_server1
                TQA  (two-node cluster, iv00095p)---------soa_server2
                PROD (two-node cluster, iv00076p)---------soa_server1
                PROD (two-node cluster, iv00077p)---------soa_server2
'''
soaServer = ''
args = sys.argv[:]
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-s':
        soaServer = args[1].strip()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
print "Target SOA Server Name:" + soaServer
if soaServer == '' or ( soaServer != 'soa_server1' and soaServer != 'soa_server2' and soaServer !='osb_server1'):
    print ww.bcolors.RED + "Bad soa server name." + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    exit(exitcode=100)

loadProperties('/home/oraclesoa/.serverEnv.properties')
ww.init(nmusername, nmpassword)
try:
    nmConnect(os.getenv('un'), 
                os.getenv('pw'),
                nmHost,
                nmPort,
                nmDomainName,
                nmDomainDir,
                nmType,
                nmIsVerbose.lower()
                )
    nmKill(soaServer)
    nmDisconnect()
    exit(exitcode=0)
except WLSTException, detail:
       print 'Exception:', detail
       dumpStack()
       exit(exitcode=100)
