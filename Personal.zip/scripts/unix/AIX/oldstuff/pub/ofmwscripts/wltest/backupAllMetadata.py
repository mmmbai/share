#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh

###############################################################################################
# File Name  : backupAllMetadata.py 
# Description: This script is for exporting metadata from the MDS_repository to a pre-defined 
#              directory. At this time, the repository partition is fixed to be 
#              soa-infra (Application), it may be changed for applying any specified
#              applications.
# Created by : Richard Wang
# Date       : Sep 15, 2011
###############################################################################################
import re
import sys
import os
import datetime
import wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")
applicationName = 'soa-infra'
mdsNamespace = "/apps/**"
mdsExportBasePath = "/ofmwmedia/cenovus_apps/MDS/"

usageText = '''
                <<<<< Read Me >>>>>
         This script is to export all custom metadata from MDS schema belongs to your
         specified SOA server. The exported tree-structure folder will be generated
         under /ofmwmedia/cenovus-apps/MDS with the name like XXX-MDS-YYYY-MM-DD-HH-MM.
         Where XXX is the environment specified by -e argument

         Usage: backupAllMetadata.py -e environment
            -e: Environment, it must be LAB, DEV1, DEV2, TST, TQA or PROD
'''
targetServer = ''
userid = ''
passwd = ''

args = sys.argv[:]  # Copy so don't destroy original
while len(args) > 0:
    current_arg = args[0]
    if current_arg == '-e':
        targetServer = args[1].strip().upper()
        args = args[2:]
    else:
        # Move index
        args = args[1:]
if targetServer == '':
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()

print "Target Server:" + targetServer
serverUrl = getServerT3Url(targetServer)
if serverUrl == "None":
    print ww.bcolors.RED + "Invalid target server" + ww.bcolors.ENDC
    print ww.bcolors.WARNING + usageText + ww.bcolors.ENDC
    sys.exit()
else:
    targetSOAServer = getSOAServer(targetServer)
    # Create working directory
    workDir = targetServer + "-MDS-" + datetime.datetime.now().strftime("%Y-%m-%d-%H-%M")
    mdsExportPath = mdsExportBasePath + workDir

    if os.getenv('un') is None or os.getenv('pw') is None:
        userid = raw_input("Enter username: ")
        MaskingThread = MaskingPassword()
        MaskingThread.start()
        passwd = raw_input("Enter password: ")
        MaskingThread.stop() 
        if userid.strip() == '' or passwd.strip() == '':
            print ww.bcolors.RED + "userid or password or both is empty, please try again." + ww.bcolors.ENDC
            exit()
    else:
        userid = os.getenv('un')
        passwd = os.getenv('pw')

    # Connect to the AdminServer
    connect(userid, passwd, serverUrl)
    exportMetadata(application=applicationName, 
                    server=targetSOAServer,
                    toLocation=mdsExportPath,
                    docs=mdsNamespace)
disconnect()
exit()

