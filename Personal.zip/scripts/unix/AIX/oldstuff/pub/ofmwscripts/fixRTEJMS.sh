#!/usr/bin/bash
#set -x

EXPECTED_ARGS=1
echo '\e[1;31m'
echo "---------------------------------------------------------------------------------"
echo " This script must be run from the same machine where the Scheduler residents     "
echo " For example, if you want to run this script for PROD, you need to login to      "
echo " iv00076p.cenovus.com, change your working directory to /ofmwscript, then invoke "
echo " fixJMSTopics.sh PROD                                                      "
echo "                                                                                 "
echo " Created by chandra rai                                                         "
echo " Created on Aug 09, 2013                                                         "
echo "---------------------------------------------------------------------------------"
echo '\e[0m'

if [ $# -ne $EXPECTED_ARGS ]
then
  echo "Usage: `basename $0` {arg}"
  exit 100
fi
echo "Target environment is " $1

cd /ofmwscripts

stopComposite.py -e $1 -a "JDEAccountReceiverService,1.5,True,True,Finance"
stopComposite.py -e $1 -a "JDECostCentreReceiverService,1.5,True,True,Finance"
stopComposite.py -e $1 -a "JDEVendorReceiverService,1.6,True,True,Finance"
stopComposite.py -e $1 -a "JDEDivisionOfInterestReceiverService,1.4,True,True,Finance"
stopComposite.py -e $1 -a "JDEPOInvoiceReceiptReceiverService,2.5,True,True,Finance"
stopComposite.py -e $1 -a "StatusChangeNotificationService,1.1, True,True,Finance"

sleep 60

startComposite.py -e $1 -a "JDEAccountReceiverService,1.5,True,True,Finance"
startComposite.py -e $1 -a "JDECostCentreReceiverService,1.5,True,True,Finance"
startComposite.py -e $1 -a "JDEVendorReceiverService,1.6,True,True,Finance"
startComposite.py -e $1 -a "JDEDivisionOfInterestReceiverService,1.4,True,True,Finance"
startComposite.py -e $1 -a "JDEPOInvoiceReceiptReceiverService,2.5,True,True,Finance"
startComposite.py -e $1 -a "StatusChangeNotificationService,1.1, True,True,Finance"

exit
