#!/usr/bin/env /u01/app/oracle/fmw/Oracle_SOA1/common/bin/wlst.sh
###############################################################################################
# File Name  : repairComposites.py
# Description: This script is to backup individual deployed composite with "UNKNOWN" state
#              to a specific folder and re-install it again in order to fix the "UNKNOWN"
#              state back to normal.
# Created by : Richard Wang
# Last update: Aug 21, 2012
#        
###############################################################################################
import re, sys, os
import wlstwrapper as ww
execfile("/ofmwscripts/wlstCustomUtils.py")

# Preformatted UsageText
usageText = '''
    Usage: repairComposite.py [-u update-type] -e environment -p partition -c composite -r revision
           -e: Environment, it must be one of the following servers:
               LAB, DEV1, DEV2, TST, TQA or PROD
           -u: Update type, the type of postdeployment changes (like DVM)
               to be exported, default is "all"
           -p: Partition
           -c: Composite
           -r: Revision
           
    Note: This script does not validate the Partition, Composite and Revision you input,
          leave them to the API, if the system could not find the one you specified, it will
          cause exception.
'''

username = 'weblogic'

password = 'labsoa01'

URL='t3://iv00046p.cenovus.com:7001'

connect(username,password,URL)




domainRuntime()

cd('ServerRuntimes')
servers=domainRuntimeService.getServerRuntimes()


for server in servers:
    serverName=server.getName()
    print '**************************************************'
    print serverName
    jmsRuntime = server.getJMSRuntime()
    connections = jmsRuntime.getConnections();  
    for connection in connections:  
        print('-Connection Name: ' + connection.getName()) 
        sessions = connection.getSessions()  
        for session in sessions:  
            print(' -Session Name: ' + session.getName())  
            consumers = session.getConsumers()  
            for consumer in consumers:  
                print('  -Consumer Name: ' + consumer.getName() + ', Bytes Received: ' + repr(consumer.getBytesReceivedCount()))  
                producers = session.getProducers()  
                for producer in producers:  
                    print('  -Producer Name: ' + producer.getName() + ',  Bytes Send: ' + repr(producer.getBytesSentCount()))
try:
    print ww.bcolors.RED + "Done" + ww.bcolors.ENDC
except Exception, detail:
       print 'Exception:', detail
       sys.exit()

exit()