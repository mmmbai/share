/*
*   ===========================================================================
*  $Source: /cvs/corp_root1/eai/sysadmin/Java/ExcaliburStatus.java,v $
*  $Date: 2007/03/21 20:08:13 $ @(#)$Revision: 1.3 $
*   ===========================================================================
*
*  Title: ExcaliburStatus.java
*
*  Author: Praneet Khatra
*
*  Descr: Return value of no. of rows from SYSTEM_SUBJECT_METRICS table from
*  the rows written in the past time interval in min, if no row is written in the past
*  time interval "0" is returned. This program is used by Hawk for Excalibur Integration Activity monitoring.
*
*  Usage:  Usage: java ExcaliburStatus --sid <SID> --username <UNAME> --password <PASSWORD> --interval <INTERVAL (min)>
*
*  Legal:  Copyright(C) 2007 EnCana Corporation, All Rights Reserved.
*
*  ===========================================================================
*/

import java.util.*;
import java.sql.*;
import gnu.getopt.Getopt;
import gnu.getopt.LongOpt;

public class ExcaliburStatus {

	public static void main(String[] args) {

		if (args.length != 8) {
		System.err.println("Usage: java ExcaliburStatus [--sid <SID>] [--username <UNAME>]  ");
		System.err.println(" [--password <PASSWORD>]  [--interval INTERVAL (min)] ");
		System.exit(1);
		}

		String sid = null ;
                	String uname = null ;
                	String password = null ;
                	String interval = null  ;
		
		LongOpt[] longopts = new LongOpt[4];
        		longopts[0] = new LongOpt("sid",      LongOpt.REQUIRED_ARGUMENT, null, 's');
        		longopts[1] = new LongOpt("username",     LongOpt.REQUIRED_ARGUMENT, null, 'u');
        		longopts[2] = new LongOpt("password",     LongOpt.REQUIRED_ARGUMENT, null, 'p');
        		longopts[3] = new LongOpt("interval",      LongOpt.REQUIRED_ARGUMENT, null, 'i');
       
        		Getopt g = new Getopt("test", args, "s:u:p:i:", longopts);
		int       c;
		while ((c = g.getopt()) != -1) {
            		switch(c) {
            		case 's':
                	sid = g.getOptarg();
                	break;
            		case 'u':
                	uname = g.getOptarg();
                	break;
            		case 'p':
                	password = g.getOptarg();
                	break;
            		case 'i':
                	interval = g.getOptarg();
                	break;
		default:
                	System.out.print("getopt() returned " + c + "\n");
            		}
       		 }


		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@"+sid+":1521:"+sid;
		Connection con = DriverManager.getConnection( url , uname , password);
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select count(1) from CBO_RAW" +
		" where EVENT_ACTION like '%CHANGE%' and STATUS_FLAG = 'SUCCESS' and CREATE_TIMESTAMP > SYSDATE - "+interval+"/1440");

		boolean exist = false;

		if (rs.next()) {
			exist = true;
			System.out.println(rs.getInt(1));
		}

		if ( exist == false)
			System.out.println("0");
		}
		catch (java.lang.Exception ex) {
			ex.printStackTrace();
		}
    	}
}

