#!/bin/ksh

#   /apps/tibco/src/SCCS/s.click2learn.sh  @(#)1.6  04/01/12 10:20:24
#   ===========================================================================
#
#   Title:   click2learn.sh
#
#   Author:  David Owen
#
#   Descr:   Simple shell script to extract the McDas passwords and then call
#            the click2learn perl script.
#
#   Usage:   click2learn.sh
#
#   Legal:   Copyright(C) 2003 EnCana Corporation, All Rights Reserved.
#
#   ===========================================================================

unalias -a

export PATH=/usr/bin:/bin
export ORACLE_HOME=/oracle/product/817
export TNS_ADMIN=/oracle/admin/network
export NLS_LANG=AMERICAN_AMERICA.WE8ISO8859P15

RSHUSER=c2learn
RSHSERV=sunsrv09
RSHCMD=/local/home/c2learn/c2learn/bin/send-files
TIBCO_HOME=/apps/tibco

PROPERTYHOME=${TIBCO_HOME}/Repositories/ReferenceData
PROPERTYFILE=${PROPERTYHOME}/Properties.cfg

ORAUSER=$(${TIBCO_HOME}/bin/perl -ne 'if ($_ =~ /MCDAS_JDBC_USERNAME/) {
                                    @cols=split /: */;
                                    print $cols[1], "\n";
                                    }' ${PROPERTYFILE})

ORAPASS=$(${TIBCO_HOME}/bin/perl -ne 'if ($_ =~ /MCDAS_JDBC_PASSWORD/) {
                                    @cols=split /: */;
                                    print $cols[1], "\n";
                                    }' ${PROPERTYFILE})

ORASERV=$(${TIBCO_HOME}/bin/perl -ne 'if ($_ =~ /MCDAS_JDBC_URL/) {
                                    @cols=split /: */;
                                    print $cols[6], "\n";
                                    }' ${PROPERTYFILE})

${TIBCO_HOME}/bin/click2learn.pl --orauser ${ORAUSER} \
                                 --orapass ${ORAPASS} \
                                 --oraserv ${ORASERV} \
                                 --rshuser ${RSHUSER} \
                                 --rshserv ${RSHSERV} \
                                 --rshcmd  ${RSHCMD} $@
