#!/bin/bash

# ----------------------------------------------------------------------------
# Title: file_compare.sh
#
# Purpose: This script will compare files on our tibco servers and output a
#	file showing the full path of script and the cksum results for the
#	environment it is run on. The output will be pipe-delimited so that it can be
#	ported into Excel easily. The resulting output will then need to be blended
#	with the other server output files.
#
# Usage:	$1 = The full path to perform the file compares.
#		$2 = The output path and filename for the results.
#
# Returns: File output to specified $2 argument.
# ----------------------------------------------------------------------------

TIBHOME=/apps/tibco/
. ${TIBHOME}.tibrc
. /apps/tibco/lib/test_shell_lib/utility.sandox.inc

# check usage
if [[ $# -ne 2 ]]; then
        echo "Usage: `basename $0` [full path to files for checksum] [output file path and name]"
	logger "${LOG_WARN}" "file_compare.sh" "Usage: `basename $0` [full path to files for checksum] [output file path and name]"
	exit -1
fi

FULL_PATH=$1
OUTPUT_FILE=$2

# check full path of file compare
if [[ ! -d ${FULL_PATH} ]]; then
	echo "Arg 1: ${FULL_PATH} is not a directory, exiting now."
	logger "${LOG_WARN}" "file_compare.sh" "Arg 1: ${FULL_PATH} is not a directory, exiting now."
	exit -1
fi

declare -a FILE_ARRAY
FILE_ARRAY=`arrayOfDirectoryListing ${FULL_PATH}`

TMP_ARRAY=( `echo "${FILE_ARRAY[@]}"` )
FILE_ARRAY_LENGTH=${#TMP_ARRAY[*]}
COUNT=0

if [[ -f ${OUTPUT_FILE} ]]; then
	rm -f ${OUTPUT_FILE}
fi

while [ "${COUNT}" -lt "${FILE_ARRAY_LENGTH}" ]
do
	CKSUM_RESULT=`cksum ${FULL_PATH}${TMP_ARRAY[${COUNT}]} | awk -F' ' '{ print $1 }'`
	echo "${FULL_PATH}${TMP_ARRAY[${COUNT}]}|${CKSUM_RESULT}" >> ${OUTPUT_FILE}
	COUNT=`expr ${COUNT} + 1`
done

