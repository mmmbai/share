#!/apps/tibco/bin/perl -w

#   /apps/tibco/src/SCCS/s.click2learn.pl  @(#)1.11  04/01/15 12:39:38
#   ===========================================================================
#
#   Title:  click2learn.pl
#
#   Author: David Owen
#
#   Descr:  Extract the Click 2 Learn files into people.txt, heirarchy.txt
#           and mapping.txt.
#
#   Usage:  click2learn.pl [ { -h | --help } ] --rshuser user ...
#
#   Legal:  Copyright(C) 2003 EnCana Corporation, All Rights Reserved.
#
#   ===========================================================================

use strict;
use Getopt::Long;
use DBI qw(:sql_types);
use DBD::Oracle qw(:ora_types);

# Options and option flags

my($help);
my($orauser);
my($orapass);
my($oraserv);
my($rshuser);
my($rshserv);
my($rshcmd);
my($debug);

# Local variables

my(@res);
my($peo);
my($map);
my($result);
#my($active);

my($active_user_count) = 0;
my($other_user_count)  = 0;

my($tibco_temp)     = "/apps/tibco/temp";

my($people_file)    = "$tibco_temp/people.txt";
my($hierarchy_file) = "$tibco_temp/hierarchy.txt";
my($mapping_file)   = "$tibco_temp/mapping.txt";

my($dbh);
my($sth);

if (defined(Getopt::Long::Configure)) {
    Getopt::Long::Configure("bundling", "no_ignore_case_always");
}
else {
    Getopt::Long::config("bundling", "no_ignore_case_always");
}

if (!GetOptions("help|h"     => \$help,
                "orauser=s"  => \$orauser,
                "orapass=s"  => \$orapass,
                "oraserv=s"  => \$oraserv,
                "rshuser=s"  => \$rshuser,
                "rshserv=s"  => \$rshserv,
                "rshcmd=s"   => \$rshcmd,
                "dBug"       => \$debug          # Undocumented flag
               )) {
    usage();
    exit 1;
}

if ($help) {
    usage();
    exit 0;
}

# All parameters apart from '-h' are mandatory.

if (!defined($orauser)  ||
    !defined($orapass)  ||
    !defined($oraserv)  ||
    !defined($rshuser)  ||
    !defined($rshserv)  ||
    !defined($rshcmd))    {
    usage();
    exit 1;
}

$dbh = DBI->connect("dbi:Oracle:$oraserv", $orauser, $orapass)
    or die "Cannot connect to Oracle: $!\n";

open(PEOPLE,  ">$people_file")  or die("$0: Unable to open people file: $!\n");
open(MAPPING, ">$mapping_file") or die("$0: Unable to open mapping file: $!\n");

$sth = $dbh->prepare("BEGIN ref_data.mcdas.getPeopleIncludingSafetyCode(:result); END;");

$sth->bind_param_inout(":result", \$result, 0, {ora_type => ORA_RSET});
$sth->execute();
$sth->finish;

print PEOPLE "\n";         # Blank first line for the C2L people.

while (@res = $result->fetchrow_array) {

         #  0 EMPLID
         #  1 USER_ID
         #  2 EMPL_STATUS_DESC
         #  3 SUPERVISOR_ID
         #  4 LAST_NAME
         #  5 FIRST_NAME
         #  6 JOBTITLE
         #  7 LOCATION_DESC
         #  8 COUNTRY
         #  9 COUNTRY_DESC
         # 10 EMAIL_ADDR
         # 11 SEARCH_TYPE
         # 12 DEPTID
         # 13 SAFETY_INDICATOR
         # 14 COUNTRY - EMPL_STATUS - SAFETY_INDICATOR

    # Make sure we have no undefined elements.

    $res[3]  = ''  if !$res[3];
    $res[3]  = ''  if  $res[3] eq '0';
    $res[5]  = '?' if !$res[5];
    $res[13] = ''  if !$res[13];
    @res     = map { (!defined($_) || $_ eq '.' ? '' : $_) } @res;

    #$active  = (defined($res[11]) && ($res[11] eq 'E' || $res[11] eq 'S') ? 1 : 0);

    $peo  = "$res[0]|$res[13]|$res[2]|$res[3]||$res[4]|$res[5]||||$res[6]|||||$res[7]||";
    $peo .= "$res[9]||$res[10]|||||||$res[1]||$res[11]|$res[11]||||||$res[12]|$res[8]|$res[14]|||||||||||||";

    if ($res[11]) {
        ++$active_user_count;

        # Only need the mapping file for active users.

        $map = "$res[0]|$res[1]";
        print MAPPING $map, "\n";
    }
    else {
        ++$other_user_count;
    }

    print PEOPLE  $peo, "\n";
}

close PEOPLE;
close MAPPING;


open(HIER, ">$hierarchy_file") or die("$0: Unable to open hierarchy file: $!\n");

print HIER "\n";               # Another blank first line.

$sth = $dbh->prepare("BEGIN ref_data.mcdas.getHierarchy(:result); END;");

$sth->bind_param_inout(":result", \$result, 0, {ora_type => ORA_RSET});
$sth->execute();
$sth->finish;

while (@res = $result->fetchrow_array) {

    # As before

    $res[3] = '' if !$res[3];
    @res    = map { (!defined($_)?'':$_) } @res;

    print HIER "$res[0]|$res[1]|$res[2]|$res[3]", "|" x 23, "\n";
}

#
# Append the country data to the end of the hierarchy file
#
$sth = $dbh->prepare("BEGIN ref_data.mcdas.getCountry(:result); END;");

$sth->bind_param_inout(":result", \$result, 0, {ora_type => ORA_RSET});
$sth->execute();
$sth->finish;

while (@res = $result->fetchrow_array) {

    # As before

    $res[2] = '' if !$res[2];
    @res    = map { (!defined($_)?'':$_) } @res;

    print HIER "$res[0]||$res[1]|$res[2]", "|" x 23, "\n";
}

#
# Append the status data to the end of the hierarchy file
#

$sth = $dbh->prepare("BEGIN ref_data.mcdas.getCountryStatusSafety(:result); END;");

$sth->bind_param_inout(":result", \$result, 0, {ora_type => ORA_RSET});
$sth->execute();
$sth->finish;

while (@res = $result->fetchrow_array) {

    # As before

    $res[2] = '' if !$res[2];
    @res    = map { (!defined($_)?'':$_) } @res;

    print HIER "$res[0]||$res[1]|$res[2]", "|" x 23, "\n";
}

close HIER;

if (!$debug) {
    system('/usr/bin/rcp', $people_file,    "$rshuser\@$rshserv:");
    system('/usr/bin/rcp', $hierarchy_file, "$rshuser\@$rshserv:");

    system('/usr/bin/rsh', '-n', '-l', $rshuser, $rshserv, $rshcmd);

    # There is no point in checking any error status, since it is coming back
    # from rsh and *not* the command that rsh is running.

    unlink($people_file);
    unlink($hierarchy_file);
    unlink($mapping_file);
}

print "Transferred $active_user_count active users and $other_user_count non active.\n";

exit 0;

sub usage {

print STDERR <<USAGE
usage: click2learn.pl --orauser user --orapass password --oraserv server
                      --rshuser user --rshserv server --rshcmd command

      --orauser   Username of the oracle schema to extract the data from.
      --orapass   Password for orauser.
      --oraserv   The server that the schema resides on.
      --rshuser   The rsh user that will be used to execute the transfer
                  commands.
      --rshserv   Server to copy files to and subsequently execute commands
                  on.
      --rshcmd    Command to issue on remote server to send files to
                  Click2Learn.

USAGE

}

=head1 NAME

click2learn.pl - File transfer script for the Policy Training and Tracking project.

=head1 DESCRIPTION

This script is used by the Policy Training and Tracking project to transfer
current EnCana personnel and hierarchy data to the Click2Learn server.

A brief outline (this is not rocket science):

The script extracts data from the McDas repository via the McDas package.
This contains the 2 routines that need to be called.  (Close inspection of
this package will reveal that the hierarchy data is not held directly by
McDas and is extracted from a JDE snapshot.)

The data, once extracted, is filtered for nulls and "."'s, (McDas uses
"."'s to distinguish blank values.  These are not needed on the remote
system.) and the output shoved into 2 files: people.txt and hierarchy.txt.

These two files are then copied to the transfer host (rshserv).  In effect,
this is going to be sunsrv09 for the forseable future.  Once there, a
remote command is executed on the remote host that sends the files to
Click2Learn.  Currently, the transport of choice is sftp.  Passphraseless
transfer is achieved by means of the ssh-agent running in the background.
The shell script that does the transfer, sets the environment variables in
/local/home/c2learn/c2learn/.ssh/.ssh-agent.  This should have the correct
key loaded into memory.  This is a dependency that we cannot easily check,
so if the transfer stops for some reason, go to the rshserv (sunsrv09) and
check that ssh-agent is running.  If not, issue the following:

  ssh-agent > /local/home/c2learn/c2learn/.ssh/.ssh-agent
  . /local/home/c2learn/c2learn/.ssh/.ssh-agent
  ssh-add

whereupon you will be prompted for the passphrase.  You have to know where
to look to get that.

Other than that, the only other dependency is the .rhosts file for the
c2learn account on the rshserv.  This must have

"ss1045l.encana.com tibadmin"

as one of the lines.  (Note that the tibprod01 alias does not seem to
work.)

=cut
