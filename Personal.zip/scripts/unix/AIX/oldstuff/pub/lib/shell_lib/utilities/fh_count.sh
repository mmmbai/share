#!/bin/ksh

#
# Show the top offenders of file-handler usage...
#

find /proc -name 'fd' -type d 2>/dev/null| while read dir; do
count=`ls $dir | wc -l`
echo $count $dir 
done 2>/dev/null | sort -n -r | head

