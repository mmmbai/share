#!/bin/bash

# ----------------------------------------------------------------------------
# Title: file_cksum_merger.sh
#
# Purpose: This script will compare a master file (file 1) and a secondary
#	file (file 2) and merge the cksums of files together into a single
#	results file. If file 2 does not contain the file, then the cksum
#	entry will be a zero (0). This script is used after the file_compare.sh
#	script has created two separate files of the same directory.
#
# Usage:        $1 = The full path and name of file 1.
#		$2 = The full path and name of file 2.
#               $3 = The output path and filename for the results.
#
# Returns: File output to specified $3 argument.
# ----------------------------------------------------------------------------

TIBHOME=/apps/tibco/
. ${TIBHOME}.tibrc
. /apps/tibco/lib/test_shell_lib/utility.sandox.inc

# check usage
if [[ $# -ne 3 ]]; then
        echo "Usage: `basename $0` [full path master file] [full path to secondary file] [output file path and name]"
        logger "${LOG_WARN}" "file_cksum_merger.sh" "Usage: `basename $0` [full path to master file] [full path to secondary file] [output file path and name]"
        exit -1
fi

MASTER_FILE="${1}"
SECONDARY_FILE="${2}"
OUTPUT_FILE="${3}"

if [[ ! -f ${MASTER_FILE} ]] || [[ ! -f ${SECONDARY_FILE} ]]; then
	echo "Arg 1 and Arg 2 must be full path to existing files, exiting now."
	logger "${LOG_WARN}" "file_cksum_merger.sh" "Arg 1 and Arg 2 must be full path and file names, exiting now."
fi

declare -a MASTER_FILE_LISTING
MASTER_FILE_LISTING=( `cat ${MASTER_FILE} | awk -F'|' '{ print $1 }'` )

TMP_ARRAY=( `echo "${MASTER_FILE_LISTING[@]}"` )
MASTER_ARRAY_LENGTH=${#TMP_ARRAY[*]}
COUNT=0

while [ "${COUNT}" -lt "${MASTER_ARRAY_LENGTH}" ]
do
	LINE_SEARCH_RESULT=`grep "${MASTER_FILE_LISTING[${COUNT}]}|" ${SECONDARY_FILE}`
	MASTER_LINE_CKSUM=`grep "${MASTER_FILE_LISTING[${COUNT}]}|" ${MASTER_FILE} | awk -F'|' '{ print $2 }'`
	if [[ -z "${LINE_SEARCH_RESULT}" ]]; then
		# the result is null
		#echo "${LINE_SEARCH_RESULT} NOT found in file ${SECONDARY_FILE}"
		echo "${MASTER_FILE_LISTING[${COUNT}]}|${MASTER_LINE_CKSUM}|0|" >> ${OUTPUT_FILE}.diff
	else
		# the line exists, so pull out the cksum from file 2
		SECONDARY_LINE_CKSUM=`grep "${MASTER_FILE_LISTING[${COUNT}]}|" ${SECONDARY_FILE} | awk -F'|' '{ print $2 }'`
		
		# check if the two cksums are different
		if [[ "${MASTER_LINE_CKSUM}" -ne "${SECONDARY_LINE_CKSUM}" ]]; then
			echo "${MASTER_FILE_LISTING[${COUNT}]}|${MASTER_LINE_CKSUM}|${SECONDARY_LINE_CKSUM}|" >> ${OUTPUT_FILE}.diff
		else
			echo "${MASTER_FILE_LISTING[${COUNT}]}|${MASTER_LINE_CKSUM}|${SECONDARY_LINE_CKSUM}|" >> ${OUTPUT_FILE}.same
		fi
	fi

	COUNT=`expr ${COUNT} + 1`
done
