#!/usr/bin/perl -w
#
# Quick and dirty program to count the number of file handles each
# process has.  The idea is to find which one is leaking!
# 2004/08/19 Darcy
#

use strict;
my($proc);
my($count) = 0;
my($total) = 0;
my($null);
my($lastProc) = "";

open(PROC, "lsof -i|grep ESTABLISHED|") or die("Cannot open proc list\n");
<PROC>;
printf "PID\tCount\n---\t-----\n";
while (<PROC>) {
	($null,$proc,$null) = split;
	if ( $proc ne $lastProc ) {
		if ( $count > 0 ) {
			printf "$lastProc:\t$count\n";
		}
		$count = 0;
		$lastProc = $proc;
	}
	$count++;
	$total++;
}
printf "$lastProc:\t$count\n";
printf "total:\t$total\n";

exit 0;
