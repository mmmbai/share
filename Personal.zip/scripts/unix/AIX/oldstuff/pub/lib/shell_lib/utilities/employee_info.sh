#!/bin/ksh

#
# Display employee information, using the everyone table, for the purpose
# of setting up users within APWF.
#

if [ $# -ne 1 ]; then
	echo "Usage: $0 Name"
	exit -1
fi

name="'$1%'"

sqlplus tib_st/pathf1nd3r@orasrv24 <<-EOF > /tmp/employee_info
	set linesize 160
	select EMPLID,
		USER_ID,
		substr(NAME,0,45) as NAME,
		substr(EMAIL_ADDR,0,45) as EMAIL_ADDR
	from EVERYONE
	where NAME like $name;
EOF

awk '
	BEGIN { output=0 }

	$1 ~ /EMPLID/ { output=1 }
	$1 ~ /SQL/ { output=0 }

	{
		if (output == 1) { print $0 }
	}
'  /tmp/employee_info



rm -f /tmp/employee_info