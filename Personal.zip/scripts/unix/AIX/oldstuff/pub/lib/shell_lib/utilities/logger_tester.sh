#!/bin/bash

#   ===========================================================================
#
#   Title:  logger_tester.sh
#
#   Author: Wade Lockhart
#
#   Descr:  This script will simulate any of the log level conditions which exist
#	in the logger.cfg file. It will call logger in each case just like it
#	is called from a script.
#
#   Usage:  This script is menu-driven and interactive; it does not take
#	any arguments.
#
#   Legal:  Copyright(C) 2009 EnCana Corporation, All Rights Reserved.
#
#   ===========================================================================

TIBHOME=/apps/tibco

. ${TIBHOME}/.tibrc

BASENAME=`basename ${0}`

if [[ $# -gt 0 ]]; then
	exit 1
fi

# clear the screen
clear

PS3='Choose a number or enter (1) to Quit:'

select LEVEL in "Quit this script" "LOG_VERBOSE" "LOG_DEBUG" "LOG_AUDIT" "LOG_INFO" "LOG_WARN" "LOG_ERROR" "LOG_CRITICAL"
do

	case "${LEVEL}" in
	"LOG_VERBOSE")
		logger "${LOG_VERBOSE}" "logger_tester.sh" "Test message sent with level: ${LOG_VERBOSE}"
	;;
	"LOG_DEBUG")
		logger "${LOG_DEBUG}" "logger_tester.sh" "Test message sent with level: ${LOG_DEBUG}"
        ;;
	"LOG_AUDIT")
		logger "${LOG_AUDIT}" "logger_tester.sh" "Test message sent with level: ${LOG_AUDIT}"
        ;;
	"LOG_INFO")
		logger "${LOG_INFO}" "logger_tester.sh" "Test message sent with level: ${LOG_INFO}"
        ;;
	"LOG_WARN")
		logger "${LOG_WARN}" "logger_tester.sh" "Test message sent with level: ${LOG_WARN}"
        ;;
	"LOG_ERROR")
		MAGIC_EXISTS=`checkMagicLock ${BASENAME}`
		if [[ "${MAGIC_EXISTS}" == "TRUE" ]]; then
			echo "Did you remember to remove the mtlock file? Run rm -f ${TIBHOME}/lib/shell_lib/mtlock/${BASENAME}.lock"
        		logger "${LOG_WARN}" "logger_tester.sh" "Lock file found. Test message sent with level: ${LOG_WARN}"
		else
			logger "${LOG_ERROR}" "logger_tester.sh" "Test message sent with level: ${LOG_ERROR}"
		fi
        ;;
	"LOG_CRITICAL")
		MAGIC_EXISTS=`checkMagicLock ${BASENAME}`
                if [[ "${MAGIC_EXISTS}" == "TRUE" ]]; then
			echo "Did you remember to remove the mtlock file? Run rm -f ${TIBHOME}/lib/shell_lib/mtlock/${BASENAME}.lock"
                        logger "${LOG_WARN}" "logger_tester.sh" "Lock file found. Test message sent with level: ${LOG_WARN}"
                else
                        logger "${LOG_CRITICAL}" "logger_tester.sh" "Test message sent with level: ${LOG_CRITICAL}"
                fi
        ;;
	       *)
		echo "Check your results at: /apps/tibco/logger_tester.sh.log"
                echo "Exiting the script now!"
                exit 0
        ;;

	esac
done
exit 0
