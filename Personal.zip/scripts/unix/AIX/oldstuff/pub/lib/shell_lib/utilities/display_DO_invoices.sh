#!/bin/ksh


sqlplus dgtl_of_devlper/d1g1tal@orasrv24 <<-EOF
	set pagesize 1000
	set linesize 32767
	set tab off
	set wrap on
	set arraysize 1
	set long 10000
	set longc 10000

--	select	vendor_id, invoice_id, voucher_id, create_date
--	from	DGTL_OILFIELD.DO_INVOICE_HISTORY
--	where	rowstat_id = 'S'
select VENDOR_ID, INVOICE_ID, ROWSTAT_ID, modify_date from DGTL_OILFIELD.do_invoice_log
	;

EOF

