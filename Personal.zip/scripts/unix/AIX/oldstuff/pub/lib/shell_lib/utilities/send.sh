#!/bin/ksh

#   %P%  %Z%%I%  %E% %U%
#   ===========================================================================
#   Title:  send.sh
#
#   Author: Curtis Ling
#
#   Descr:  Attempt to send an email using mailx
#
#   Usage:  send.sh <mailfile>
#
#   Legal:  Copyright(C) 2002,2003 EnCana Corporation, All Rights Reserved.
#
#   History:
#   2003/10/09 CJL 1. Initial script creation
#   ===========================================================================

trap '/bin/rm -f $1;exit 0' 0 1 2 15 

/usr/bin/mailx -t < $1

exitVal=$?

if [ $exitVal -ne 0 ]; then
  echo "Unable to send using mailx.  An error occurred."
fi

exit $exitVal
