#!/bin/bash

TIBHOME="/apps/tibco/"
. ${TIBHOME}.tibrc

# check the number of arguments
if [[ $# -ne 1 ]]; then
	echo "Usage: $(basename $0) {full path plus tar file}"
	logger "${LOG_WARN}" "script_backr_upr.sh" "Usage: $(basename $0) {full path plus tar file}"
	exit 1
fi

TAR_FILE=${1}
TAR_CONTENTS_FILE="/apps/tibco/lib/shell_lib/logs/tar.tmp"

tar -tf ${TAR_FILE} > ${TAR_CONTENTS_FILE}
FILE_CONTENTS_ARRAY=$(<${TAR_CONTENTS_FILE})


