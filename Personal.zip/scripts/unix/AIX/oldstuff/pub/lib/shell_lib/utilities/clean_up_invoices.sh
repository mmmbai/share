#!/bin/ksh


# Where <<DOCID>> is the athena document that you are using to test.

sqlplus tib_ic/tib_ic@orasrv64 <<-EOF
	delete from tasks where job_id in (select job_id from jobs where name like '86756');
	delete from jobs where name like '86756';
	commit;
EOF

sqlplus tib_ap/tib_ap@orasrv48  <<-EOF
	delete from wf_invoice_header where athena_doc_id like '86756';
	delete from coding_log where athena_doc_id like '86756';
	commit;
EOF


