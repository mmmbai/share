#!/bin/bash

date
echo
find . | while read file 
# for file in $(find -print0  )  Do not use this. This filename have space.
do 
  fileTime=`stat "$file" | grep Modify|cut -c 9-38`
  echo  $file"; "$fileTime
done

echo
date
