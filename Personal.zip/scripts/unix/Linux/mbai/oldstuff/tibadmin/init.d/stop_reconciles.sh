#!/bin/bash

#   ===========================================================================
#
#   Title:  stop_reconciles.sh
#
#   Author: Darcy McKinnon
#
#   Descr:  Stop all reconciles that were left running when the engine shutdown.
#
#   Usage:  stop_reconciles.sh
#
#   Legal:  Copyright(C) 2004 EnCana Corporation, All Rights Reserved.
#           
#   ===========================================================================

TIBCO_HOME=/apps/tibco

. ${TIBCO_HOME}/.tibrc

BINDIR=/apps/tibco/Repositories/RefData/scripts
EXEC=${BINDIR}/mcdas_reconcile

logger "${LOG_INFO}" "stop_reconciles.sh" "Calling stop on reconciles using: ${EXEC} script."

${EXEC} stop PERSON
${EXEC} stop CODES
${EXEC} stop DEPARTMENT
${EXEC} stop BUILDING
${EXEC} stop COMPANY
${EXEC} stop PERSONAPPLICATION
${EXEC} stop ORGLEVEL
${EXEC} stop USERGROUP
${EXEC} stop USERROLE
