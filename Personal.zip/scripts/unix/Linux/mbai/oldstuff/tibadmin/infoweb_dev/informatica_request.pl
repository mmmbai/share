#!/usr/bin/perl -w
#   ===========================================================================
#
#   Title:  informatica_request.pl
#
#   Author: Darcy McKinnon/Michael Bai
#
#   Descr:  informatica_request.pl is used to communicate with a listener on the
#           specified server.  The command it sends to the remote listener
#           defaults to "STATUS", but can be given as an additional parameter.
#
#   Usage:  informatica_request.pl server [command]
#
#   Legal:  Copyright(C) 2013 Cenovus Corporation, All Rights Reserved.
#
#   ===========================================================================

use strict;
use Socket;

my ($remote)  = $ARGV[0] || 'localhost';
my ($request) = $ARGV[1] || "all_wf";
my ($port)    = 12010;
my ($iaddr);
my ($paddr);
my ($proto);
my ($old_file_handler);
my ($error_flag) = 0;

if ($#ARGV > 1) {
  # Originally this script expected only two arguments.  Its been modified to pass more through
  # but only if there are more.  CJL
  shift(@ARGV);                   # strip the target server argument
  $request = join(' ', @ARGV);    # concatenate the rest of the arguments and overwrite $request
}

$iaddr   = inet_aton($remote) or $error_flag = 1;
$paddr   = sockaddr_in($port, $iaddr);
$proto   = getprotobyname('tcp');

socket(SOCK, PF_INET, SOCK_STREAM, $proto) or $error_flag = 1;
connect(SOCK, $paddr) or $error_flag = 1;

if ($error_flag == 1) {
	print "$remote is not responding.\n";
} else {
	#
	# Request a process list and flush.
	#

	printf SOCK "$request\n";
	$old_file_handler = select SOCK; $|=1; select $old_file_handler;

	while (<SOCK>) {
		print;
	}

	close SOCK or die "close: $!";
}

exit $error_flag;
