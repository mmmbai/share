export ORACLE_HOME=/oracle/product/920
export PATH=$PATH:/oracle/product/920/bin


while read line
do
	[ -z "$line" ] && continue
	#echo $schema
	#sqlplus -s $schema @check.sql
	if [[ $line != //* ]]; then
	echo $line	
	echo -----------------------
	#sqlplus -s  $schema @check.sql
	echo
	fi
done <.schemas












