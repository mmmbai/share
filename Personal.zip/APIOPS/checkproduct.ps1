#  Connect-AzAccount -UseDeviceAuthentication
#APP
#Set-AzContext -Subscription  "31aa985b-4df3-43ab-87d3-92153f79500b"  
# Example .\extract.ps1  ApiId assessment-cci-employeraccount 
param(
    [Parameter(Mandatory)]
    [object]$ApiId 
)
$global:existingProductList = @()
$SYRGName = "AS-SY-APIMgmt-RG"
$SYServiceName = "as-sy-apimgmt01-apim"
$SYAPIMContext = New-AzApiManagementContext -ResourceGroupName $SYRGName -ServiceName $SYServiceName

$STRGName = "AS-ST-APIMgmt-RG"
$STServiceName = "as-st-apimgmt01-apim"
$STAPIMContext = New-AzApiManagementContext -ResourceGroupName $STRGName -ServiceName $STServiceName

$PRRGName = "AS-PR-APIMgmt-RG"
$PRServiceName = "as-pr-apimgmt01-apim"
$PRAPIMContext = New-AzApiManagementContext -ResourceGroupName $PRRGName -ServiceName $PRServiceName

$outString = "ProductName".PadRight(20) + "Sy".PadLeft(10) + "St".PadLeft(10) + "Pd".PadLeft(10) 
echo $outString

function yesNo {	
    param(
        [Parameter(Mandatory)]
        [object]$count
    )
    if ($count -eq 0) { return "N" } else { return "Y" }
     
}
function checkProduct {	
    param(
        [Parameter(Mandatory)]
        [object]$product
    )	 
    $syProducts = Get-AzApiManagementProduct -Context $SYAPIMContext -ProductId $product -ErrorAction SilentlyContinue
    $stProducts = Get-AzApiManagementProduct -Context $STAPIMContext -ProductId $product -ErrorAction SilentlyContinue
    $prProducts = Get-AzApiManagementProduct -Context $PRAPIMContext -ProductId $product -ErrorAction SilentlyContinue

    $outString = $product.PadRight(20)

    $outString += (yesNo $syProducts.Count).PadLeft(10)
    $outString += (yesNo $stProducts.Count).PadLeft(10)
    $outString += (yesNo $prProducts.Count).PadLeft(10)
    echo $outString  
    if ($prProducts.Count -ne 0) {        
        $global:existingProductList += $product       
     }
}

$productsFolderPath =	$ApiId + '/products/'
$productsFolder = Get-ChildItem -Path $productsFolderPath
foreach ($product in $productsFolder) {   
    checkProduct $product.Name
} 
$outString = "ProductName".PadRight(20) + "Sy".PadLeft(10) + "St".PadLeft(10) + "Pd".PadLeft(10) 
echo $outString 

function checkAPIinProduct {	
    param(
        [Parameter(Mandatory)]
        [object]$product
    )	 
    $syAPIList = Get-AzApiManagementApi -Context $SYAPIMContext -ProductId $product -ErrorAction SilentlyContinue
    $stAPIList  = Get-AzApiManagementApi -Context $STAPIMContext -ProductId $product -ErrorAction SilentlyContinue
    $prAPIList  = Get-AzApiManagementApi -Context $PRAPIMContext -ProductId $product -ErrorAction SilentlyContinue

    $outString = $product.PadRight(20)

    $outString += (yesNo $syProducts.Count).PadLeft(10)
    $outString += (yesNo $stProducts.Count).PadLeft(10)
    $outString += (yesNo $prProducts.Count).PadLeft(10)
    echo $outString  
    if ($prProducts.Count -ne 0) {        
        $global:existingProductList += $product       
     }
}
foreach ($product in  $global:existingProductList) {   
    checkAPIinProduct $product.Name
} 
 
 








