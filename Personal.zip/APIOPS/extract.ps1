##Version 1.4
# Updated by Michael Bai 2025/11/05
# v1.4 add support of versionset
## Powershell YAML module: https://www.powershellgallery.com/packages/powershell-yaml/0.4.7
#  Optional: Connect-AzAccount
# Example .\extract.ps1  b2b-claim-roicommon-api 
# Example .\extract.ps1  b2b-claim-roicommon-api excludeProduct
param(
		[Parameter(Mandatory)]
        [String]$ApiId,
				
		[Parameter()]
        [String] $excludeProduct
    )
$outFolder=	$ApiId + '/'
if (Test-Path  $outFolder	) {
        Remove-Item -Recurse -Force $outFolder
    }	
	

$RGName="DV-DV-APIMgmt-RG"
$ServiceName = "dv-dv-apimgmt01-apim"
function insertNamedValue {	
	param(
        [Parameter(Mandatory)]
        [object]$policy,
		[Parameter(Mandatory)]
        [object]$hashConfig
    )
	$pattern = '(?<={{)(.*?)(?=}})'
	$results = [regex]::Matches($policy,$pattern)
	write-host $results.count "namedValues"

	#insert namedValue. 
	foreach ($result in $results.value)
	{
		write-host "namedValue name:" $result
		# Don't insert it if 1. It's already in key namedValueNames 2. it's a shared namedValue 
		if ( !$hashConfig['namedValueNames'].Contains($result) -And !(Get-Content -Path "\\rc14dp40\L7 Support\Azure\Tools\APIM-extractor-creator\Config.txt").Contains($result))
			{ $hashConfig.namedValueNames += $result }
	}
	
	return $hashConfig
}

function insertProduct {	
	param(
        [Parameter(Mandatory)]
        [object]$products,
		[Parameter(Mandatory)]
        [object]$hashConfig
    )
	
	#insert products
	foreach ($product in $products)
	{
		write-host "product name:" $product.ProductId
		if ( !$hashConfig['productNames'].Contains($product.ProductId))
			{ $hashConfig.productNames += $product.ProductId }
	}
	
	return $hashConfig
}

function insertTag {	
	param(
        [Parameter(Mandatory)]
        [object]$tags,
		[Parameter(Mandatory)]
        [object]$hashConfig
    )
	
	#insert tags
	foreach ($tag in $tags)
	{
		write-host "Tag name:" $tags
		if ( !$hashConfig['tagNames'].Contains($tag))
			{ $hashConfig.tagNames += $tag }
	}
	
	return $hashConfig
}


# Load the extract YAML configuration and convert to hashtable
$Config = Get-Content -Path "\\rc14dp40\L7 Support\Azure\Tools\APIM-extractor-creator\extractor.yaml"
$content = ''
foreach ($line in $Config) { $content = $content + "`n" + $line }
$hashConfig = ConvertFrom-YAML $content

#Add API Id to the configuration file
$hashConfig.apiNames += $ApiId

## namedValue
# Load policy from APIM

# API policy
$APIMContext = New-AzApiManagementContext -ResourceGroupName $RGName -ServiceName $ServiceName
$APIPolicy = Get-AzApiManagementPolicy -Context $APIMContext -ApiId $ApiId
$hashConfig = insertNamedValue $APIPolicy $hashConfig

# Operation Policy
$APIOperations = Get-AzApiManagementOperation -Context $APIMContext -ApiId $ApiId
foreach ($operation in $APIOperations)
{
	$OpPolicy = Get-AzApiManagementPolicy -Context $APIMContext -ApiId $ApiId -OperationId $operation.OperationId
	If($OpPolicy -eq $null){continue}
	$hashConfig = insertNamedValue $OpPolicy $hashConfig
}

##Product
$products = Get-AzApiManagementProduct -Context $APIMContext -ApiId $ApiId
$hashConfig = insertProduct $products $hashConfig

## Tags
# API Tags
$tags = (Get-AzResource -ResourceGroupName $RGName -ResourceType Microsoft.ApiManagement/service/apis/tags -ResourceName "$ServiceName/$APIId" -ApiVersion 2022-08-01).Name
$hashConfig = insertTag $tags $hashConfig
#write to file
$OutYamlConfig = ConvertTo-Yaml $hashConfig
Out-File -FilePath extractor.yaml -InputObject $OutYamlConfig

# Run extract exe
$env:API_MANAGEMENT_SERVICE_OUTPUT_FOLDER_PATH=$outFolder
$env:AZURE_RESOURCE_GROUP_NAME="dv-dv-APIMgmt-RG"
$env:API_MANAGEMENT_SERVICE_NAME='dv-dv-apimgmt01-apim'
$env:APIM_INSTANCE_NAME='dv-dv-apimgmt01-apim'
$env:AZURE_SUBSCRIPTION_ID='e0279acf-930e-4937-abbf-f45670343bcf'
$env:AZURE_BEARER_TOKEN=ConvertFrom-SecureString (Get-AzAccessToken -AsSecureString).Token -AsPlainText
$env:CONFIGURATION_YAML_PATH='.\extractor.yaml'
$extractexec = '.\extractor.exe'

& $extractexec 

# Remove Starter Product
$starterFolder=$outFolder+"products/starter/"
if (Test-Path  $starterFolder	) {
		Remove-Item -Recurse -Force $starterFolder
	}	
# Remove Product
if($PSBoundParameters.ContainsKey('excludeProduct'))
{
	$productFolder=$outFolder+"products/"
	if (Test-Path  $productFolder	) {
		Remove-Item -Recurse -Force $productFolder
	}	
	 
}
else
{
	foreach ($product in $products)
	{
		$fileName=$outFolder+"products/"+ $product.ProductId +"/apis.json"	
		if (Test-Path  $fileName	) {
			Remove-Item -Recurse -Force $fileName
		}	
	}	 
}	

$api = Get-AzApiManagementApi -Context $APIMContext -ApiId $ApiId

if ($api.ApiVersionSetId) {
	$ApiVersionSetId = ($api.ApiVersionSetId -split "/")[-1]
	write-host "ApiVersionSetId:" $ApiVersionSetId
	Get-ChildItem -Path ($outFolder+"version sets/") | ForEach-Object {
		if ($_.Name -ne $ApiVersionSetId) {
			# Remove files or folders that are NOT named "abc"
			Remove-Item $_.FullName -Recurse -Force
		}
	}
} 
else 
{
    Remove-Item -Recurse -Force ($outFolder+"version sets/")
}

#Remove-Item -Recurse -Force ($outFolder+"version sets/")
Remove-Item -Recurse -Force ($outFolder+"policy.xml")

$apisinfoJson=$outFolder+"/apis/" + $ApiId + "/apiInformation.json"
$myJson = Get-Content $apisinfoJson -Raw | ConvertFrom-Json 
$myJson.properties.authenticationSettings=@{}
$myJson | ConvertTo-Json -Depth 4 | Out-File $apisinfoJson


# For the SOAP service, We will generate the json file to keep its APIId and all OperationId
# For the SOAP service, APIM will generate 2 ports(endpoint). Need to remove the second one
if ($api.ApiType -eq "soap")
{
	#Generate json file
	# Get operations for this API
	$operations = Get-AzApiManagementOperation -Context $APIMContext -ApiId $ApiId

	# Convert each operation into a custom object
	$operationObjects = @()
	foreach ($op in $operations) {
		$operationObjects += [PSCustomObject]@{
			OperationId   = $op.OperationId
			Name          = $op.Name
			Method        = $op.Method
			UrlTemplate   = $op.UrlTemplate
			Description   = $op.Description
		}
	}

	# Build full API object with operations as child
	$apiObject = [PSCustomObject]@{
		ApiId       = $api.ApiId
		Name        = $api.Name
		ServiceUrl  = $api.ServiceUrl
		Path        = $api.Path
		Description = $api.Description   
		ApiType     = $api.ApiType	
		Operations  = $operationObjects
	}

	# Convert to Json and write to file
	$Json =  $apiObject | ConvertTo-Json -Depth 10
	$fileName = $outFolder+"apis/" + $ApiId + "/"+ ($api.ApiId) + ".json"	
	$Json | Out-File -FilePath ($fileName) -Encoding utf8	
	write-host "Json File saved:" $fileName 
	
	# Remove 2 Ports to 1
	$workingPath = Get-Location
	Set-Location "$ApiId\apis\$ApiId"
	$xml = [xml](Get-Content specification.wsdl)

	$namespace = $xml.DocumentElement.NamespaceURI
	$ns = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
	$ns.AddNamespace("wsdl", $namespace)
	$xpath = "/wsdl:definitions/wsdl:service/wsdl:port"

	$nodeToRemove = $xml.SelectNodes($xpath, $ns)
	if ($nodeToRemove.ChildNodes.Count -gt 1)
	{
		$singleNode = $nodeToRemove[1]
		$singleNode.ParentNode.RemoveChild($singleNode)
	}

	$xml.Save((Get-Location).Path+"\specification.wsdl")
	Set-Location $workingPath
}

#Generate publish Yaml

$publishYaml = [PSCustomObject]@{
	apimServiceName=$ApiId
	namedValues=@()	
}

foreach ($namedValueName in $hashConfig.namedValueNames)
{
	If($namedValueName -eq "None"){continue}
	$properties=	[PSCustomObject]@{
		displayName=$namedValueName
		value="PlaceHolder"
    }
	$namedValue=	[PSCustomObject]@{
		name=$namedValueName
		properties=$properties
    }
	$publishYaml.namedValues+=$namedValue	
}
ConvertTo-Yaml $publishYaml|Out-File -FilePath ($outFolder+"publish.sy.yaml")
ConvertTo-Yaml $publishYaml|Out-File -FilePath ($outFolder+"publish.st.yaml")
ConvertTo-Yaml $publishYaml|Out-File -FilePath ($outFolder+"publish.pr.yaml")
 














