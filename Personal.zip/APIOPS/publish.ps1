##Version 1.3
# Updated by Michael Bai 2025/07/14
#-myenv sy -toolfolder tool -apifolder test-api
[CmdletBinding()]
param
(
    [Parameter()]
    [String] $myenv,
	
	[Parameter()]
    [String] $toolfolder,
	
	[Parameter()]
    [String] $apifolder
	
)

$env:API_MANAGEMENT_SERVICE_OUTPUT_FOLDER_PATH="./"+ $apifolder
$env:AZURE_RESOURCE_GROUP_NAME="AS-" + $myenv + "-APIMgmt-RG"
$env:API_MANAGEMENT_SERVICE_NAME='as-'+$myenv+'-apimgmt01-apim'
$env:APIM_INSTANCE_NAME='as-'+$myenv+'-apimgmt01-apim'
$env:AZURE_SUBSCRIPTION_ID='31aa985b-4df3-43ab-87d3-92153f79500b'
$env:AZURE_BEARER_TOKEN=ConvertFrom-SecureString(Get-AzAccessToken -AsSecureString).Token -AsPlainText
$env:CONFIGURATION_YAML_PATH=$apifolder + '/publish.'+$myenv+'.yaml'
$publishexec = $toolfolder + '/_WS.Integration.APIM/APIOPS/publisher.exe'
echo ("Using publish exe:" + $publishexec)


function updateProduct {	
	param(
        [Parameter(Mandatory)]
        [object]$product
    )
	echo ("  Updateing product " + $product)
	$outFolder=  $apifolder	
	$hashConfig=@()
	try {
		$apilist = Get-AzApiManagementApi -Context $APIMContext -ProductId $product
	}
	catch {
		Write-Host "Get-AzApiManagementApi Exception: $($_.Exception.Message)"		
		if ($_.Exception.Message -like "*Error Code: ResourceNotFound*") {
			Write-Host "This Exception is ResourceNotFound. It is because target system does not have this product. It should be a new product. Will continue"
			$apilist=@()			
		}
		else
		{
			throw $_ 
		}
	}
	
	$hash=@{}		
	$hash.Add("name", $apifolder)
    $hashConfig+=$hash	
	
	#insert products
	foreach ($api in $apilist)
	{
		if($api.ApiId -ne $apifolder)
		{
			
			$hash=@{}		
			$hash.Add("name", $api.ApiId)			 
			$hashConfig+=$hash
		}
	} 
 
	#$hash.Add("name", $apifolder)		
	$OutJsonConfig = ConvertTo-Json $hashConfig
	$fileName=$outFolder+"/products/"+ $product +"/apis.json"	
	#Following are not used in this version since folder must already in there
	#$FolderName=Split-Path -Parent $fileName
	#New-Item -ItemType Directory -Force -Path $FolderName
	Out-File -FilePath $fileName -InputObject $OutJsonConfig
	#Delete policy.xml file
	$policyFile=$outFolder+"/products/"+ $product+"/policy.xml"
	if (Test-Path  $policyFile	) {
			Remove-Item -Recurse -Force $policyFile
	}	
	echo ("  Done Updated product " + $product)
}

#Update product infomation from target environment. The products will only add the current API. All others are same with target environment
if (Test-Path  ($apifolder+"/products") 	) 
{
	echo "Updateing product infomation from target environment"
	$APIMContext = New-AzApiManagementContext -ResourceGroupName $env:AZURE_RESOURCE_GROUP_NAME -ServiceName $env:API_MANAGEMENT_SERVICE_NAME
	Get-ChildItem -Path ($apifolder+"/products") -Directory | ForEach-Object {
		updateProduct( $_.Name) 
	}
}

# If current API is a Soap API. We will  Create this API based on extracted json to keep operation ID same
$ApiId=$apifolder
$JsonFileName=$apifolder+"/apis/" + $ApiId + "/"+ ($ApiId) + ".json"	
echo ("Testing JsonFile exists or not:" + $JsonFileName)
if (Test-Path  $JsonFileName 	) 
{
	write-host ("This is a soap project, will genereate the API based on Json file:" + $JsonFileName )
	$context = New-AzApiManagementContext -ResourceGroupName $env:AZURE_RESOURCE_GROUP_NAME -ServiceName $env:APIM_INSTANCE_NAME

	$apiDef = Get-Content $JsonFileName -Raw | ConvertFrom-Json

	# Check if API exists
	$existingApi = Get-AzApiManagementApi -Context $context -ApiId $apiDef.ApiId -ErrorAction SilentlyContinue

	if ($null -ne $existingApi) {
		Write-Host "API '$($apiDef.Name)' already exists. Skipping creation. Wiil continue"
	} else {
		Write-Host "Creating API '$($apiDef.Name)'..."

		# Create the API 
		# Build parameters dynamically
		$apiParams = @{
			Context     = $context
			ApiId       = $apiDef.ApiId
			Name        = $apiDef.Name
			Path        = $apiDef.Path
			ApiType     = $apiDef.ApiType
			Protocols   = @("https")
		}

		# Optional: add only if not null or empty
		if ($apiDef.Description) {
			$apiParams["Description"] = $apiDef.Description
		}
		if ($apiDef.ServiceUrl) {
			$apiParams["ServiceUrl"] = $apiDef.ServiceUrl
		}

		# Call the API creation command
		New-AzApiManagementApi @apiParams > $null

		# Add operations
		foreach ($op in $apiDef.Operations) {
			Write-Host "  Adding operation '$($op.Name)'..."
			$operationParams = @{
				Context      = $context
				ApiId        = $apiDef.ApiId
				OperationId  = $op.OperationId
				Name         = $op.Name
				Method       = $op.Method
				UrlTemplate  = $op.UrlTemplate
			}

			# Add Description only if not null or empty
			if ($op.Description) {
				$operationParams["Description"] = $op.Description
			}

			# Call the operation creation
			New-AzApiManagementOperation @operationParams > $null
		}

		Write-Host "API and operations created successfully."
	}
}

echo ("Starting publish ")
& $publishexec
# Check if the process succeeded
if ($?) {
    Write-Output "Success"
} else {
    Write-Output "Failure"
	Throw "Publish failed"
}


 