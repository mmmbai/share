#  Connect-AzAccount -UseDeviceAuthentication
#APP
#Set-AzContext -Subscription  "31aa985b-4df3-43ab-87d3-92153f79500b"  
# Example .\extract.ps1  -productId b2b-claim-roicommon-api 

#$DVRGName="DV-DV-APIMgmt-RG"
#$DVServiceName = "dv-dv-apimgmt01-apim"
#$DVAPIMContext = New-AzApiManagementContext -ResourceGroupName $DVRGName -ServiceName $DVServiceName

$SYRGName="AS-SY-APIMgmt-RG"
$SYServiceName = "as-sy-apimgmt01-apim"
$SYAPIMContext = New-AzApiManagementContext -ResourceGroupName $SYRGName -ServiceName $SYServiceName

$STRGName="AS-ST-APIMgmt-RG"
$STServiceName = "as-st-apimgmt01-apim"
$STAPIMContext = New-AzApiManagementContext -ResourceGroupName $STRGName -ServiceName $STServiceName

$PRRGName="AS-PR-APIMgmt-RG"
$PRServiceName = "as-pr-apimgmt01-apim"
$PRAPIMContext = New-AzApiManagementContext -ResourceGroupName $PRRGName -ServiceName $PRServiceName
	 
$syProducts = Get-AzApiManagementProduct -Context $SYAPIMContext -ProductId starter
$stProducts = Get-AzApiManagementProduct -Context $STAPIMContext -ProductId starter
$prProducts = Get-AzApiManagementProduct -Context $PRAPIMContext -ProductId starter

if(($null -eq $syProducts ) -or ($null -eq $stProducts) -or($null -eq $prProducts))  {
	Write-Host "Can not connect to sy or st or pd, Please fix it and rerun this program"
	exit
}

Write-Host "Connected to sy, st and pd without errors. Continue..."










