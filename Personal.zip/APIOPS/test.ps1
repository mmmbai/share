#  Connect-AzAccount -UseDeviceAuthentication
#APP
#Set-AzContext -Subscription  "31aa985b-4df3-43ab-87d3-92153f79500b"  
# Example .\extract.ps1  ApiId assessment-cci-employeraccount 
param(
    [Parameter(Mandatory)]
    [object]$ApiId 
)
$script:existingProductList = @()

[System.Collections.ArrayList]$script:dvAPIList = @()
[System.Collections.ArrayList]$script:syAPIList = @()
[System.Collections.ArrayList]$script:stAPIList = @()
[System.Collections.ArrayList]$script:prAPIList = @()
$SYRGName = "AS-SY-APIMgmt-RG"
$SYServiceName = "as-sy-apimgmt01-apim"
$SYAPIMContext = New-AzApiManagementContext -ResourceGroupName $SYRGName -ServiceName $SYServiceName

$STRGName = "AS-ST-APIMgmt-RG"
$STServiceName = "as-st-apimgmt01-apim"
$STAPIMContext = New-AzApiManagementContext -ResourceGroupName $STRGName -ServiceName $STServiceName

$PRRGName = "AS-PR-APIMgmt-RG"
$PRServiceName = "as-pr-apimgmt01-apim"
$PRAPIMContext = New-AzApiManagementContext -ResourceGroupName $PRRGName -ServiceName $PRServiceName

$outString = "ProductName".PadRight(20) + "Sy".PadLeft(10) + "St".PadLeft(10) + "Pd".PadLeft(10) 
echo $outString

function yesNo {	
    param(
        [Parameter(Mandatory)]
        [object]$count
    )
    if ($count -eq 0) { return "N" } else { return "Y" }
     
}
function checkProduct {	
    param(
        [Parameter(Mandatory)]
        [object]$product
    )	 
    $syProducts = Get-AzApiManagementProduct -Context $SYAPIMContext -ProductId $product -ErrorAction SilentlyContinue
    $stProducts = Get-AzApiManagementProduct -Context $STAPIMContext -ProductId $product -ErrorAction SilentlyContinue
    $prProducts = Get-AzApiManagementProduct -Context $PRAPIMContext -ProductId $product -ErrorAction SilentlyContinue

    $outString = $product.PadRight(20)

    $outString += (yesNo $syProducts.Count).PadLeft(10)
    $outString += (yesNo $stProducts.Count).PadLeft(10)
    $outString += (yesNo $prProducts.Count).PadLeft(10)
    echo $outString  
    if ($prProducts.Count -ne 0) {        
        $script:existingProductList += $product       
    }
}

$productsFolderPath =	$ApiId + '/products/'
$productsFolder = Get-ChildItem -Path $productsFolderPath
foreach ($product in $productsFolder) {   
    checkProduct $product.Name
} 



function loadDvAPIList {	
    param(
        [Parameter(Mandatory)]
        [object]$product
    )	
    $apisFileName =	$ApiId + '/products/' + $product + "/apis.json"  
    $myJson = Get-Content $apisFileName -Raw | ConvertFrom-Json 
    $script:dvAPIList = $myJson.name     
}

function getAPIlistFromObject {	
    param(
        [Parameter(Mandatory)]
        [object]$listObject
    )	
    $apiList = @()
    foreach ($api in $listObject) {
		 	
        $apiList += $api.ApiId
    }	
    return    $apiList 
}


function loadAPIList {	
    param(
        [Parameter(Mandatory)]
        [object]$product
    )	 
    #-ErrorAction SilentlyContinue
    $syAPIListObj = Get-AzApiManagementApi -Context $SYAPIMContext -ProductId $product  
    $stAPIListObj = Get-AzApiManagementApi -Context $STAPIMContext -ProductId $product  
    $prAPIListObj = Get-AzApiManagementApi -Context $PRAPIMContext -ProductId $product 

    $script:syAPIList = getAPIlistFromObject $syAPIListObj  
    $script:stAPIList = getAPIlistFromObject $stAPIListObj  
    $script:prAPIList = getAPIlistFromObject $prAPIListObj  
 
}

function removePrAPI {	
    $tempList = $script:prAPIList.PsObject.Copy()     
    foreach ($api in $tempList) {     
        if ($script:dvAPIList.Contains($api) -and $script:syAPIList.Contains($api) -and $script:stAPIList.Contains($api)   ) {
            $script:dvAPIList.Remove($api)
            $script:syAPIList.Remove($api)
            $script:stAPIList.Remove($api)
            $script:prAPIList.Remove($api)
        }
    }     
}

function formatAPIExistorNot {	
    foreach ($api in  $script:dvAPIList ) {
        $outString = $api.PadRight(50)
        echo $outString 
    }   
}
function IfApiExist {	
    param(
        [Parameter(Mandatory)]
        [object]$api,
        [Parameter(Mandatory)]
        [object]$arrList
    )
    if ($arrList.Contains($api) ) {
        $arrList.Remove($api)
        return "Y".PadRight(10) 
    } 
    else
    { return "N".PadRight(10) }
     
}

function printEnv {	
    param(
        [Parameter(Mandatory)]
        [object]$arrList
    )
    $tempList = $arrList.PsObject.Copy()     
    foreach ($api in  $tempList ) {
        $outString = $api.PadRight(50)
        $outString += IfApiExist  $api $script:dvAPIList
        $outString += IfApiExist  $api $script:syAPIList
        $outString += IfApiExist  $api $script:stAPIList
        $outString += IfApiExist  $api $script:prAPIList
        echo $outString 
    }   
}

foreach ($product in  $script:existingProductList) {     
    $outString = "------" + $product + "------"
    echo $outString 
    $outString = "APIName".PadRight(50) + "Dv".PadRight(10) + "Sy".PadRight(10) + "St".PadRight(10) + "Pd".PadRight(10) 
    echo $outString 
    $script:dvAPIList.Clear()
    $script:syAPIList.Clear()
    $script:stAPIList.Clear()
    $script:prAPIList.Clear()
    loadDvAPIList $product
    loadAPIList $product
    removePrAPI
    printEnv $script:dvAPIList
    printEnv $script:syAPIList
    printEnv $script:stAPIList
    printEnv $script:prAPIList
} 
 











