Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class Keyboard {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
}
"@

$VK_SCROLL = 0x91
$KEYEVENTF_KEYUP = 0x0002

while ($true) {
    [Keyboard]::keybd_event($VK_SCROLL, 0, 0, [UIntPtr]::Zero)
    [Keyboard]::keybd_event($VK_SCROLL, 0, $KEYEVENTF_KEYUP, [UIntPtr]::Zero)

    Start-Sleep -Seconds 150
}