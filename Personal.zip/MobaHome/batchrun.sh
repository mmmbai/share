#!/bin/sh
PWD=`pwd`
ifile="$PWD/server.lists/server.list"
#ifile="$PWD/server.lists/esb_crp_prd.list"
cfile="$PWD/command/command"

while read server
do
	if [[ $server == "#"* ]] ; then       
            echo $server
            continue;       
    fi    
	if [[ $server == ""  ]] ; then continue; fi	
	tibrun="tibrun${server:3:4}"
	while read command
	do	
		if [[ $command == "#"* ]] ; then continue; fi
		if [[ $command == ""  ]] ; then continue; fi		
		realcommand=${command/TIBRUN/$tibrun} 
		#echo $realcommand
		#echo Run: ssh -n -q $server $realcommand
		#echo -n $tibrun:
		echo -n $server:       
		ssh -n -q $server  $realcommand 
	done < $cfile
	#echo $server finished
done < $ifile