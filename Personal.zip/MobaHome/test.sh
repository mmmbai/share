#!/bin/sh
VALUE="ITEM4"

LIST1="ITEM1 
ITEM2"
LIST2="ITEM3
 ITEM4"

# echo "ITEM1 ITEM2" | xargs -n1 echo | grep -e "ITEM1"

if [ -n "`echo $LIST1 | xargs -n1 echo | grep -e \"$VALUE\"`" ]; then
   echo "in 1"
elif [ -n "`echo $LIST2 | xargs -n1 echo | grep -e \"$VALUE\"`" ]; then
  echo "in 2"
else  
  echo "no there"
fi