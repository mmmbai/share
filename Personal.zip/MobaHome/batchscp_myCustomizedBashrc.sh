#!/bin/sh
PWD=`pwd`
ifile="$PWD/server.lists/server.list"
cfile="$PWD/command/.myCustomizedBashrc"
#cfile="$PWD/command/bashrc"
while read server
do
	if [[ $server == "#"* ]] ; then continue; fi
	if [[ $server == ""  ]] ; then continue; fi	

    scp -q  $cfile micbai@$server:~
	echo $server done.
done < $ifile
