#!/bin/sh
PWD=`pwd`
ifile="$PWD/server.lists/server.list"
cfile="$PWD/command/tib.bashrc"

while read server
do
	if [[ $server == "#"* ]] ; then continue; fi
	if [[ $server == ""  ]] ; then continue; fi	

    scp -q  $cfile micbai@$server:~ 
	echo $server done.
done < $ifile


#cp /home/micbai/tib.bashrc .bashrc