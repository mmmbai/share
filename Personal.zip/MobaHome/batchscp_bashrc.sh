#!/bin/sh
PWD=`pwd`
ifile="$PWD/server.lists/server.list"
#ifile="$PWD/server.lists/temp.list"
tfile="$PWD/command/bashrc.templete"
cfile="$PWD/command/bashrc"

BLDLIST="esbcallbld01
esbcallbld02
esbcallbld03"

ORADRRLIST="esbdrrora01"

ORANPRDLIST="esbnprdora1
esbnprdora2
esbnprdora3
esbnprdora4
esbnprdora7
esbnprdora8"

ORAPRDLIST="
esbprdora01
esbprdora02
esbprdora03
esbprdora04
esbprdora07
esbprdora08
"

while read server
do
	if [[ $server == "#"* ]] ; then continue; fi
	if [[ $server == ""  ]] ; then continue; fi	
	if [ -n "`echo $BLDLIST | xargs -n1 echo | grep -e \"$server\"`" ]; then  #BLDLIST
	   	tibrun="tibrunbld"
		sed "s/TIBRUN/$tibrun/g" $tfile > $cfile
	elif [ -n "`echo $ORADRRLIST | xargs -n1 echo | grep -e \"$server\"`" ]; then #ORADRRLIST
	  	tibrun="tibruncdrr"
		sed "s/TIBRUN/$tibrun/g" $tfile > $cfile
	elif [ -n "`echo $ORANPRDLIST | xargs -n1 echo | grep -e \"$server\"`" ]; then #ORANPRDLIST
	  	tibrun="tibruncnprd"
		sed "s/TIBRUN/$tibrun/g" $tfile > $cfile	
	elif [ -n "`echo $ORAPRDLIST | xargs -n1 echo | grep -e \"$server\"`" ]; then #ORAPRDLIST
	  	tibrun="tibruncprd"
		sed "s/TIBRUN/$tibrun/g" $tfile > $cfile		
	else  
	  	tibrun="tibrun${server:3:4}"
		sed "s/TIBRUN/$tibrun/g" $tfile > $cfile
	fi
	scp -q  $cfile micbai@$server:~/.bashrc
	echo $server done.
done < $ifile
